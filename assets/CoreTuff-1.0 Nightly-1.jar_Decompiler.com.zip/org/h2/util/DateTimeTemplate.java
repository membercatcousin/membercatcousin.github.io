package org.h2.util;

import java.util.ArrayList;
import java.util.Arrays;
import org.h2.engine.CastDataProvider;
import org.h2.message.DbException;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueDate;
import org.h2.value.ValueTime;
import org.h2.value.ValueTimeTimeZone;
import org.h2.value.ValueTimestamp;
import org.h2.value.ValueTimestampTimeZone;

public final class DateTimeTemplate {
   private static final SmallLRUCache<String, DateTimeTemplate> CACHE = SmallLRUCache.<String, DateTimeTemplate>newInstance(100);
   private final Part[] parts;
   private final boolean containsDate;
   private final boolean containsTime;
   private final boolean containsTimeZone;

   public static DateTimeTemplate of(String var0) {
      synchronized(CACHE) {
         DateTimeTemplate var2 = (DateTimeTemplate)CACHE.get(var0);
         if (var2 != null) {
            return var2;
         }
      }

      DateTimeTemplate var1 = parseTemplate(var0);
      DateTimeTemplate var7;
      synchronized(CACHE) {
         var7 = (DateTimeTemplate)CACHE.putIfAbsent(var0, var1);
      }

      return var7 != null ? var7 : var1;
   }

   private static DateTimeTemplate parseTemplate(String var0) {
      ArrayList var1 = new ArrayList();
      Scanner var2 = new Scanner(var0);

      int var3;
      int var4;
      Object var5;
      for(var3 = 0; (var4 = var2.readChar()) >= 0; var1.add(var5)) {
         switch (var4) {
            case 32:
               var5 = DateTimeTemplate.Delimiter.SPACE;
               break;
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 40:
            case 41:
            case 42:
            case 43:
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 60:
            case 61:
            case 62:
            case 63:
            case 64:
            case 66:
            case 67:
            case 69:
            case 71:
            case 73:
            case 74:
            case 75:
            case 76:
            case 78:
            case 79:
            case 81:
            case 85:
            case 86:
            case 87:
            case 88:
            default:
               throw DbException.get(90014, var0);
            case 39:
               var5 = DateTimeTemplate.Delimiter.APOSTROPHE;
               break;
            case 44:
               var5 = DateTimeTemplate.Delimiter.COMMA;
               break;
            case 45:
               var5 = DateTimeTemplate.Delimiter.MINUS_SIGN;
               break;
            case 46:
               var5 = DateTimeTemplate.Delimiter.PERIOD;
               break;
            case 47:
               var5 = DateTimeTemplate.Delimiter.SOLIDUS;
               break;
            case 58:
               var5 = DateTimeTemplate.Delimiter.COLON;
               break;
            case 59:
               var5 = DateTimeTemplate.Delimiter.SEMICOLON;
               break;
            case 65:
            case 80:
               var2.readChar('.');
               var2.readChar('M');
               var2.readChar('.');
               var3 = checkUsed(var3, 11, var0);
               var5 = DateTimeTemplate.Field.AM_PM;
               break;
            case 68:
               var2.readChar('D');
               if (var2.readCharIf('D')) {
                  var3 = checkUsed(var3, 4, var0);
                  var5 = DateTimeTemplate.Field.DDD;
               } else {
                  var3 = checkUsed(var3, 3, var0);
                  var5 = DateTimeTemplate.Field.DD;
               }
               break;
            case 70:
               var2.readChar('F');
               var4 = var2.readChar();
               if (var4 < 49 || var4 > 57) {
                  throw DbException.get(90014, var0);
               }

               var3 = checkUsed(var3, 10, var0);
               var5 = DateTimeTemplate.Field.ff(var4 - 48);
               break;
            case 72:
               var2.readChar('H');
               if (var2.readCharIf('2')) {
                  var2.readChar('4');
                  var3 = checkUsed(var3, 6, var0);
                  var5 = DateTimeTemplate.Field.HH24;
               } else {
                  if (var2.readCharIf('1')) {
                     var2.readChar('2');
                  }

                  var3 = checkUsed(var3, 5, var0);
                  var5 = DateTimeTemplate.Field.HH12;
               }
               break;
            case 77:
               if (var2.readCharIf('I')) {
                  var3 = checkUsed(var3, 7, var0);
                  var5 = DateTimeTemplate.Field.MI;
               } else {
                  var2.readChar('M');
                  var3 = checkUsed(var3, 2, var0);
                  var5 = DateTimeTemplate.Field.MM;
               }
               break;
            case 82:
               var3 = checkUsed(var3, 0, var0);
               var2.readChar('R');
               if (var2.readCharIf('R')) {
                  var2.readChar('R');
                  var5 = DateTimeTemplate.Field.RRRR;
               } else {
                  var5 = DateTimeTemplate.Field.RR;
               }
               break;
            case 83:
               var2.readChar('S');
               if (var2.readCharIf('S')) {
                  var2.readChar('S');
                  var2.readChar('S');
                  var3 = checkUsed(var3, 9, var0);
                  var5 = DateTimeTemplate.Field.SSSSS;
               } else {
                  var3 = checkUsed(var3, 8, var0);
                  var5 = DateTimeTemplate.Field.SS;
               }
               break;
            case 84:
               var2.readChar('Z');
               if (var2.readCharIf('H')) {
                  var3 = checkUsed(var3, 12, var0);
                  var5 = DateTimeTemplate.Field.TZH;
               } else if (var2.readCharIf('M')) {
                  var3 = checkUsed(var3, 13, var0);
                  var5 = DateTimeTemplate.Field.TZM;
               } else {
                  var2.readChar('S');
                  var3 = checkUsed(var3, 14, var0);
                  var5 = DateTimeTemplate.Field.TZS;
               }
               break;
            case 89:
               var3 = checkUsed(var3, 0, var0);
               if (var2.readCharIf('Y')) {
                  if (var2.readCharIf('Y')) {
                     var5 = var2.readCharIf('Y') ? DateTimeTemplate.Field.YYYY : DateTimeTemplate.Field.YYY;
                  } else {
                     var5 = DateTimeTemplate.Field.YY;
                  }
               } else {
                  var5 = DateTimeTemplate.Field.Y;
               }
         }
      }

      if (((var3 & 16) == 0 || (var3 & 12) == 0) && (var3 & 32) != 0 == ((var3 & 2048) != 0) && ((var3 & 64) == 0 || (var3 & 32) == 0) && ((var3 & 512) == 0 || (var3 & 480) == 0) && ((var3 & 16384) == 0 || (var3 & 8192) != 0) && ((var3 & 8192) == 0 || (var3 & 4096) != 0)) {
         return new DateTimeTemplate((Part[])var1.toArray(new Part[0]), (var3 & 29) != 0, (var3 & 3040) != 0, (var3 & 28672) != 0);
      } else {
         throw DbException.get(90014, var0);
      }
   }

   private static int checkUsed(int var0, int var1, String var2) {
      int var3 = var0 | 1 << var1;
      if (var0 == var3) {
         throw DbException.get(90014, var2);
      } else {
         return var3;
      }
   }

   private DateTimeTemplate(Part[] var1, boolean var2, boolean var3, boolean var4) {
      this.parts = var1;
      this.containsDate = var2;
      this.containsTime = var3;
      this.containsTimeZone = var4;
   }

   public String format(Value var1) {
      long var2;
      long var4;
      int var6;
      switch (var1.getValueType()) {
         case 0:
            return null;
         case 17:
            if (this.containsTime || this.containsTimeZone) {
               throw DbException.get(90014, "time or time zone fields with DATE");
            }

            var2 = ((ValueDate)var1).getDateValue();
            var4 = 0L;
            var6 = 0;
            break;
         case 18:
            if (this.containsDate || this.containsTimeZone) {
               throw DbException.get(90014, "date or time zone fields with TIME");
            }

            var2 = 0L;
            var4 = ((ValueTime)var1).getNanos();
            var6 = 0;
            break;
         case 19:
            if (this.containsDate) {
               throw DbException.get(90014, "date fields with TIME WITH TIME ZONE");
            }

            ValueTimeTimeZone var13 = (ValueTimeTimeZone)var1;
            var2 = 0L;
            var4 = var13.getNanos();
            var6 = var13.getTimeZoneOffsetSeconds();
            break;
         case 20:
            if (this.containsTimeZone) {
               throw DbException.get(90014, "time zone fields with TIMESTAMP");
            }

            ValueTimestamp var12 = (ValueTimestamp)var1;
            var2 = var12.getDateValue();
            var4 = var12.getTimeNanos();
            var6 = 0;
            break;
         case 21:
            ValueTimestampTimeZone var7 = (ValueTimestampTimeZone)var1;
            var2 = var7.getDateValue();
            var4 = var7.getTimeNanos();
            var6 = var7.getTimeZoneOffsetSeconds();
            break;
         default:
            throw DbException.getUnsupportedException(var1.getType().getTraceSQL());
      }

      StringBuilder var14 = new StringBuilder();

      for(Part var11 : this.parts) {
         var11.format(var14, var2, var4, var6);
      }

      return var14.toString();
   }

   public Value parse(String var1, TypeInfo var2, CastDataProvider var3) {
      switch (var2.getValueType()) {
         case 17:
            if (!this.containsTime && !this.containsTimeZone) {
               int[] var8 = yearMonth(var3);
               return ValueDate.fromDateValue(constructDate(this.parse(var1, var8[0]), var8));
            }

            throw DbException.get(90014, "time or time zone fields with DATE");
         case 18:
            if (!this.containsDate && !this.containsTimeZone) {
               return ValueTime.fromNanos(constructTime(this.parse(var1, 0)));
            }

            throw DbException.get(90014, "date or time zone fields with TIME");
         case 19:
            if (this.containsDate) {
               throw DbException.get(90014, "date fields with TIME WITH TIME ZONE");
            }

            int[] var7 = this.parse(var1, 0);
            return ValueTimeTimeZone.fromNanos(constructTime(var7), constructOffset(var7));
         case 20:
            if (this.containsTimeZone) {
               throw DbException.get(90014, "time zone fields with TIMESTAMP");
            }

            int[] var6 = yearMonth(var3);
            int[] var9 = this.parse(var1, var6[0]);
            return ValueTimestamp.fromDateValueAndNanos(constructDate(var9, var6), constructTime(var9));
         case 21:
            int[] var4 = yearMonth(var3);
            int[] var5 = this.parse(var1, var4[0]);
            return ValueTimestampTimeZone.fromDateValueAndNanos(constructDate(var5, var4), constructTime(var5), constructOffset(var5));
         default:
            throw DbException.getUnsupportedException(var2.getTraceSQL());
      }
   }

   private static int[] yearMonth(CastDataProvider var0) {
      long var1 = var0.currentTimestamp().getDateValue();
      return new int[]{DateTimeUtils.yearFromDateValue(var1), DateTimeUtils.monthFromDateValue(var1)};
   }

   private int[] parse(String var1, int var2) {
      int[] var3 = new int[15];
      Arrays.fill(var3, Integer.MIN_VALUE);
      Scanner var4 = new Scanner(var1);
      int var5 = 0;

      for(int var6 = this.parts.length - 1; var5 <= var6; ++var5) {
         Part var7 = this.parts[var5];
         var7.parse(var3, var4, (var5 == 0 || (1 << var7.type() & 6144) != 0 || (1 << this.parts[var5 - 1].type() & '蠀') != 0) && (var5 == var6 || var7.type() == 11 || (1 << this.parts[var5 + 1].type() & '頀') != 0), var2);
      }

      return var3;
   }

   private static long constructDate(int[] var0, int[] var1) {
      int var2 = var0[0];
      if (var2 == Integer.MIN_VALUE) {
         var2 = var0[1];
      }

      if (var2 == Integer.MIN_VALUE) {
         var2 = var1[0];
      }

      int var3 = var0[4];
      if (var3 != Integer.MIN_VALUE) {
         if (var3 >= 1 && var3 <= (DateTimeUtils.isLeapYear(var2) ? 366 : 365)) {
            return DateTimeUtils.dateValueFromAbsoluteDay(DateTimeUtils.absoluteDayFromYear((long)var2) + (long)var3 - 1L);
         } else {
            throw DbException.get(90014, "Day of year " + var3);
         }
      } else {
         int var4 = var0[2];
         if (var4 == Integer.MIN_VALUE) {
            var4 = var1[1];
         }

         int var5 = var0[3];
         if (var5 == Integer.MIN_VALUE) {
            var5 = 1;
         }

         if (!DateTimeUtils.isValidDate(var2, var4, var5)) {
            throw DbException.get(90014, "Invalid date, year=" + var2 + ", month=" + var4 + ", day=" + var5);
         } else {
            return DateTimeUtils.dateValue((long)var2, var4, var5);
         }
      }
   }

   private static long constructTime(int[] var0) {
      int var1 = var0[9];
      if (var1 == Integer.MIN_VALUE) {
         int var2 = var0[6];
         if (var2 == Integer.MIN_VALUE) {
            var2 = var0[5];
            if (var2 == Integer.MIN_VALUE) {
               var2 = 0;
            } else {
               if (var2 < 1 || var2 > 12) {
                  throw DbException.get(90014, "Hour(12) " + var2);
               }

               if (var2 == 12) {
                  var2 = 0;
               }

               var2 += var0[11] * 12;
            }
         } else if (var2 < 0 || var2 > 23) {
            throw DbException.get(90014, "Hour(24) " + var2);
         }

         int var3 = var0[7];
         if (var3 == Integer.MIN_VALUE) {
            var3 = 0;
         } else if (var3 < 0 || var3 > 59) {
            throw DbException.get(90014, "Minute " + var3);
         }

         int var4 = var0[8];
         if (var4 == Integer.MIN_VALUE) {
            var4 = 0;
         } else if (var4 < 0 || var4 > 59) {
            throw DbException.get(90014, "Second of minute " + var4);
         }

         var1 = (var2 * 60 + var3) * 60 + var4;
      } else if (var1 < 0 || (long)var1 >= 86400L) {
         throw DbException.get(90014, "Second of day " + var1);
      }

      int var6 = var0[10];
      if (var6 == Integer.MIN_VALUE) {
         var6 = 0;
      }

      return (long)var1 * 1000000000L + (long)var6;
   }

   private static int constructOffset(int[] var0) {
      int var1 = var0[12];
      if (var1 == Integer.MIN_VALUE) {
         return 0;
      } else {
         boolean var2 = var1 < 0;
         if (var2) {
            if (var1 == -100) {
               var1 = 0;
            } else {
               var1 = -var1;
            }
         }

         int var3 = var0[13];
         if (var3 == Integer.MIN_VALUE) {
            var3 = 0;
         } else if (var3 > 59) {
            throw DbException.get(90014, "Time zone minute " + var3);
         }

         int var4 = var0[14];
         if (var4 == Integer.MIN_VALUE) {
            var4 = 0;
         } else if (var4 > 59) {
            throw DbException.get(90014, "Time zone second " + var4);
         }

         int var5 = (var1 * 60 + var3) * 60 + var4;
         if (var5 > 64800) {
            throw DbException.get(90014, "Time zone offset is too large");
         } else {
            return var2 ? -var5 : var5;
         }
      }
   }

   public static final class FieldType {
      static final int YEAR = 0;
      static final int ROUNDED_YEAR = 1;
      static final int MONTH = 2;
      static final int DAY_OF_MONTH = 3;
      static final int DAY_OF_YEAR = 4;
      static final int HOUR12 = 5;
      static final int HOUR24 = 6;
      static final int MINUTE = 7;
      static final int SECOND_OF_MINUTE = 8;
      static final int SECOND_OF_DAY = 9;
      static final int FRACTION = 10;
      static final int AMPM = 11;
      static final int TIME_ZONE_HOUR = 12;
      static final int TIME_ZONE_MINUTE = 13;
      static final int TIME_ZONE_SECOND = 14;
      static final int DELIMITER = 15;
   }

   private static final class Scanner {
      final String string;
      private int offset;
      private final int length;

      Scanner(String var1) {
         this.string = var1;
         this.length = var1.length();
      }

      int readChar() {
         return this.offset < this.length ? this.string.charAt(this.offset++) : -1;
      }

      void readChar(char var1) {
         if (this.offset < this.length && this.string.charAt(this.offset) == var1) {
            ++this.offset;
         } else {
            throw DbException.get(90014, this.string);
         }
      }

      boolean readCharIf(char var1) {
         if (this.offset < this.length && this.string.charAt(this.offset) == var1) {
            ++this.offset;
            return true;
         } else {
            return false;
         }
      }

      int readPositiveInt(int var1, boolean var2) {
         int var3 = this.offset;
         int var4;
         if (var2) {
            char var5;
            for(var4 = var3; var4 < this.length && (var5 = this.string.charAt(var4)) >= '0' && var5 <= '9'; ++var4) {
            }

            if (var3 == var4) {
               throw DbException.get(90014, this.string);
            }
         } else {
            var4 = var3 + var1;
            if (var4 > this.length) {
               throw DbException.get(90014, this.string);
            }
         }

         try {
            return StringUtils.parseUInt31(this.string, var3, this.offset = var4);
         } catch (NumberFormatException var6) {
            throw DbException.get(90014, this.string);
         }
      }

      int readNanos(int var1, boolean var2) {
         int var3 = this.offset;
         int var5 = 0;
         int var6 = 100000000;
         int var4;
         if (var2) {
            char var8;
            for(var4 = var3; var4 < this.length && (var8 = this.string.charAt(var4)) >= '0' && var8 <= '9'; ++var4) {
               var5 += var6 * (var8 - 48);
               var6 /= 10;
            }

            if (var3 == var4) {
               throw DbException.get(90014, this.string);
            }
         } else {
            var4 = var3 + var1;
            if (var4 > this.length) {
               throw DbException.get(90014, this.string);
            }

            while(var3 < var4) {
               char var7 = this.string.charAt(var3);
               if (var7 < '0' || var7 > '9') {
                  throw DbException.get(90014, this.string);
               }

               var5 += var6 * (var7 - 48);
               var6 /= 10;
               ++var3;
            }
         }

         this.offset = var4;
         return var5;
      }
   }

   private abstract static class Part {
      Part() {
      }

      abstract int type();

      abstract void format(StringBuilder var1, long var2, long var4, int var6);

      abstract void parse(int[] var1, Scanner var2, boolean var3, int var4);
   }

   private static final class Delimiter extends Part {
      static final Delimiter MINUS_SIGN = new Delimiter('-');
      static final Delimiter PERIOD = new Delimiter('.');
      static final Delimiter SOLIDUS = new Delimiter('/');
      static final Delimiter COMMA = new Delimiter(',');
      static final Delimiter APOSTROPHE = new Delimiter('\'');
      static final Delimiter SEMICOLON = new Delimiter(';');
      static final Delimiter COLON = new Delimiter(':');
      static final Delimiter SPACE = new Delimiter(' ');
      private final char delimiter;

      private Delimiter(char var1) {
         this.delimiter = var1;
      }

      int type() {
         return 15;
      }

      public void format(StringBuilder var1, long var2, long var4, int var6) {
         var1.append(this.delimiter);
      }

      public void parse(int[] var1, Scanner var2, boolean var3, int var4) {
         var2.readChar(this.delimiter);
      }
   }

   private static final class Field extends Part {
      static final Field Y = new Field(0, 1);
      static final Field YY = new Field(0, 2);
      static final Field YYY = new Field(0, 3);
      static final Field YYYY = new Field(0, 4);
      static final Field RR = new Field(1, 2);
      static final Field RRRR = new Field(1, 4);
      static final Field MM = new Field(2, 2);
      static final Field DD = new Field(3, 2);
      static final Field DDD = new Field(4, 3);
      static final Field HH12 = new Field(5, 2);
      static final Field HH24 = new Field(6, 2);
      static final Field MI = new Field(7, 2);
      static final Field SS = new Field(8, 2);
      static final Field SSSSS = new Field(9, 5);
      private static final Field[] FF;
      static final Field AM_PM = new Field(11, 4);
      static final Field TZH = new Field(12, 2);
      static final Field TZM = new Field(13, 2);
      static final Field TZS = new Field(14, 2);
      private final int type;
      private final int digits;

      static Field ff(int var0) {
         return FF[var0 - 1];
      }

      Field(int var1, int var2) {
         this.type = var1;
         this.digits = var2;
      }

      int type() {
         return this.type;
      }

      void format(StringBuilder var1, long var2, long var4, int var6) {
         switch (this.type) {
            case 0:
            case 1:
               int var10 = DateTimeUtils.yearFromDateValue(var2);
               if (var10 < 0) {
                  var1.append('-');
                  var10 = -var10;
               }

               switch (this.digits) {
                  case 1:
                     var10 %= 10;
                     break;
                  case 2:
                     var10 %= 100;
                     break;
                  case 3:
                     var10 %= 1000;
               }

               formatLast(var1, var10, this.digits);
               break;
            case 2:
               StringUtils.appendTwoDigits(var1, DateTimeUtils.monthFromDateValue(var2));
               break;
            case 3:
               StringUtils.appendTwoDigits(var1, DateTimeUtils.dayFromDateValue(var2));
               break;
            case 4:
               StringUtils.appendZeroPadded(var1, 3, DateTimeUtils.getDayOfYear(var2));
               break;
            case 5:
               int var9 = (int)(var4 / 3600000000000L);
               if (var9 == 0) {
                  var9 = 12;
               } else if (var9 > 12) {
                  var9 -= 12;
               }

               StringUtils.appendTwoDigits(var1, var9);
               break;
            case 6:
               StringUtils.appendTwoDigits(var1, (int)(var4 / 3600000000000L));
               break;
            case 7:
               StringUtils.appendTwoDigits(var1, (int)(var4 / 60000000000L % 60L));
               break;
            case 8:
               StringUtils.appendTwoDigits(var1, (int)(var4 / 1000000000L % 60L));
               break;
            case 9:
               StringUtils.appendZeroPadded(var1, 5, (int)(var4 / 1000000000L));
               break;
            case 10:
               formatLast(var1, (int)(var4 % 1000000000L) / DateTimeUtils.FRACTIONAL_SECONDS_TABLE[this.digits], this.digits);
               break;
            case 11:
               int var8 = (int)(var4 / 3600000000000L);
               var1.append(var8 < 12 ? "A.M." : "P.M.");
               break;
            case 12:
               int var7 = var6 / 3600;
               if (var6 >= 0) {
                  var1.append('+');
               } else {
                  var7 = -var7;
                  var1.append('-');
               }

               StringUtils.appendTwoDigits(var1, var7);
               break;
            case 13:
               StringUtils.appendTwoDigits(var1, Math.abs(var6 % 3600 / 60));
               break;
            case 14:
               StringUtils.appendTwoDigits(var1, Math.abs(var6 % 60));
         }

      }

      private static void formatLast(StringBuilder var0, int var1, int var2) {
         if (var2 == 2) {
            StringUtils.appendTwoDigits(var0, var1);
         } else {
            StringUtils.appendZeroPadded(var0, var2, var1);
         }

      }

      void parse(int[] var1, Scanner var2, boolean var3, int var4) {
         switch (this.type) {
            case 0:
            case 1:
               boolean var8 = var2.readCharIf('-');
               if (!var8) {
                  var2.readCharIf('+');
               }

               int var9 = var2.readPositiveInt(this.digits, var3);
               if (var8) {
                  if (this.digits < 4 || this.type == 1) {
                     throw DbException.get(90014, var2.string);
                  }

                  var9 = -var9;
               } else if (this.digits < 4) {
                  if (this.digits == 1) {
                     if (var9 > 9) {
                        throw DbException.get(90014, var2.string);
                     }

                     var9 += var4 / 10 * 10;
                  } else if (this.digits == 2) {
                     if (var9 > 99) {
                        throw DbException.get(90014, var2.string);
                     }

                     var9 += var4 / 100 * 100;
                     if (this.type == 1) {
                        if (var9 > var4 + 50) {
                           var9 -= 100;
                        } else if (var9 < var4 - 49) {
                           var9 += 100;
                        }
                     }
                  } else if (this.digits == 3) {
                     if (var9 > 999) {
                        throw DbException.get(90014, var2.string);
                     }

                     var9 += var4 / 1000 * 1000;
                  }
               }

               var1[this.type] = var9;
               break;
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
            case 9:
            case 13:
            case 14:
               var1[this.type] = var2.readPositiveInt(this.digits, var3);
               break;
            case 10:
               var1[10] = var2.readNanos(this.digits, var3);
               break;
            case 11:
               byte var7;
               if (var2.readCharIf('A')) {
                  var7 = 0;
               } else {
                  var2.readChar('P');
                  var7 = 1;
               }

               var2.readChar('.');
               var2.readChar('M');
               var2.readChar('.');
               var1[11] = var7;
               break;
            case 12:
               boolean var5 = var2.readCharIf('-');
               if (!var5 && !var2.readCharIf('+')) {
                  var2.readChar(' ');
               }

               int var6 = var2.readPositiveInt(this.digits, var3);
               if (var6 > 18) {
                  throw DbException.get(90014, var2.string);
               }

               var1[12] = var5 ? (var6 == 0 ? -100 : -var6) : var6;
         }

      }

      static {
         Field[] var0 = new Field[9];

         for(int var1 = 0; var1 < 9; var0[var1++] = new Field(10, var1)) {
         }

         FF = var0;
      }
   }
}
