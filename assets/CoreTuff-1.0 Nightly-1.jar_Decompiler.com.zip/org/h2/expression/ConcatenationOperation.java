package org.h2.expression;

import java.util.Arrays;
import org.h2.engine.SessionLocal;
import org.h2.expression.function.CastSpecification;
import org.h2.expression.function.ConcatFunction;
import org.h2.value.DataType;
import org.h2.value.ExtTypeInfo;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueArray;
import org.h2.value.ValueNull;
import org.h2.value.ValueVarbinary;
import org.h2.value.ValueVarchar;

public final class ConcatenationOperation extends OperationN {
   public ConcatenationOperation() {
      super(new Expression[4]);
   }

   public ConcatenationOperation(Expression var1, Expression var2) {
      super(new Expression[]{var1, var2});
      this.argsCount = 2;
   }

   public boolean needParentheses() {
      return true;
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      int var3 = 0;

      for(int var4 = this.args.length; var3 < var4; ++var3) {
         if (var3 > 0) {
            var1.append(" || ");
         }

         this.args[var3].getSQL(var1, var2, 0);
      }

      return var1;
   }

   public Value getValue(SessionLocal var1) {
      int var2 = this.args.length;
      if (var2 == 2) {
         Value var3 = this.args[0].getValue(var1);
         var3 = var3.convertTo(this.type, var1);
         if (var3 == ValueNull.INSTANCE) {
            return ValueNull.INSTANCE;
         } else {
            Value var4 = this.args[1].getValue(var1);
            var4 = var4.convertTo(this.type, var1);
            return (Value)(var4 == ValueNull.INSTANCE ? ValueNull.INSTANCE : this.getValue(var1, var3, var4));
         }
      } else {
         return this.getValue(var1, var2);
      }
   }

   private Value getValue(SessionLocal var1, Value var2, Value var3) {
      int var4 = this.type.getValueType();
      if (var4 == 2) {
         String var11 = var2.getString();
         String var13 = var3.getString();
         return ValueVarchar.get((new StringBuilder(var11.length() + var13.length())).append(var11).append(var13).toString());
      } else if (var4 == 6) {
         byte[] var10 = var2.getBytesNoCopy();
         byte[] var12 = var3.getBytesNoCopy();
         int var14 = var10.length;
         int var15 = var12.length;
         byte[] var16 = Arrays.copyOf(var10, var14 + var15);
         System.arraycopy(var12, 0, var16, var14, var15);
         return ValueVarbinary.getNoCopy(var16);
      } else {
         Value[] var5 = ((ValueArray)var2).getList();
         Value[] var6 = ((ValueArray)var3).getList();
         int var7 = var5.length;
         int var8 = var6.length;
         Value[] var9 = (Value[])Arrays.copyOf(var5, var7 + var8);
         System.arraycopy(var6, 0, var9, var7, var8);
         return ValueArray.get((TypeInfo)this.type.getExtTypeInfo(), var9, var1);
      }
   }

   private Value getValue(SessionLocal var1, int var2) {
      Value[] var3 = new Value[var2];

      for(int var4 = 0; var4 < var2; ++var4) {
         Value var5 = this.args[var4].getValue(var1).convertTo(this.type, var1);
         if (var5 == ValueNull.INSTANCE) {
            return ValueNull.INSTANCE;
         }

         var3[var4] = var5;
      }

      int var11 = this.type.getValueType();
      if (var11 == 2) {
         StringBuilder var14 = new StringBuilder();

         for(int var18 = 0; var18 < var2; ++var18) {
            var14.append(var3[var18].getString());
         }

         return ValueVarchar.get(var14.toString(), var1);
      } else if (var11 == 6) {
         int var13 = 0;

         for(int var16 = 0; var16 < var2; ++var16) {
            var13 += var3[var16].getBytesNoCopy().length;
         }

         byte[] var17 = new byte[var13];
         int var19 = 0;

         for(int var20 = 0; var20 < var2; ++var20) {
            byte[] var21 = var3[var20].getBytesNoCopy();
            int var22 = var21.length;
            System.arraycopy(var21, 0, var17, var19, var22);
            var19 += var22;
         }

         return ValueVarbinary.getNoCopy(var17);
      } else {
         int var12 = 0;

         for(int var6 = 0; var6 < var2; ++var6) {
            var12 += ((ValueArray)var3[var6]).getList().length;
         }

         Value[] var15 = new Value[var12];
         int var7 = 0;

         for(int var8 = 0; var8 < var2; ++var8) {
            Value[] var9 = ((ValueArray)var3[var8]).getList();
            int var10 = var9.length;
            System.arraycopy(var9, 0, var15, var7, var10);
            var7 += var10;
         }

         return ValueArray.get((TypeInfo)this.type.getExtTypeInfo(), var15, var1);
      }
   }

   public Expression optimize(SessionLocal var1) {
      this.determineType(var1);
      this.inlineSubexpressions((var1x) -> var1x instanceof ConcatenationOperation && var1x.getType().getValueType() == this.type.getValueType());
      if (this.type.getValueType() == 2 && var1.getMode().treatEmptyStringsAsNull) {
         return (new ConcatFunction(0, this.args)).optimize(var1);
      } else {
         int var2 = this.args.length;
         boolean var3 = true;
         boolean var4 = false;

         for(int var5 = 0; var5 < var2; ++var5) {
            if (this.args[var5].isConstant()) {
               var4 = true;
            } else {
               var3 = false;
            }
         }

         if (var3) {
            return TypedValueExpression.getTypedIfNull(this.getValue(var1), this.type);
         } else {
            if (var4) {
               int var11 = 0;

               for(int var6 = 0; var6 < var2; ++var6) {
                  Object var7 = this.args[var6];
                  if (((Expression)var7).isConstant()) {
                     Value var8 = ((Expression)var7).getValue(var1).convertTo(this.type, var1);
                     if (var8 == ValueNull.INSTANCE) {
                        return TypedValueExpression.get(ValueNull.INSTANCE, this.type);
                     }

                     if (isEmpty(var8)) {
                        continue;
                     }

                     Expression var9;
                     for(; var6 + 1 < var2 && (var9 = this.args[var6 + 1]).isConstant(); ++var6) {
                        Value var10 = var9.getValue(var1).convertTo(this.type, var1);
                        if (var10 == ValueNull.INSTANCE) {
                           return TypedValueExpression.get(ValueNull.INSTANCE, this.type);
                        }

                        if (!isEmpty(var10)) {
                           var8 = this.getValue(var1, var8, var10);
                        }
                     }

                     var7 = ValueExpression.get(var8);
                  }

                  this.args[var11++] = (Expression)var7;
               }

               if (var11 == 1) {
                  Expression var12 = this.args[0];
                  TypeInfo var13 = var12.getType();
                  if (TypeInfo.areSameTypes(this.type, var13)) {
                     return var12;
                  }

                  return new CastSpecification(var12, this.type);
               }

               this.argsCount = var11;
               this.doneWithParameters();
            }

            return this;
         }
      }
   }

   private void determineType(SessionLocal var1) {
      int var2 = this.args.length;
      boolean var3 = false;
      boolean var4 = true;
      boolean var5 = true;

      for(int var6 = 0; var6 < var2; ++var6) {
         Expression var7 = this.args[var6].optimize(var1);
         this.args[var6] = var7;
         int var8 = var7.getType().getValueType();
         if (var8 == 40) {
            var3 = true;
            var5 = false;
            var4 = false;
         } else if (var8 != 0) {
            if (DataType.isBinaryStringType(var8)) {
               var5 = false;
            } else if (DataType.isCharacterStringType(var8)) {
               var4 = false;
            } else {
               var5 = false;
               var4 = false;
            }
         }
      }

      if (var3) {
         this.type = TypeInfo.getTypeInfo(40, -1L, 0, TypeInfo.getHigherType(this.args).getExtTypeInfo());
      } else if (var4) {
         long var9 = this.getPrecision(0);

         for(int var11 = 1; var11 < var2; ++var11) {
            var9 = DataType.addPrecision(var9, this.getPrecision(var11));
         }

         this.type = TypeInfo.getTypeInfo(6, var9, 0, (ExtTypeInfo)null);
      } else if (var5) {
         long var10 = this.getPrecision(0);

         for(int var12 = 1; var12 < var2; ++var12) {
            var10 = DataType.addPrecision(var10, this.getPrecision(var12));
         }

         this.type = TypeInfo.getTypeInfo(2, var10, 0, (ExtTypeInfo)null);
      } else {
         this.type = TypeInfo.TYPE_VARCHAR;
      }

   }

   private long getPrecision(int var1) {
      TypeInfo var2 = this.args[var1].getType();
      return var2.getValueType() != 0 ? var2.getPrecision() : 0L;
   }

   private static boolean isEmpty(Value var0) {
      int var1 = var0.getValueType();
      if (var1 == 2) {
         return var0.getString().isEmpty();
      } else if (var1 == 6) {
         return var0.getBytesNoCopy().length == 0;
      } else {
         return ((ValueArray)var0).getList().length == 0;
      }
   }
}
