package org.h2.index;

public final class IndexSort implements Comparable<IndexSort> {
   public static final int FULLY_SORTED = Integer.MAX_VALUE;
   private final Index index;
   private final int sortedColumns;
   private final boolean reverse;

   public IndexSort(Index var1, boolean var2) {
      this(var1, Integer.MAX_VALUE, var2);
   }

   public IndexSort(Index var1, int var2, boolean var3) {
      this.index = var1;
      this.sortedColumns = var2;
      this.reverse = var3;
   }

   public Index getIndex() {
      return this.index;
   }

   public int getSortedColumns() {
      return this.sortedColumns;
   }

   public boolean isReverse() {
      return this.reverse;
   }

   public int compareTo(IndexSort var1) {
      return var1.sortedColumns - this.sortedColumns;
   }
}
