package org.h2.value;

import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import org.h2.engine.CastDataProvider;
import org.h2.engine.SysProperties;
import org.h2.message.DbException;
import org.h2.store.DataHandler;
import org.h2.store.FileStore;
import org.h2.store.FileStoreOutputStream;
import org.h2.store.LobStorageInterface;
import org.h2.util.IOUtils;
import org.h2.util.MathUtils;
import org.h2.util.StringUtils;
import org.h2.util.Utils;
import org.h2.value.lob.LobData;
import org.h2.value.lob.LobDataDatabase;
import org.h2.value.lob.LobDataFetchOnDemand;
import org.h2.value.lob.LobDataFile;
import org.h2.value.lob.LobDataInMemory;

public final class ValueBlob extends ValueLob {
   public static ValueBlob createSmall(byte[] var0) {
      return new ValueBlob(new LobDataInMemory(var0), (long)var0.length);
   }

   public static ValueBlob createTempBlob(InputStream var0, long var1, DataHandler var3) {
      try {
         long var4 = Long.MAX_VALUE;
         if (var1 >= 0L && var1 < var4) {
            var4 = var1;
         }

         int var6 = ValueLob.getBufferSize(var3, var4);
         byte[] var7;
         if (var6 >= Integer.MAX_VALUE) {
            var7 = IOUtils.readBytesAndClose(var0, -1);
            var6 = var7.length;
         } else {
            var7 = Utils.newBytes(var6);
            var6 = IOUtils.readFully(var0, var7, var6);
         }

         return var6 <= var3.getMaxLengthInplaceLob() ? createSmall(Utils.copyBytes(var7, var6)) : createTemporary(var3, var7, var6, var0, var4);
      } catch (IOException var8) {
         throw DbException.convertIOException(var8, (String)null);
      }
   }

   private static ValueBlob createTemporary(DataHandler var0, byte[] var1, int var2, InputStream var3, long var4) throws IOException {
      String var6 = ValueLob.createTempLobFileName(var0);
      FileStore var7 = var0.openFile(var6, "rw", false);
      var7.autoDelete();
      long var8 = 0L;
      FileStoreOutputStream var10 = new FileStoreOutputStream(var7, (String)null);

      try {
         do {
            var8 += (long)var2;
            var10.write(var1, 0, var2);
            var4 -= (long)var2;
            if (var4 <= 0L) {
               break;
            }

            var2 = ValueLob.getBufferSize(var0, var4);
            var2 = IOUtils.readFully(var3, var1, var2);
         } while(var2 > 0);
      } catch (Throwable var14) {
         try {
            var10.close();
         } catch (Throwable var13) {
            var14.addSuppressed(var13);
         }

         throw var14;
      }

      var10.close();
      return new ValueBlob(new LobDataFile(var0, var6, var7), var8);
   }

   public ValueBlob(LobData var1, long var2) {
      super(var1, var2, -1L);
   }

   public int getValueType() {
      return 7;
   }

   public String getString() {
      long var1 = this.charLength;
      if (var1 >= 0L) {
         if (var1 > 1000000000L) {
            throw this.getStringTooLong(var1);
         } else {
            return this.readString((int)var1);
         }
      } else if (this.octetLength > 3000000000L) {
         throw this.getStringTooLong(this.charLength());
      } else {
         String var3;
         if (this.lobData instanceof LobDataInMemory) {
            var3 = new String(((LobDataInMemory)this.lobData).getSmall(), StandardCharsets.UTF_8);
         } else {
            var3 = this.readString(Integer.MAX_VALUE);
         }

         this.charLength = var1 = (long)var3.length();
         if (var1 > 1000000000L) {
            throw this.getStringTooLong(var1);
         } else {
            return var3;
         }
      }
   }

   byte[] getBytesInternal() {
      if (this.octetLength > 1000000000L) {
         throw this.getBinaryTooLong(this.octetLength);
      } else {
         return this.readBytes((int)this.octetLength);
      }
   }

   public InputStream getInputStream() {
      return this.lobData.getInputStream(this.octetLength);
   }

   public InputStream getInputStream(long var1, long var3) {
      long var5 = this.octetLength;
      return rangeInputStream(this.lobData.getInputStream(var5), var1, var3, var5);
   }

   public Reader getReader(long var1, long var3) {
      return rangeReader(this.getReader(), var1, var3, -1L);
   }

   public int compareTypeSafe(Value var1, CompareMode var2, CastDataProvider var3) {
      if (var1 == this) {
         return 0;
      } else {
         ValueBlob var4 = (ValueBlob)var1;
         LobData var5 = this.lobData;
         LobData var6 = var4.lobData;
         if (var5.getClass() == var6.getClass()) {
            if (var5 instanceof LobDataInMemory) {
               return Integer.signum(Arrays.compareUnsigned(((LobDataInMemory)var5).getSmall(), ((LobDataInMemory)var6).getSmall()));
            }

            if (var5 instanceof LobDataDatabase) {
               if (((LobDataDatabase)var5).getLobId() == ((LobDataDatabase)var6).getLobId()) {
                  return 0;
               }
            } else if (var5 instanceof LobDataFetchOnDemand && ((LobDataFetchOnDemand)var5).getLobId() == ((LobDataFetchOnDemand)var6).getLobId()) {
               return 0;
            }
         }

         return compare(this, var4);
      }
   }

   private static int compare(ValueBlob var0, ValueBlob var1) {
      long var2 = Math.min(var0.octetLength, var1.octetLength);

      try {
         InputStream var4 = var0.getInputStream();

         int var9;
         label148: {
            int var19;
            label149: {
               label150: {
                  try {
                     InputStream var5;
                     label152: {
                        var5 = var1.getInputStream();

                        label153: {
                           label154: {
                              try {
                                 byte[] var6 = new byte[512];

                                 for(byte[] var7 = new byte[512]; var2 >= 512L; var2 -= 512L) {
                                    if (IOUtils.readFully((InputStream)var4, (byte[])var6, 512) != 512 || IOUtils.readFully((InputStream)var5, (byte[])var7, 512) != 512) {
                                       throw DbException.getUnsupportedException("Invalid LOB");
                                    }

                                    int var8 = Integer.signum(Arrays.compareUnsigned(var6, var7));
                                    if (var8 != 0) {
                                       var9 = var8;
                                       break label153;
                                    }
                                 }

                                 while(true) {
                                    int var16 = var4.read();
                                    var9 = var5.read();
                                    if (var16 < 0) {
                                       var19 = var9 < 0 ? 0 : -1;
                                       break label154;
                                    }

                                    if (var9 < 0) {
                                       var19 = 1;
                                       break;
                                    }

                                    if (var16 != var9) {
                                       var19 = (var16 & 255) < (var9 & 255) ? -1 : 1;
                                       break label152;
                                    }
                                 }
                              } catch (Throwable var13) {
                                 if (var5 != null) {
                                    try {
                                       var5.close();
                                    } catch (Throwable var12) {
                                       var13.addSuppressed(var12);
                                    }
                                 }

                                 throw var13;
                              }

                              if (var5 != null) {
                                 var5.close();
                              }
                              break label150;
                           }

                           if (var5 != null) {
                              var5.close();
                           }
                           break label149;
                        }

                        if (var5 != null) {
                           var5.close();
                        }
                        break label148;
                     }

                     if (var5 != null) {
                        var5.close();
                     }
                  } catch (Throwable var14) {
                     if (var4 != null) {
                        try {
                           var4.close();
                        } catch (Throwable var11) {
                           var14.addSuppressed(var11);
                        }
                     }

                     throw var14;
                  }

                  if (var4 != null) {
                     var4.close();
                  }

                  return var19;
               }

               if (var4 != null) {
                  var4.close();
               }

               return var19;
            }

            if (var4 != null) {
               var4.close();
            }

            return var19;
         }

         if (var4 != null) {
            var4.close();
         }

         return var9;
      } catch (IOException var15) {
         throw DbException.convert(var15);
      }
   }

   public StringBuilder getSQL(StringBuilder var1, int var2) {
      if ((var2 & 2) == 0 || this.lobData instanceof LobDataInMemory && this.octetLength <= SysProperties.MAX_TRACE_DATA_LENGTH) {
         if ((var2 & 6) == 0) {
            var1.append("CAST(X'");
            StringUtils.convertBytesToHex(var1, this.getBytesNoCopy()).append("' AS BINARY LARGE OBJECT(").append(this.octetLength).append("))");
         } else {
            var1.append("X'");
            StringUtils.convertBytesToHex(var1, this.getBytesNoCopy()).append('\'');
         }
      } else {
         var1.append("CAST(REPEAT(CHAR(0), ").append(this.octetLength).append(") AS BINARY VARYING");
         this.formatLobDataComment(var1);
      }

      return var1;
   }

   ValueBlob convertPrecision(long var1) {
      if (this.octetLength <= var1) {
         return this;
      } else {
         DataHandler var4 = this.lobData.getDataHandler();
         ValueBlob var3;
         if (var4 != null) {
            var3 = createTempBlob(this.getInputStream(), var1, var4);
         } else {
            try {
               var3 = createSmall(IOUtils.readBytesAndClose(this.getInputStream(), MathUtils.convertLongToInt(var1)));
            } catch (IOException var6) {
               throw DbException.convertIOException(var6, (String)null);
            }
         }

         return var3;
      }
   }

   public ValueLob copy(DataHandler var1, int var2) {
      if (this.lobData instanceof LobDataInMemory) {
         byte[] var3 = ((LobDataInMemory)this.lobData).getSmall();
         if (var3.length > var1.getMaxLengthInplaceLob()) {
            LobStorageInterface var4 = var1.getLobStorage();
            ValueBlob var5 = var4.createBlob(this.getInputStream(), this.octetLength);
            ValueLob var6 = var5.copy(var1, var2);
            var5.remove();
            return var6;
         } else {
            return this;
         }
      } else if (this.lobData instanceof LobDataDatabase) {
         return var1.getLobStorage().copyLob(this, var2);
      } else {
         throw new UnsupportedOperationException();
      }
   }

   public long charLength() {
      long var1 = this.charLength;
      if (var1 < 0L) {
         if (this.lobData instanceof LobDataInMemory) {
            var1 = (long)(new String(((LobDataInMemory)this.lobData).getSmall(), StandardCharsets.UTF_8)).length();
         } else {
            try {
               Reader var3 = this.getReader();

               try {
                  var1 = 0L;

                  while(true) {
                     var1 += var3.skip(Long.MAX_VALUE);
                     if (var3.read() < 0) {
                        break;
                     }

                     ++var1;
                  }
               } catch (Throwable var7) {
                  if (var3 != null) {
                     try {
                        var3.close();
                     } catch (Throwable var6) {
                        var7.addSuppressed(var6);
                     }
                  }

                  throw var7;
               }

               if (var3 != null) {
                  var3.close();
               }
            } catch (IOException var8) {
               throw DbException.convertIOException(var8, (String)null);
            }
         }

         this.charLength = var1;
      }

      return var1;
   }

   public long octetLength() {
      return this.octetLength;
   }
}
