package org.h2.table;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import org.h2.command.query.AllColumnsForPlan;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionVisitor;
import org.h2.message.Trace;

public class Plan {
   private final TableFilter[] filters;
   private final HashMap<TableFilter, PlanItem> planItems = new HashMap();
   private final Expression[] allConditions;
   private final TableFilter[] allFilters;

   public Plan(TableFilter[] var1, int var2, Expression var3) {
      this.filters = new TableFilter[var2];
      System.arraycopy(var1, 0, this.filters, 0, var2);
      ArrayList var4 = new ArrayList();
      ArrayList var5 = new ArrayList();
      if (var3 != null) {
         var4.add(var3);
      }

      for(int var6 = 0; var6 < var2; ++var6) {
         TableFilter var7 = var1[var6];
         var7.visit((var2x) -> {
            var5.add(var2x);
            if (var2x.getJoinCondition() != null) {
               var4.add(var2x.getJoinCondition());
            }

         });
      }

      this.allConditions = (Expression[])var4.toArray(new Expression[0]);
      this.allFilters = (TableFilter[])var5.toArray(new TableFilter[0]);
   }

   public PlanItem getItem(TableFilter var1) {
      return (PlanItem)this.planItems.get(var1);
   }

   public TableFilter[] getFilters() {
      return this.filters;
   }

   public void removeUnusableIndexConditions() {
      for(int var1 = 0; var1 < this.allFilters.length; ++var1) {
         TableFilter var2 = this.allFilters[var1];
         this.setEvaluatable(var2, true);
         if (var1 < this.allFilters.length - 1) {
            var2.optimizeFullCondition();
         }

         var2.removeUnusableIndexConditions();
      }

      for(TableFilter var4 : this.allFilters) {
         this.setEvaluatable(var4, false);
      }

   }

   public double calculateCost(SessionLocal var1, AllColumnsForPlan var2, boolean var3) {
      Trace var4 = var1.getTrace();
      if (var4.isDebugEnabled()) {
         var4.debug("Plan       : calculate cost for plan {0}", Arrays.toString(this.allFilters));
      }

      double var5 = (double)1.0F;
      boolean var7 = false;

      for(int var8 = 0; var8 < this.allFilters.length; ++var8) {
         TableFilter var9 = this.allFilters[var8];
         if (var4.isDebugEnabled()) {
            var4.debug("Plan       :   for table filter {0}", var9);
         }

         PlanItem var10 = var9.getBestPlanItem(var1, this.allFilters, var8, var2, var3);
         this.planItems.put(var9, var10);
         if (var4.isDebugEnabled()) {
            var4.debug("Plan       :   best plan item cost {0} index {1}", var10.cost, var10.getIndex().getPlanSQL());
         }

         var5 += var5 * var10.cost;
         this.setEvaluatable(var9, true);
         Expression var11 = var9.getJoinCondition();
         if (var11 != null && !var11.isEverything(ExpressionVisitor.EVALUATABLE_VISITOR)) {
            var7 = true;
            break;
         }
      }

      if (var7) {
         var5 = Double.POSITIVE_INFINITY;
      }

      if (var4.isDebugEnabled()) {
         var1.getTrace().debug("Plan       : plan cost {0}", var5);
      }

      for(TableFilter var15 : this.allFilters) {
         this.setEvaluatable(var15, false);
      }

      return var5;
   }

   private void setEvaluatable(TableFilter var1, boolean var2) {
      var1.setEvaluatable(var1, var2);

      for(Expression var6 : this.allConditions) {
         var6.setEvaluatable(var1, var2);
      }

   }
}
