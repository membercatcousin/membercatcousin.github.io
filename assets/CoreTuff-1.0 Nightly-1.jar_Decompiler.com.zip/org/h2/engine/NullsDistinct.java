package org.h2.engine;

import org.h2.util.HasSQL;

public enum NullsDistinct implements HasSQL {
   DISTINCT,
   ALL_DISTINCT,
   NOT_DISTINCT;

   public StringBuilder getSQL(StringBuilder var1, int var2) {
      var1.append("NULLS ");
      switch (this) {
         case DISTINCT:
            var1.append("DISTINCT");
            break;
         case ALL_DISTINCT:
            var1.append("ALL DISTINCT");
            break;
         case NOT_DISTINCT:
            var1.append("NOT DISTINCT");
      }

      return var1;
   }
}
