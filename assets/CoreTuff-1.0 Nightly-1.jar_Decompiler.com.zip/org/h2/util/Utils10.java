package org.h2.util;

import java.io.IOException;
import java.net.Socket;
import jdk.net.ExtendedSocketOptions;

public final class Utils10 {
   public static boolean getTcpQuickack(Socket var0) throws IOException {
      return (Boolean)var0.getOption(ExtendedSocketOptions.TCP_QUICKACK);
   }

   public static boolean setTcpQuickack(Socket var0, boolean var1) {
      try {
         var0.setOption(ExtendedSocketOptions.TCP_QUICKACK, var1);
         return true;
      } catch (Throwable var3) {
         return false;
      }
   }

   private Utils10() {
   }
}
