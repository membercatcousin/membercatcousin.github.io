package org.h2.index;

import java.util.ArrayList;
import java.util.Arrays;
import org.h2.command.query.AllColumnsForPlan;
import org.h2.constraint.Constraint;
import org.h2.engine.NullsDistinct;
import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.mode.DefaultNullOrdering;
import org.h2.result.Row;
import org.h2.result.RowFactory;
import org.h2.result.SearchRow;
import org.h2.result.SortOrder;
import org.h2.schema.SchemaObject;
import org.h2.table.Column;
import org.h2.table.IndexColumn;
import org.h2.table.Table;
import org.h2.table.TableFilter;
import org.h2.util.StringUtils;
import org.h2.value.CompareMode;
import org.h2.value.DataType;
import org.h2.value.Value;
import org.h2.value.ValueNull;

public abstract class Index extends SchemaObject {
   protected IndexColumn[] indexColumns;
   protected Column[] columns;
   protected int[] columnIds;
   protected final int uniqueColumnColumn;
   protected final Table table;
   protected final IndexType indexType;
   private final RowFactory rowFactory;
   private final RowFactory uniqueRowFactory;

   protected static void checkIndexColumnTypes(IndexColumn[] var0) {
      for(IndexColumn var4 : var0) {
         if (!DataType.isIndexable(var4.column.getType())) {
            throw DbException.getUnsupportedException("Index on column: " + var4.column.getCreateSQL());
         }
      }

   }

   protected Index(Table var1, int var2, String var3, IndexColumn[] var4, int var5, IndexType var6) {
      super(var1.getSchema(), var2, var3, 5);
      this.uniqueColumnColumn = var5;
      this.indexType = var6;
      this.table = var1;
      if (var4 != null) {
         this.indexColumns = var4;
         this.columns = new Column[var4.length];
         int var7 = this.columns.length;
         this.columnIds = new int[var7];

         for(int var8 = 0; var8 < var7; ++var8) {
            Column var9 = var4[var8].column;
            this.columns[var8] = var9;
            this.columnIds[var8] = var9.getColumnId();
         }
      }

      RowFactory var11 = this.database.getRowFactory();
      CompareMode var12 = this.database.getCompareMode();
      Column[] var13 = this.table.getColumns();
      this.rowFactory = var11.createRowFactory(this.database, var12, this.database, var13, var6.isScan() ? null : var4, true);
      RowFactory var10;
      if (var5 > 0) {
         if (var4 != null && var5 != var4.length) {
            var10 = var11.createRowFactory(this.database, var12, this.database, var13, (IndexColumn[])Arrays.copyOf(var4, var5), true);
         } else {
            var10 = this.rowFactory;
         }
      } else {
         var10 = null;
      }

      this.uniqueRowFactory = var10;
   }

   public final int getType() {
      return 1;
   }

   public void removeChildrenAndResources(SessionLocal var1) {
      this.table.removeIndex(this);
      this.remove(var1);
      this.database.removeMeta(var1, this.getId());
   }

   public String getCreateSQLForCopy(Table var1, String var2) {
      StringBuilder var3 = new StringBuilder("CREATE ");
      var3.append(this.indexType.getSQL(true));
      var3.append(' ');
      var3.append(var2);
      var3.append(" ON ");
      var1.getSQL(var3, 0);
      if (this.comment != null) {
         var3.append(" COMMENT ");
         StringUtils.quoteStringSQL(var3, this.comment);
      }

      return this.getColumnListSQL(var3, 0).toString();
   }

   private StringBuilder getColumnListSQL(StringBuilder var1, int var2) {
      var1.append('(');
      int var3 = this.indexColumns.length;
      if (this.uniqueColumnColumn > 0 && this.uniqueColumnColumn < var3) {
         IndexColumn.writeColumns(var1, this.indexColumns, 0, this.uniqueColumnColumn, var2).append(") INCLUDE(");
         IndexColumn.writeColumns(var1, this.indexColumns, this.uniqueColumnColumn, var3, var2);
      } else {
         IndexColumn.writeColumns(var1, this.indexColumns, 0, var3, var2);
      }

      return var1.append(')');
   }

   public String getCreateSQL() {
      return this.getCreateSQLForCopy(this.table, this.getSQL(0));
   }

   public String getPlanSQL() {
      return this.getSQL(11);
   }

   public abstract void close(SessionLocal var1);

   public abstract void add(SessionLocal var1, Row var2);

   public abstract void remove(SessionLocal var1, Row var2);

   public void update(SessionLocal var1, Row var2, Row var3) {
      this.remove(var1, var2);
      this.add(var1, var3);
   }

   public boolean isFindUsingFullTableScan() {
      return false;
   }

   public abstract Cursor find(SessionLocal var1, SearchRow var2, SearchRow var3, boolean var4);

   public abstract double getCost(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6, boolean var7);

   public abstract void remove(SessionLocal var1);

   public abstract void truncate(SessionLocal var1);

   public boolean canGetFirstOrLast() {
      return false;
   }

   public boolean canFindNext() {
      return false;
   }

   public Cursor findNext(SessionLocal var1, SearchRow var2, SearchRow var3) {
      throw DbException.getInternalError(this.toString());
   }

   public Cursor findFirstOrLast(SessionLocal var1, boolean var2) {
      throw DbException.getInternalError(this.toString());
   }

   public abstract boolean needRebuild();

   public abstract long getRowCount(SessionLocal var1);

   public abstract long getRowCountApproximation(SessionLocal var1);

   public long getDiskSpaceUsed(boolean var1) {
      return 0L;
   }

   public final int compareRows(SearchRow var1, SearchRow var2) {
      if (var1 == var2) {
         return 0;
      } else {
         int var3 = 0;

         for(int var4 = this.indexColumns.length; var3 < var4; ++var3) {
            int var5 = this.columnIds[var3];
            Value var6 = var1.getValue(var5);
            Value var7 = var2.getValue(var5);
            if (var6 == null || var7 == null) {
               return 0;
            }

            int var8 = this.compareValues(var6, var7, this.indexColumns[var3].sortType);
            if (var8 != 0) {
               return var8;
            }
         }

         return 0;
      }
   }

   private int compareValues(Value var1, Value var2, int var3) {
      if (var1 == var2) {
         return 0;
      } else {
         boolean var4 = var1 == ValueNull.INSTANCE;
         if (!var4 && var2 != ValueNull.INSTANCE) {
            int var5 = this.table.compareValues(this.database, var1, var2);
            if ((var3 & 1) != 0) {
               var5 = -var5;
            }

            return var5;
         } else {
            return this.table.getDatabase().getDefaultNullOrdering().compareNull(var4, var3);
         }
      }
   }

   public int getColumnIndex(Column var1) {
      int var2 = 0;

      for(int var3 = this.columns.length; var2 < var3; ++var2) {
         if (this.columns[var2].equals(var1)) {
            return var2;
         }
      }

      return -1;
   }

   public boolean isFirstColumn(Column var1) {
      return var1.equals(this.columns[0]);
   }

   public final IndexColumn[] getIndexColumns() {
      return this.indexColumns;
   }

   public final Column[] getColumns() {
      return this.columns;
   }

   public final int getUniqueColumnCount() {
      return this.uniqueColumnColumn;
   }

   public final IndexType getIndexType() {
      return this.indexType;
   }

   public Table getTable() {
      return this.table;
   }

   public Row getRow(SessionLocal var1, long var2) {
      throw DbException.getUnsupportedException(this.toString());
   }

   public boolean isRowIdIndex() {
      return false;
   }

   public boolean canScan() {
      return true;
   }

   protected DbException getDuplicateKeyException(String var1) {
      StringBuilder var2 = new StringBuilder(128);

      for(Constraint var4 : this.table.getConstraints()) {
         if (var4.usesIndex(this) && var4.getConstraintType().isUnique()) {
            var4.getSQL(var2, 3).append(" INDEX ");
            break;
         }
      }

      this.getSQL(var2, 3).append(" ON ");
      this.table.getSQL(var2, 3);
      this.getColumnListSQL(var2, 3);
      if (var1 != null) {
         var2.append(" VALUES ").append(var1);
      }

      DbException var5 = DbException.get(23505, (String)var2.toString());
      var5.setSource(this);
      return var5;
   }

   protected StringBuilder getDuplicatePrimaryKeyMessage(int var1) {
      StringBuilder var2 = new StringBuilder(64);

      for(Constraint var4 : this.table.getConstraints()) {
         if (var4.getConstraintType() == Constraint.Type.PRIMARY_KEY) {
            var4.getSQL(var2, 3).append(' ');
            break;
         }
      }

      this.table.getSQL(var2.append("PRIMARY KEY ON "), 3);
      if (var1 >= 0 && var1 < this.indexColumns.length) {
         var2.append('(');
         this.indexColumns[var1].getSQL(var2, 3).append(')');
      }

      return var2;
   }

   protected final long getCostRangeIndex(int[] var1, long var2, TableFilter[] var4, int var5, SortOrder var6, boolean var7, AllColumnsForPlan var8, boolean var9) {
      var2 += 1000L;
      int var10 = 0;
      long var11 = var2;
      if (var1 != null) {
         int var13 = 0;
         int var14 = this.columns.length;

         boolean var15;
         long var19;
         for(var15 = false; var13 < var14; var11 = 2L + Math.max(var2 / var19, 1L)) {
            Column var16 = this.columns[var13++];
            int var17 = var16.getColumnId();
            int var18 = var1[var17];
            if ((var18 & 1) != 1) {
               if ((var18 & 6) == 6) {
                  var11 = 2L + var11 / 4L;
                  var15 = true;
               } else if ((var18 & 2) == 2) {
                  var11 = 2L + var11 / 3L;
                  var15 = true;
               } else if ((var18 & 4) == 4) {
                  var11 /= 3L;
                  var15 = true;
               } else if ((var18 & 16) == 16) {
                  var11 = 2L + var11 / 4L;
                  var15 = true;
               } else if (var18 == 0) {
                  --var13;
               }
               break;
            }

            if (var13 > 0 && var13 == this.uniqueColumnColumn) {
               var11 = 3L;
               break;
            }

            var10 = 100 - (100 - var10) * (100 - var16.getSelectivity()) / 100;
            var19 = var2 * (long)var10 / 100L;
            if (var19 <= 0L) {
               var19 = 1L;
            }
         }

         if (var15) {
            while(var13 < var14 && var1[this.columns[var13].getColumnId()] != 0) {
               ++var13;
               --var11;
            }
         }

         var11 += (long)(var14 - var13);
      }

      long var28 = 0L;
      if (var6 != null) {
         var28 = 100L + var2 / 10L;
      }

      if (var6 != null && !var7 && var4 != null && var5 == 0) {
         int var29 = 0;
         int[] var31 = var6.getSortTypesWithNullOrdering();
         int var34 = var31.length;
         TableFilter var36 = var4[0];
         DefaultNullOrdering var38 = this.getDatabase().getDefaultNullOrdering();
         boolean var20 = false;

         for(int var21 = 0; var21 < var34 && var21 < this.indexColumns.length; ++var21) {
            Column var22 = var6.getColumn(var21, var36);
            if (var22 == null) {
               break;
            }

            IndexColumn var23 = this.indexColumns[var21];
            if (!var22.equals(var23.column)) {
               break;
            }

            boolean var24 = false;
            if (var22.isNullable()) {
               int var25 = var38.addExplicitNullOrdering(var23.sortType);
               int var26 = var31[var21];
               if (var21 == 0) {
                  if (var25 != var26) {
                     if (var25 == SortOrder.inverse(var26)) {
                        var20 = true;
                     } else {
                        var24 = true;
                     }
                  }
               } else if (var25 != (var20 ? SortOrder.inverse(var26) : var26)) {
                  var24 = true;
               }
            } else {
               boolean var45 = (var23.sortType & 1) != (var31[var21] & 1);
               if (var21 == 0) {
                  var20 = var45;
               } else {
                  var24 = var45 != var20;
               }
            }

            if (var24) {
               break;
            }

            ++var29;
         }

         if (var29 > 0) {
            var28 = (long)(100 - var29);
         }
      }

      boolean var30;
      if (var9 && !var7 && var8 != null) {
         var30 = false;
         ArrayList var32 = var8.get(this.getTable());
         if (var32 != null) {
            int var35 = this.table.getMainIndexColumn();

            label138:
            for(Column var39 : var32) {
               int var40 = var39.getColumnId();
               if (var40 != -1 && var40 != var35) {
                  for(Column var44 : this.columns) {
                     if (var39 == var44) {
                        continue label138;
                     }
                  }

                  var30 = true;
                  break;
               }
            }
         }
      } else {
         var30 = true;
      }

      long var33;
      if (!var9) {
         var33 = var11 + var28;
      } else if (var7) {
         var33 = var11 + var28 + 20L;
      } else if (var30) {
         var33 = var11 + var11 + var28 + 20L;
      } else {
         var33 = var11 + var28 + (long)this.columns.length;
      }

      return var33;
   }

   public final boolean needsUniqueCheck(SearchRow var1) {
      NullsDistinct var2 = this.indexType.getEffectiveNullsDistinct();
      return var2 != null && (var2 == NullsDistinct.NOT_DISTINCT || this.needsUniqueCheck(var1, var2 == NullsDistinct.DISTINCT));
   }

   private boolean needsUniqueCheck(SearchRow var1, boolean var2) {
      if (var2) {
         for(int var5 = 0; var5 < this.uniqueColumnColumn; ++var5) {
            int var6 = this.columnIds[var5];
            if (var1.getValue(var6) == ValueNull.INSTANCE) {
               return false;
            }
         }

         return true;
      } else {
         for(int var3 = 0; var3 < this.uniqueColumnColumn; ++var3) {
            int var4 = this.columnIds[var3];
            if (var1.getValue(var4) != ValueNull.INSTANCE) {
               return true;
            }
         }

         return false;
      }
   }

   public RowFactory getRowFactory() {
      return this.rowFactory;
   }

   public RowFactory getUniqueRowFactory() {
      return this.uniqueRowFactory;
   }
}
