package org.h2.table;

import java.util.HashSet;
import java.util.List;
import org.h2.command.query.AllColumnsForPlan;
import org.h2.command.query.Query;
import org.h2.engine.DbObject;
import org.h2.engine.SessionLocal;
import org.h2.index.Index;
import org.h2.index.IndexType;
import org.h2.message.DbException;
import org.h2.result.Row;
import org.h2.result.SortOrder;
import org.h2.schema.Schema;
import org.h2.util.StringUtils;

public class MaterializedView extends Table {
   private Table table;
   private String querySQL;
   private Query query;

   public MaterializedView(Schema var1, int var2, String var3, Table var4, Query var5, String var6) {
      super(var1, var2, var3, false, true);
      this.table = var4;
      this.query = var5;
      this.querySQL = var6;
   }

   public void replace(Table var1, Query var2, String var3) {
      this.table = var1;
      this.query = var2;
      this.querySQL = var3;
   }

   public Table getUnderlyingTable() {
      return this.table;
   }

   public Query getSelect() {
      return this.query;
   }

   public final void close(SessionLocal var1) {
      this.table.close(var1);
   }

   public final Index addIndex(SessionLocal var1, String var2, int var3, IndexColumn[] var4, int var5, IndexType var6, boolean var7, String var8) {
      return this.table.addIndex(var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public final boolean isView() {
      return true;
   }

   public final PlanItem getBestPlanItem(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6, boolean var7) {
      return this.table.getBestPlanItem(var1, var2, var3, var4, var5, var6, var7);
   }

   public boolean isQueryComparable() {
      return this.table.isQueryComparable();
   }

   public final boolean isInsertable() {
      return false;
   }

   public final void removeRow(SessionLocal var1, Row var2) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".removeRow");
   }

   public final void addRow(SessionLocal var1, Row var2) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".addRow");
   }

   public final void checkSupportAlter() {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".checkSupportAlter");
   }

   public final long truncate(SessionLocal var1) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".truncate");
   }

   public final long getRowCount(SessionLocal var1) {
      return this.table.getRowCount(var1);
   }

   public final boolean canGetRowCount(SessionLocal var1) {
      return this.table.canGetRowCount(var1);
   }

   public final long getRowCountApproximation(SessionLocal var1) {
      return this.table.getRowCountApproximation(var1);
   }

   public final boolean canReference() {
      return false;
   }

   public final List<Index> getIndexes() {
      return this.table.getIndexes();
   }

   public final Index getScanIndex(SessionLocal var1) {
      return this.getBestPlanItem(var1, (int[])null, (TableFilter[])null, -1, (SortOrder)null, (AllColumnsForPlan)null, true).getIndex();
   }

   public Index getScanIndex(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6) {
      return this.getBestPlanItem(var1, var2, var3, var4, var5, var6, true).getIndex();
   }

   public boolean isDeterministic() {
      return this.table.isDeterministic();
   }

   public final void addDependencies(HashSet<DbObject> var1) {
      this.table.addDependencies(var1);
   }

   public String getDropSQL() {
      return this.getSQL(new StringBuilder("DROP MATERIALIZED VIEW IF EXISTS "), 0).toString();
   }

   public String getCreateSQLForCopy(Table var1, String var2) {
      return this.getCreateSQL(false, true, var2);
   }

   public String getCreateSQL() {
      return this.getCreateSQL(false, true);
   }

   public String getCreateSQL(boolean var1, boolean var2) {
      return this.getCreateSQL(var1, var2, this.getSQL(0));
   }

   private String getCreateSQL(boolean var1, boolean var2, String var3) {
      StringBuilder var4 = new StringBuilder("CREATE ");
      if (var1) {
         var4.append("OR REPLACE ");
      }

      if (var2) {
         var4.append("FORCE ");
      }

      var4.append("MATERIALIZED VIEW ");
      var4.append(var3);
      if (this.comment != null) {
         var4.append(" COMMENT ");
         StringUtils.quoteStringSQL(var4, this.comment);
      }

      return var4.append(" AS\n").append(this.querySQL).toString();
   }

   public boolean canDrop() {
      return true;
   }

   public TableType getTableType() {
      return TableType.MATERIALIZED_VIEW;
   }

   public void removeChildrenAndResources(SessionLocal var1) {
      this.table.removeChildrenAndResources(var1);
      this.database.removeMeta(var1, this.getId());
      this.querySQL = null;
      this.invalidate();
   }

   public StringBuilder getSQL(StringBuilder var1, int var2) {
      if (this.isTemporary() && this.querySQL != null) {
         var1.append("(\n");
         return StringUtils.indent(var1, this.querySQL, 4, true).append(')');
      } else {
         return super.getSQL(var1, var2);
      }
   }

   public String getQuerySQL() {
      return this.querySQL;
   }

   public long getMaxDataModificationId() {
      return this.table.getMaxDataModificationId();
   }
}
