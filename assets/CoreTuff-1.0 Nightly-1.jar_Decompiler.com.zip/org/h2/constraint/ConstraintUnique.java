package org.h2.constraint;

import java.util.ArrayList;
import java.util.HashSet;
import org.h2.engine.NullsDistinct;
import org.h2.engine.SessionLocal;
import org.h2.index.Index;
import org.h2.result.Row;
import org.h2.schema.Schema;
import org.h2.table.Column;
import org.h2.table.IndexColumn;
import org.h2.table.Table;
import org.h2.util.StringUtils;

public class ConstraintUnique extends Constraint {
   private Index index;
   private boolean indexOwner;
   private IndexColumn[] columns;
   private final boolean primaryKey;
   private final NullsDistinct nullsDistinct;

   public ConstraintUnique(Schema var1, int var2, String var3, Table var4, boolean var5, IndexColumn[] var6, Index var7, boolean var8, NullsDistinct var9) {
      super(var1, var2, var3, var4);
      this.primaryKey = var5;
      this.columns = var6;
      this.index = var7;
      this.indexOwner = var8;
      this.nullsDistinct = var9;
   }

   public Constraint.Type getConstraintType() {
      return this.primaryKey ? Constraint.Type.PRIMARY_KEY : Constraint.Type.UNIQUE;
   }

   public String getCreateSQLForCopy(Table var1, String var2) {
      return this.getCreateSQLForCopy(var1, var2, true);
   }

   private String getCreateSQLForCopy(Table var1, String var2, boolean var3) {
      StringBuilder var4 = new StringBuilder("ALTER TABLE ");
      var1.getSQL(var4, 0).append(" ADD CONSTRAINT ");
      var4.append(var2);
      if (this.comment != null) {
         var4.append(" COMMENT ");
         StringUtils.quoteStringSQL(var4, this.comment);
      }

      var4.append(' ').append(this.getConstraintType().getSqlName());
      if (!this.primaryKey) {
         this.nullsDistinct.getSQL(var4.append(' '), 0).append(' ');
      }

      IndexColumn.writeColumns(var4.append('('), this.columns, 0).append(')');
      if (var3 && this.indexOwner && var1 == this.table) {
         var4.append(" INDEX ");
         this.index.getSQL(var4, 0);
      }

      return var4.toString();
   }

   public String getCreateSQLWithoutIndexes() {
      return this.getCreateSQLForCopy(this.table, this.getSQL(0), false);
   }

   public String getCreateSQL() {
      return this.getCreateSQLForCopy(this.table, this.getSQL(0));
   }

   public IndexColumn[] getColumns() {
      return this.columns;
   }

   public void removeChildrenAndResources(SessionLocal var1) {
      ArrayList var2 = new ArrayList();

      for(Constraint var4 : this.table.getConstraints()) {
         if (var4.getReferencedConstraint() == this) {
            var2.add(var4);
         }
      }

      for(Constraint var6 : var2) {
         this.database.removeSchemaObject(var1, var6);
      }

      this.table.removeConstraint(this);
      if (this.indexOwner) {
         this.table.removeIndexOrTransferOwnership(var1, this.index);
      }

      this.database.removeMeta(var1, this.getId());
      this.index = null;
      this.columns = null;
      this.table = null;
      this.invalidate();
   }

   public void checkRow(SessionLocal var1, Table var2, Row var3, Row var4) {
   }

   public boolean usesIndex(Index var1) {
      return var1 == this.index;
   }

   public void setIndexOwner(Index var1) {
      this.indexOwner = true;
   }

   public HashSet<Column> getReferencedColumns(Table var1) {
      HashSet var2 = new HashSet();

      for(IndexColumn var6 : this.columns) {
         var2.add(var6.column);
      }

      return var2;
   }

   public boolean isBefore() {
      return true;
   }

   public void checkExistingData(SessionLocal var1) {
   }

   public Index getIndex() {
      return this.index;
   }

   public void rebuild() {
   }

   public NullsDistinct getNullsDistinct() {
      return this.nullsDistinct;
   }
}
