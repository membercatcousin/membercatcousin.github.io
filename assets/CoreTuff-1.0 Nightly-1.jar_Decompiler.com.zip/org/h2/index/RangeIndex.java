package org.h2.index;

import org.h2.command.query.AllColumnsForPlan;
import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.result.Row;
import org.h2.result.SearchRow;
import org.h2.result.SortOrder;
import org.h2.table.IndexColumn;
import org.h2.table.RangeTable;
import org.h2.table.TableFilter;
import org.h2.value.Value;
import org.h2.value.ValueBigint;

public class RangeIndex extends VirtualTableIndex {
   private final RangeTable rangeTable;

   public RangeIndex(RangeTable var1, IndexColumn[] var2) {
      super(var1, "RANGE_INDEX", var2);
      this.rangeTable = var1;
   }

   public Cursor find(SessionLocal var1, SearchRow var2, SearchRow var3, boolean var4) {
      assert !var4;

      long var5 = this.rangeTable.getMin(var1);
      long var7 = this.rangeTable.getMax(var1);
      long var9 = this.rangeTable.getStep(var1);
      if (var9 == 0L) {
         throw DbException.get(90142);
      } else {
         if (var2 != null) {
            try {
               long var11 = var2.getValue(0).getLong();
               if (var9 > 0L) {
                  if (var11 > var5) {
                     var5 += (var11 - var5 + var9 - 1L) / var9 * var9;
                  }
               } else if (var11 > var7) {
                  var7 = var11;
               }
            } catch (DbException var14) {
            }
         }

         if (var3 != null) {
            try {
               long var15 = var3.getValue(0).getLong();
               if (var9 > 0L) {
                  if (var15 < var7) {
                     var7 = var15;
                  }
               } else if (var15 < var5) {
                  var5 -= (var5 - var15 - var9 - 1L) / var9 * var9;
               }
            } catch (DbException var13) {
            }
         }

         return new RangeCursor(var5, var7, var9);
      }
   }

   public double getCost(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6, boolean var7) {
      return (double)1.0F;
   }

   public String getCreateSQL() {
      return null;
   }

   public boolean canGetFirstOrLast() {
      return true;
   }

   public Cursor findFirstOrLast(SessionLocal var1, boolean var2) {
      long var3 = this.rangeTable.getMin(var1);
      long var5 = this.rangeTable.getMax(var1);
      long var7 = this.rangeTable.getStep(var1);
      if (var7 == 0L) {
         throw DbException.get(90142);
      } else {
         SingleRowCursor var10000;
         label44: {
            if (var7 > 0L) {
               if (var3 > var5) {
                  break label44;
               }
            } else if (var3 < var5) {
               break label44;
            }

            var10000 = new SingleRowCursor(Row.get(new Value[]{ValueBigint.get(var2 ^ var3 >= var5 ? var3 : var5)}, 1));
            return var10000;
         }

         var10000 = SingleRowCursor.EMPTY;
         return var10000;
      }
   }

   public String getPlanSQL() {
      return "range index";
   }
}
