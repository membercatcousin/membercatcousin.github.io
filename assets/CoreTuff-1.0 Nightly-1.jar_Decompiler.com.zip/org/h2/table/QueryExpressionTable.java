package org.h2.table;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import org.h2.command.QueryScope;
import org.h2.command.query.AllColumnsForPlan;
import org.h2.command.query.Query;
import org.h2.engine.DbObject;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.Parameter;
import org.h2.index.Index;
import org.h2.index.IndexType;
import org.h2.index.QueryExpressionIndex;
import org.h2.message.DbException;
import org.h2.result.Row;
import org.h2.result.SortOrder;
import org.h2.schema.Schema;
import org.h2.value.TypeInfo;

public abstract class QueryExpressionTable extends Table {
   private static final long ROW_COUNT_APPROXIMATION = 100L;
   Query viewQuery;
   ArrayList<Table> tables;
   private long lastModificationCheck;
   private long maxDataModificationId;

   public static List<Column> createQueryColumnTemplateList(String[] var0, Query var1, boolean var2) {
      ArrayList var3 = new ArrayList();
      var1.prepare();
      SessionLocal var4 = var1.getSession();
      ArrayList var5 = var1.getExpressions();

      for(int var6 = 0; var6 < var5.size(); ++var6) {
         Expression var7 = (Expression)var5.get(var6);
         String var8 = var0 != null && var0.length > var6 ? var0[var6] : var7.getColumnNameForView(var4, var6, var2);
         var3.add(new Column(var8, var7.getType()));
      }

      return var3;
   }

   QueryExpressionTable(Schema var1, int var2, String var3) {
      super(var1, var2, var3, false, true);
   }

   Column[] initColumns(SessionLocal var1, Column[] var2, Query var3, boolean var4, boolean var5) {
      ArrayList var6 = var3.getExpressions();
      int var7 = var3.getColumnCount();
      ArrayList var8 = new ArrayList(var7);

      for(int var9 = 0; var9 < var7; ++var9) {
         Expression var10 = (Expression)var6.get(var9);
         String var11 = null;
         TypeInfo var12 = TypeInfo.TYPE_UNKNOWN;
         if (var2 != null && var2.length > var9) {
            var11 = var2[var9].getName();
            var12 = var2[var9].getType();
         }

         if (var11 == null) {
            var11 = var4 ? var10.getAlias(var1, var9) : var10.getColumnNameForView(var1, var9, var5);
         }

         if (var12.getValueType() == -1) {
            var12 = var10.getType();
         }

         var8.add(new Column(var11, var12, this, var9));
      }

      return (Column[])var8.toArray(new Column[0]);
   }

   public final Query getQuery() {
      return this.viewQuery;
   }

   public abstract Query getTopQuery();

   public final void close(SessionLocal var1) {
   }

   public final Index addIndex(SessionLocal var1, String var2, int var3, IndexColumn[] var4, int var5, IndexType var6, boolean var7, String var8) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".addIndex");
   }

   public final boolean isView() {
      return true;
   }

   public final PlanItem getBestPlanItem(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6, boolean var7) {
      CacheKey var8 = new CacheKey(var2, this);
      Map var9 = var1.getViewIndexCache(this.getTableType() == null);
      QueryExpressionIndex var10 = (QueryExpressionIndex)var9.get(var8);
      if (var10 == null || var10.isExpired()) {
         var10 = this.createIndex(var1, var2);
         var9.put(var8, var10);
      }

      PlanItem var11 = new PlanItem();
      var11.cost = var10.getCost(var1, var2, var3, var4, var5, var6, var7);
      var11.setIndex(var10);
      return var11;
   }

   abstract QueryExpressionIndex createIndex(SessionLocal var1, int[] var2);

   public boolean isQueryComparable() {
      for(Table var2 : this.tables) {
         if (!var2.isQueryComparable()) {
            return false;
         }
      }

      return true;
   }

   public final boolean isInsertable() {
      return false;
   }

   public final void removeRow(SessionLocal var1, Row var2) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".removeRow");
   }

   public final void addRow(SessionLocal var1, Row var2) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".addRow");
   }

   public final void checkSupportAlter() {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".checkSupportAlter");
   }

   public final long truncate(SessionLocal var1) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".truncate");
   }

   public final long getRowCount(SessionLocal var1) {
      throw DbException.getInternalError(this.toString());
   }

   public final boolean canGetRowCount(SessionLocal var1) {
      return false;
   }

   public final long getRowCountApproximation(SessionLocal var1) {
      return 100L;
   }

   public final int getParameterOffset(ArrayList<Parameter> var1) {
      Query var2 = this.getTopQuery();
      int var3 = var2 == null ? 0 : Parameter.getMaxIndex(var2.getParameters());
      if (var1 != null) {
         var3 = Math.max(var3, Parameter.getMaxIndex(var1));
      }

      return var3;
   }

   public final boolean canReference() {
      return false;
   }

   public final List<Index> getIndexes() {
      return List.of();
   }

   public long getMaxDataModificationId() {
      long var1 = this.database.getModificationDataId();
      if (var1 > this.lastModificationCheck && this.maxDataModificationId <= var1) {
         this.maxDataModificationId = this.viewQuery.getMaxDataModificationId();
         this.lastModificationCheck = var1;
      }

      return this.maxDataModificationId;
   }

   public final Index getScanIndex(SessionLocal var1) {
      return this.getBestPlanItem(var1, (int[])null, (TableFilter[])null, -1, (SortOrder)null, (AllColumnsForPlan)null, true).getIndex();
   }

   public Index getScanIndex(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6) {
      return this.getBestPlanItem(var1, var2, var3, var4, var5, var6, true).getIndex();
   }

   public boolean isDeterministic() {
      return this.viewQuery.isEverything(ExpressionVisitor.DETERMINISTIC_VISITOR);
   }

   public final void addDependencies(HashSet<DbObject> var1) {
      super.addDependencies(var1);
      if (this.tables != null) {
         for(Table var3 : this.tables) {
            if (TableType.VIEW != var3.getTableType()) {
               var3.addDependencies(var1);
            }
         }
      }

   }

   public abstract QueryScope getQueryScope();

   static final class CacheKey {
      private final int[] masks;
      private final QueryExpressionTable queryExpressionTable;

      CacheKey(int[] var1, QueryExpressionTable var2) {
         this.masks = var1;
         this.queryExpressionTable = var2;
      }

      public int hashCode() {
         int var2 = 1;
         var2 = 31 * var2 + Arrays.hashCode(this.masks);
         var2 = 31 * var2 + this.queryExpressionTable.hashCode();
         return var2;
      }

      public boolean equals(Object var1) {
         if (this == var1) {
            return true;
         } else if (var1 == null) {
            return false;
         } else if (this.getClass() != var1.getClass()) {
            return false;
         } else {
            CacheKey var2 = (CacheKey)var1;
            return this.queryExpressionTable != var2.queryExpressionTable ? false : Arrays.equals(this.masks, var2.masks);
         }
      }
   }
}
