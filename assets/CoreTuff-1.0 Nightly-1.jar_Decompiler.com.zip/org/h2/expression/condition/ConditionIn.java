package org.h2.expression.condition;

import java.util.ArrayList;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionColumn;
import org.h2.expression.ExpressionList;
import org.h2.expression.ExpressionVisitor;
import org.h2.index.IndexCondition;
import org.h2.table.Column;
import org.h2.table.TableFilter;
import org.h2.value.TypeInfo;
import org.h2.value.Value;

abstract class ConditionIn extends Condition {
   Expression left;
   final boolean not;
   final boolean whenOperand;
   final ArrayList<Expression> valueList;

   ConditionIn(Expression var1, boolean var2, boolean var3, ArrayList<Expression> var4) {
      this.left = var1;
      this.not = var2;
      this.whenOperand = var3;
      this.valueList = var4;
   }

   public final Value getValue(SessionLocal var1) {
      return this.getValue(var1, this.left.getValue(var1));
   }

   public final boolean getWhenValue(SessionLocal var1, Value var2) {
      return !this.whenOperand ? super.getWhenValue(var1, var2) : this.getValue(var1, var2).isTrue();
   }

   abstract Value getValue(SessionLocal var1, Value var2);

   public final boolean isWhenConditionOperand() {
      return this.whenOperand;
   }

   public final void createIndexConditions(SessionLocal var1, TableFilter var2) {
      if (!this.not && !this.whenOperand && var1.getDatabase().getSettings().optimizeInList) {
         if (this.left instanceof ExpressionColumn) {
            ExpressionColumn var3 = (ExpressionColumn)this.left;
            if (var2 == var3.getTableFilter()) {
               this.createIndexConditions(var2, var3, this.valueList);
            }
         } else if (this.left instanceof ExpressionList) {
            ExpressionList var4 = (ExpressionList)this.left;
            if (!var4.isArray()) {
               this.createCompoundIndexCondition(var2, var4);
               this.createUniqueIndexConditions(var2, var4);
            }
         }

      }
   }

   private void createCompoundIndexCondition(TableFilter var1, ExpressionList var2) {
      int var3 = var2.getSubexpressionCount();
      Column[] var4 = new Column[var3];

      for(int var5 = 0; var5 < var3; ++var5) {
         Expression var6 = var2.getSubexpression(var5);
         if (!(var6 instanceof ExpressionColumn)) {
            return;
         }

         ExpressionColumn var7 = (ExpressionColumn)var6;
         if (var1 != var7.getTableFilter()) {
            return;
         }

         var4[var5] = var7.getColumn();
      }

      TypeInfo var9 = this.left.getType();
      ExpressionVisitor var10 = ExpressionVisitor.getNotFromResolverVisitor(var1);

      for(Expression var8 : this.valueList) {
         if (!var8.isEverything(var10) || !TypeInfo.haveSameOrdering(var9, TypeInfo.getHigherType(var9, var8.getType()))) {
            return;
         }
      }

      var1.addIndexCondition(IndexCondition.getCompoundInList(var4, this.valueList));
   }

   abstract void createUniqueIndexConditions(TableFilter var1, ExpressionList var2);

   abstract void createIndexConditions(TableFilter var1, ExpressionColumn var2, ArrayList<Expression> var3);

   public final boolean needParentheses() {
      return true;
   }

   public final StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      return this.getWhenSQL(this.left.getSQL(var1, var2, 0), var2);
   }

   public final StringBuilder getWhenSQL(StringBuilder var1, int var2) {
      if (this.not) {
         var1.append(" NOT");
      }

      return writeExpressions(var1.append(" IN("), this.valueList, var2).append(')');
   }

   public final int getSubexpressionCount() {
      return 1 + this.valueList.size();
   }

   public final Expression getSubexpression(int var1) {
      if (var1 == 0) {
         return this.left;
      } else if (var1 > 0 && var1 <= this.valueList.size()) {
         return (Expression)this.valueList.get(var1 - 1);
      } else {
         throw new IndexOutOfBoundsException();
      }
   }
}
