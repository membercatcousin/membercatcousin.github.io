package org.h2.tools;

import java.util.Locale;

public enum CompressionType {
   NONE,
   GZIP,
   ZIP,
   BZIP2,
   KANZI,
   DEFLATE,
   LZF;

   public static CompressionType from(String var0) {
      return var0 != null && !var0.isEmpty() ? (CompressionType)Enum.valueOf(CompressionType.class, var0.toUpperCase(Locale.ENGLISH)) : NONE;
   }
}
