package org.h2.expression.function;

import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.TypedValueExpression;
import org.h2.message.DbException;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueNull;

public final class CoalesceFunction extends FunctionN {
   public static final int COALESCE = 0;
   public static final int GREATEST = 1;
   public static final int LEAST = 2;
   private static final String[] NAMES = new String[]{"COALESCE", "GREATEST", "LEAST"};
   private final int function;
   private boolean ignoreNulls;

   public CoalesceFunction(int var1) {
      this(var1);
   }

   public CoalesceFunction(int var1, Expression... var2) {
      super(var2);
      this.function = var1;
   }

   public void setIgnoreNulls(boolean var1) {
      this.ignoreNulls = var1;
   }

   public Value getValue(SessionLocal var1) {
      Object var2;
      switch (this.function) {
         case 0:
            var2 = ValueNull.INSTANCE;
            int var3 = 0;

            for(int var4 = this.args.length; var3 < var4; ++var3) {
               Value var5 = this.args[var3].getValue(var1);
               if (var5 != ValueNull.INSTANCE) {
                  var2 = var5.convertTo(this.type, var1);
                  return (Value)var2;
               }
            }
            break;
         case 1:
         case 2:
            var2 = this.greatestOrLeast(var1);
            break;
         default:
            throw DbException.getInternalError("function=" + this.function);
      }

      return (Value)var2;
   }

   private Value greatestOrLeast(SessionLocal var1) {
      Object var2 = ValueNull.INSTANCE;
      Value var3 = null;
      int var4 = 0;

      for(int var5 = this.args.length; var4 < var5; ++var4) {
         Value var6 = this.args[var4].getValue(var1);
         if (var6 != ValueNull.INSTANCE) {
            var6 = var6.convertTo(this.type, var1);
            if (var2 == ValueNull.INSTANCE) {
               if (var3 == null) {
                  var2 = var6;
               } else {
                  int var7 = var1.compareWithNull(var3, var6, false);
                  if (var7 == Integer.MIN_VALUE) {
                     var3 = getWithNull(var3, var6);
                  } else if (this.test(var7)) {
                     var2 = var6;
                     var3 = null;
                  }
               }
            } else {
               int var9 = var1.compareWithNull((Value)var2, var6, false);
               if (var9 == Integer.MIN_VALUE) {
                  if (var4 + 1 == var5) {
                     return ValueNull.INSTANCE;
                  }

                  var3 = getWithNull((Value)var2, var6);
                  var2 = ValueNull.INSTANCE;
               } else if (this.test(var9)) {
                  var2 = var6;
               }
            }
         } else if (!this.ignoreNulls) {
            return ValueNull.INSTANCE;
         }
      }

      return (Value)var2;
   }

   private static Value getWithNull(Value var0, Value var1) {
      Value var2 = var0.getValueWithFirstNull(var1);
      return var2 != null ? var2 : var0;
   }

   private boolean test(int var1) {
      return this.function == 1 ? var1 < 0 : var1 > 0;
   }

   public Expression optimize(SessionLocal var1) {
      boolean var2 = this.optimizeArguments(var1, true);
      this.type = TypeInfo.getHigherType(this.args);
      if (this.type.getValueType() <= 0) {
         this.type = TypeInfo.TYPE_VARCHAR;
      }

      return (Expression)(var2 ? TypedValueExpression.getTypedIfNull(this.getValue(var1), this.type) : this);
   }

   public String getName() {
      return NAMES[this.function];
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      super.getUnenclosedSQL(var1, var2);
      if (this.function == 1 || this.function == 2) {
         var1.append(this.ignoreNulls ? " IGNORE NULLS" : " RESPECT NULLS");
      }

      return var1;
   }
}
