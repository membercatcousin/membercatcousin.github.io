package org.h2.expression;

import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.mvstore.db.Store;
import org.h2.util.json.JSONArray;
import org.h2.util.json.JSONValue;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueArray;
import org.h2.value.ValueJson;
import org.h2.value.ValueNull;

public final class ArrayElementReference extends Operation2 {
   public ArrayElementReference(Expression var1, Expression var2) {
      super(var1, var2);
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      this.left.getSQL(var1, var2, 0).append('[');
      return this.right.getUnenclosedSQL(var1, var2).append(']');
   }

   public Value getValue(SessionLocal var1) {
      Value var2 = this.left.getValue(var1);
      Value var3 = this.right.getValue(var1);
      if (var2 != ValueNull.INSTANCE && var3 != ValueNull.INSTANCE) {
         int var4 = var3.getInt();
         if (this.left.getType().getValueType() == 40) {
            Value[] var7 = ((ValueArray)var2).getList();
            int var8 = var7.length;
            if (var4 >= 1 && var4 <= var8) {
               return var7[var4 - 1];
            }

            throw DbException.get(22034, (String[])(Integer.toString(var4), "1.." + var8));
         }

         JSONValue var5 = var2.convertToAnyJson().getDecomposition();
         if (var5 instanceof JSONArray) {
            JSONValue var6 = ((JSONArray)var5).getElement(var4 - 1);
            if (var6 != null) {
               return ValueJson.fromJson(var6);
            }
         }
      }

      return ValueNull.INSTANCE;
   }

   public Expression optimize(SessionLocal var1) {
      this.left = this.left.optimize(var1);
      this.right = this.right.optimize(var1);
      TypeInfo var2 = this.left.getType();
      switch (var2.getValueType()) {
         case 0:
            return ValueExpression.NULL;
         case 38:
            this.type = TypeInfo.TYPE_JSON;
            if (this.left.isConstant() && this.right.isConstant()) {
               return TypedValueExpression.getTypedIfNull(this.getValue(var1), this.type);
            }
            break;
         case 40:
            this.type = (TypeInfo)var2.getExtTypeInfo();
            if (this.left.isConstant() && this.right.isConstant()) {
               return TypedValueExpression.get(this.getValue(var1), this.type);
            }
            break;
         default:
            throw Store.getInvalidExpressionTypeException("Array", this.left);
      }

      return this;
   }
}
