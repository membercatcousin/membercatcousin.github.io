package org.h2.table;

import java.util.ArrayList;
import org.h2.command.QueryScope;
import org.h2.command.query.Query;
import org.h2.engine.SessionLocal;
import org.h2.expression.Parameter;
import org.h2.index.QueryExpressionIndex;
import org.h2.index.RecursiveIndex;
import org.h2.index.RegularQueryExpressionIndex;
import org.h2.result.ResultInterface;
import org.h2.util.ParserUtil;

public final class CTE extends QueryExpressionTable {
   private final String querySQL;
   private final boolean recursive;
   private final QueryScope queryScope;
   private final ArrayList<Parameter> originalParameters;
   private ResultInterface recursiveResult;

   public CTE(String var1, Query var2, String var3, ArrayList<Parameter> var4, Column[] var5, SessionLocal var6, boolean var7, QueryScope var8) {
      super(var6.getDatabase().getMainSchema(), 0, var1);
      this.setTemporary(true);
      this.queryScope = var8;
      this.querySQL = var3;
      this.recursive = var7;
      this.originalParameters = var4;
      this.tables = new ArrayList(var2.getTables());
      this.setColumns(this.initColumns(var6, var5, var2, false, true));
      this.viewQuery = var2;
   }

   protected QueryExpressionIndex createIndex(SessionLocal var1, int[] var2) {
      return (QueryExpressionIndex)(this.recursive ? new RecursiveIndex(this, this.querySQL, this.originalParameters, var1) : new RegularQueryExpressionIndex(this, this.querySQL, this.originalParameters, var1, var2));
   }

   public Query getTopQuery() {
      return null;
   }

   public String getCreateSQL() {
      return null;
   }

   public boolean canDrop() {
      return false;
   }

   public TableType getTableType() {
      return null;
   }

   public StringBuilder getSQL(StringBuilder var1, int var2) {
      return ParserUtil.quoteIdentifier(var1, this.getName(), var2);
   }

   public String getQuerySQL() {
      return this.querySQL;
   }

   public QueryScope getQueryScope() {
      return this.queryScope;
   }

   public boolean isRecursive() {
      return this.recursive;
   }

   public boolean isDeterministic() {
      return this.recursive ? false : super.isDeterministic();
   }

   public void setRecursiveResult(ResultInterface var1) {
      if (this.recursiveResult != null) {
         this.recursiveResult.close();
      }

      this.recursiveResult = var1;
   }

   public ResultInterface getRecursiveResult() {
      return this.recursiveResult;
   }
}
