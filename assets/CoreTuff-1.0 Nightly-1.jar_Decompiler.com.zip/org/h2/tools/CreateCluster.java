package org.h2.tools;

import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.h2.jdbc.JdbcConnection;
import org.h2.util.Tool;

public class CreateCluster extends Tool {
   public static void main(String... var0) throws SQLException {
      (new CreateCluster()).runTool(var0);
   }

   public void runTool(String... var1) throws SQLException {
      String var2 = null;
      String var3 = null;
      String var4 = "";
      String var5 = "";
      String var6 = null;

      for(int var7 = 0; var1 != null && var7 < var1.length; ++var7) {
         String var8 = var1[var7];
         if (var8.equals("-urlSource")) {
            ++var7;
            var2 = var1[var7];
         } else if (var8.equals("-urlTarget")) {
            ++var7;
            var3 = var1[var7];
         } else if (var8.equals("-user")) {
            ++var7;
            var4 = var1[var7];
         } else if (var8.equals("-password")) {
            ++var7;
            var5 = var1[var7];
         } else if (var8.equals("-serverList")) {
            ++var7;
            var6 = var1[var7];
         } else {
            if (var8.equals("-help") || var8.equals("-?")) {
               this.showUsage();
               return;
            }

            this.showUsageAndThrowUnsupportedOption(var8);
         }
      }

      if (var2 != null && var3 != null && var6 != null) {
         process(var2, var3, var4, var5, var6);
      } else {
         this.showUsage();
         throw new SQLException("Source URL, target URL, or server list not set");
      }
   }

   public void execute(String var1, String var2, String var3, String var4, String var5) throws SQLException {
      process(var1, var2, var3, var4, var5);
   }

   private static void process(String var0, String var1, String var2, String var3, String var4) throws SQLException {
      JdbcConnection var5 = new JdbcConnection(var0 + ";CLUSTER=''", (Properties)null, var2, var3, false);

      try {
         Statement var6 = var5.createStatement();

         try {
            var6.execute("SET EXCLUSIVE 2");

            try {
               performTransfer(var6, var1, var2, var3, var4);
            } finally {
               var6.execute("SET EXCLUSIVE FALSE");
            }
         } catch (Throwable var17) {
            if (var6 != null) {
               try {
                  var6.close();
               } catch (Throwable var15) {
                  var17.addSuppressed(var15);
               }
            }

            throw var17;
         }

         if (var6 != null) {
            var6.close();
         }
      } catch (Throwable var18) {
         try {
            var5.close();
         } catch (Throwable var14) {
            var18.addSuppressed(var14);
         }

         throw var18;
      }

      var5.close();
   }

   private static void performTransfer(Statement var0, String var1, String var2, String var3, String var4) throws SQLException {
      JdbcConnection var5 = new JdbcConnection(var1 + ";CLUSTER=''", (Properties)null, var2, var3, false);

      try {
         Statement var6 = var5.createStatement();

         try {
            var6.execute("DROP ALL OBJECTS DELETE FILES");
         } catch (Throwable var19) {
            if (var6 != null) {
               try {
                  var6.close();
               } catch (Throwable var15) {
                  var19.addSuppressed(var15);
               }
            }

            throw var19;
         }

         if (var6 != null) {
            var6.close();
         }
      } catch (Throwable var23) {
         try {
            var5.close();
         } catch (Throwable var14) {
            var23.addSuppressed(var14);
         }

         throw var23;
      }

      var5.close();

      try {
         PipedReader var24 = new PipedReader();

         try {
            Future var25 = startWriter(var24, var0);
            JdbcConnection var7 = new JdbcConnection(var1, (Properties)null, var2, var3, false);

            try {
               Statement var8 = var7.createStatement();

               try {
                  RunScript.execute(var7, var24);

                  try {
                     var25.get();
                  } catch (ExecutionException var16) {
                     throw new SQLException(var16.getCause());
                  } catch (InterruptedException var17) {
                     throw new SQLException(var17);
                  }

                  var0.executeUpdate("SET CLUSTER '" + var4 + "'");
                  var8.executeUpdate("SET CLUSTER '" + var4 + "'");
               } catch (Throwable var18) {
                  if (var8 != null) {
                     try {
                        var8.close();
                     } catch (Throwable var13) {
                        var18.addSuppressed(var13);
                     }
                  }

                  throw var18;
               }

               if (var8 != null) {
                  var8.close();
               }
            } catch (Throwable var20) {
               try {
                  var7.close();
               } catch (Throwable var12) {
                  var20.addSuppressed(var12);
               }

               throw var20;
            }

            var7.close();
         } catch (Throwable var21) {
            try {
               var24.close();
            } catch (Throwable var11) {
               var21.addSuppressed(var11);
            }

            throw var21;
         }

         var24.close();
      } catch (IOException var22) {
         throw new SQLException(var22);
      }
   }

   private static Future<?> startWriter(PipedReader var0, Statement var1) throws IOException {
      ExecutorService var2 = Executors.newFixedThreadPool(1);
      PipedWriter var3 = new PipedWriter(var0);
      Future var4 = var2.submit(() -> {
         try {
            PipedWriter var2 = var3;

            try {
               ResultSet var3x = var1.executeQuery("SCRIPT");

               try {
                  while(var3x.next()) {
                     var2.write(var3x.getString(1) + "\n");
                  }
               } catch (Throwable var8) {
                  if (var3x != null) {
                     try {
                        var3x.close();
                     } catch (Throwable var7) {
                        var8.addSuppressed(var7);
                     }
                  }

                  throw var8;
               }

               if (var3x != null) {
                  var3x.close();
               }
            } catch (Throwable var9) {
               if (var3 != null) {
                  try {
                     var2.close();
                  } catch (Throwable var6) {
                     var9.addSuppressed(var6);
                  }
               }

               throw var9;
            }

            if (var2 != null) {
               var2.close();
            }

         } catch (IOException | SQLException var10) {
            throw new IllegalStateException("Producing script from the source DB is failing.", var10);
         }
      });
      var2.shutdown();
      return var4;
   }
}
