package org.h2.engine;

import java.util.ArrayList;
import org.h2.schema.Schema;

public final class Role extends RightOwner {
   private final boolean system;

   public Role(Database var1, int var2, String var3, boolean var4) {
      super(var1, var2, var3, 13);
      this.system = var4;
   }

   public String getCreateSQL(boolean var1) {
      if (this.system) {
         return null;
      } else {
         StringBuilder var2 = new StringBuilder("CREATE ROLE ");
         if (var1) {
            var2.append("IF NOT EXISTS ");
         }

         return this.getSQL(var2, 0).toString();
      }
   }

   public String getCreateSQL() {
      return this.getCreateSQL(false);
   }

   public int getType() {
      return 7;
   }

   public ArrayList<DbObject> getChildren() {
      ArrayList var1 = new ArrayList();

      for(Schema var3 : this.database.getAllSchemas()) {
         if (var3.getOwner() == this) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public void removeChildrenAndResources(SessionLocal var1) {
      for(RightOwner var3 : this.database.getAllUsersAndRoles()) {
         Right var4 = var3.getRightForRole(this);
         if (var4 != null) {
            this.database.removeDatabaseObject(var1, var4);
         }
      }

      for(Right var6 : this.database.getAllRights()) {
         if (var6.getGrantee() == this) {
            this.database.removeDatabaseObject(var1, var6);
         }
      }

      this.database.removeMeta(var1, this.getId());
      this.invalidate();
   }
}
