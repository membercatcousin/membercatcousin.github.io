package org.h2.table;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import org.h2.api.IntervalQualifier;
import org.h2.command.Command;
import org.h2.command.ParserBase;
import org.h2.constraint.Constraint;
import org.h2.constraint.ConstraintDomain;
import org.h2.constraint.ConstraintReferential;
import org.h2.constraint.ConstraintUnique;
import org.h2.engine.Constants;
import org.h2.engine.DbObject;
import org.h2.engine.NullsDistinct;
import org.h2.engine.QueryStatisticsData;
import org.h2.engine.Right;
import org.h2.engine.RightOwner;
import org.h2.engine.Role;
import org.h2.engine.SessionLocal;
import org.h2.engine.Setting;
import org.h2.engine.User;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.ValueExpression;
import org.h2.index.Index;
import org.h2.index.IndexType;
import org.h2.index.MetaIndex;
import org.h2.message.DbException;
import org.h2.result.Row;
import org.h2.result.SearchRow;
import org.h2.schema.Constant;
import org.h2.schema.Domain;
import org.h2.schema.FunctionAlias;
import org.h2.schema.Schema;
import org.h2.schema.Sequence;
import org.h2.schema.TriggerObject;
import org.h2.schema.UserDefinedFunction;
import org.h2.store.InDoubtTransaction;
import org.h2.util.DateTimeUtils;
import org.h2.util.MathUtils;
import org.h2.util.NetworkConnectionInfo;
import org.h2.util.StringUtils;
import org.h2.util.TimeZoneProvider;
import org.h2.util.Utils;
import org.h2.util.geometry.EWKTUtils;
import org.h2.value.CompareMode;
import org.h2.value.DataType;
import org.h2.value.ExtTypeInfoEnum;
import org.h2.value.ExtTypeInfoGeometry;
import org.h2.value.ExtTypeInfoRow;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueBigint;
import org.h2.value.ValueBoolean;
import org.h2.value.ValueDouble;
import org.h2.value.ValueInteger;
import org.h2.value.ValueNull;
import org.h2.value.ValueToObjectConverter2;
import org.h2.value.ValueVarchar;

public final class InformationSchemaTable extends MetaTable {
   private static final String CHARACTER_SET_NAME = "Unicode";
   private static final int INFORMATION_SCHEMA_CATALOG_NAME = 0;
   private static final int CHECK_CONSTRAINTS = 1;
   private static final int COLLATIONS = 2;
   private static final int COLUMNS = 3;
   private static final int COLUMN_PRIVILEGES = 4;
   private static final int CONSTRAINT_COLUMN_USAGE = 5;
   private static final int DOMAINS = 6;
   private static final int DOMAIN_CONSTRAINTS = 7;
   private static final int ELEMENT_TYPES = 8;
   private static final int FIELDS = 9;
   private static final int KEY_COLUMN_USAGE = 10;
   private static final int PARAMETERS = 11;
   private static final int REFERENTIAL_CONSTRAINTS = 12;
   private static final int ROUTINES = 13;
   private static final int SCHEMATA = 14;
   private static final int SEQUENCES = 15;
   private static final int TABLES = 16;
   private static final int TABLE_CONSTRAINTS = 17;
   private static final int TABLE_PRIVILEGES = 18;
   private static final int TRIGGERS = 19;
   private static final int VIEWS = 20;
   private static final int CONSTANTS = 21;
   private static final int ENUM_VALUES = 22;
   private static final int INDEXES = 23;
   private static final int INDEX_COLUMNS = 24;
   private static final int IN_DOUBT = 25;
   private static final int LOCKS = 26;
   private static final int QUERY_STATISTICS = 27;
   private static final int RIGHTS = 28;
   private static final int ROLES = 29;
   private static final int SESSIONS = 30;
   private static final int SESSION_STATE = 31;
   private static final int SETTINGS = 32;
   private static final int SYNONYMS = 33;
   private static final int USERS = 34;
   public static final int META_TABLE_TYPE_COUNT = 35;
   private final boolean isView;

   public InformationSchemaTable(Schema var1, int var2, int var3) {
      super(var1, var2, var3);
      String var5 = null;
      boolean var6 = true;
      Column[] var4;
      switch (var3) {
         case 0:
            this.setMetaTableName("INFORMATION_SCHEMA_CATALOG_NAME");
            var6 = false;
            var4 = new Column[]{this.column("CATALOG_NAME")};
            break;
         case 1:
            this.setMetaTableName("CHECK_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("CHECK_CLAUSE")};
            var5 = "CONSTRAINT_NAME";
            break;
         case 2:
            this.setMetaTableName("COLLATIONS");
            var4 = new Column[]{this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("PAD_ATTRIBUTE"), this.column("LANGUAGE_TAG")};
            break;
         case 3:
            this.setMetaTableName("COLUMNS");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_INTEGER), this.column("COLUMN_DEFAULT"), this.column("IS_NULLABLE"), this.column("DATA_TYPE"), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_BIGINT), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("CHARACTER_SET_CATALOG"), this.column("CHARACTER_SET_SCHEMA"), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("DOMAIN_CATALOG"), this.column("DOMAIN_SCHEMA"), this.column("DOMAIN_NAME"), this.column("MAXIMUM_CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("DTD_IDENTIFIER"), this.column("IS_IDENTITY"), this.column("IDENTITY_GENERATION"), this.column("IDENTITY_START", TypeInfo.TYPE_BIGINT), this.column("IDENTITY_INCREMENT", TypeInfo.TYPE_BIGINT), this.column("IDENTITY_MAXIMUM", TypeInfo.TYPE_BIGINT), this.column("IDENTITY_MINIMUM", TypeInfo.TYPE_BIGINT), this.column("IDENTITY_CYCLE"), this.column("IS_GENERATED"), this.column("GENERATION_EXPRESSION"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("GEOMETRY_TYPE"), this.column("GEOMETRY_SRID", TypeInfo.TYPE_INTEGER), this.column("IDENTITY_BASE", TypeInfo.TYPE_BIGINT), this.column("IDENTITY_CACHE", TypeInfo.TYPE_BIGINT), this.column("COLUMN_ON_UPDATE"), this.column("IS_VISIBLE", TypeInfo.TYPE_BOOLEAN), this.column("DEFAULT_ON_NULL", TypeInfo.TYPE_BOOLEAN), this.column("SELECTIVITY", TypeInfo.TYPE_INTEGER), this.column("REMARKS")};
            var5 = "TABLE_NAME";
            break;
         case 4:
            this.setMetaTableName("COLUMN_PRIVILEGES");
            var4 = new Column[]{this.column("GRANTOR"), this.column("GRANTEE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("PRIVILEGE_TYPE"), this.column("IS_GRANTABLE")};
            var5 = "TABLE_NAME";
            break;
         case 5:
            this.setMetaTableName("CONSTRAINT_COLUMN_USAGE");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME")};
            var5 = "TABLE_NAME";
            break;
         case 6:
            this.setMetaTableName("DOMAINS");
            var4 = new Column[]{this.column("DOMAIN_CATALOG"), this.column("DOMAIN_SCHEMA"), this.column("DOMAIN_NAME"), this.column("DATA_TYPE"), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_SET_CATALOG"), this.column("CHARACTER_SET_SCHEMA"), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DOMAIN_DEFAULT"), this.column("MAXIMUM_CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("DTD_IDENTIFIER"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("GEOMETRY_TYPE"), this.column("GEOMETRY_SRID", TypeInfo.TYPE_INTEGER), this.column("DOMAIN_ON_UPDATE"), this.column("PARENT_DOMAIN_CATALOG"), this.column("PARENT_DOMAIN_SCHEMA"), this.column("PARENT_DOMAIN_NAME"), this.column("REMARKS")};
            var5 = "DOMAIN_NAME";
            break;
         case 7:
            this.setMetaTableName("DOMAIN_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("DOMAIN_CATALOG"), this.column("DOMAIN_SCHEMA"), this.column("DOMAIN_NAME"), this.column("IS_DEFERRABLE"), this.column("INITIALLY_DEFERRED"), this.column("REMARKS")};
            var5 = "DOMAIN_NAME";
            break;
         case 8:
            this.setMetaTableName("ELEMENT_TYPES");
            var4 = new Column[]{this.column("OBJECT_CATALOG"), this.column("OBJECT_SCHEMA"), this.column("OBJECT_NAME"), this.column("OBJECT_TYPE"), this.column("COLLECTION_TYPE_IDENTIFIER"), this.column("DATA_TYPE"), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_SET_CATALOG"), this.column("CHARACTER_SET_SCHEMA"), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("MAXIMUM_CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("DTD_IDENTIFIER"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("GEOMETRY_TYPE"), this.column("GEOMETRY_SRID", TypeInfo.TYPE_INTEGER)};
            break;
         case 9:
            this.setMetaTableName("FIELDS");
            var4 = new Column[]{this.column("OBJECT_CATALOG"), this.column("OBJECT_SCHEMA"), this.column("OBJECT_NAME"), this.column("OBJECT_TYPE"), this.column("ROW_IDENTIFIER"), this.column("FIELD_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_INTEGER), this.column("DATA_TYPE"), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_SET_CATALOG"), this.column("CHARACTER_SET_SCHEMA"), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("MAXIMUM_CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("DTD_IDENTIFIER"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("GEOMETRY_TYPE"), this.column("GEOMETRY_SRID", TypeInfo.TYPE_INTEGER)};
            break;
         case 10:
            this.setMetaTableName("KEY_COLUMN_USAGE");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_INTEGER), this.column("POSITION_IN_UNIQUE_CONSTRAINT", TypeInfo.TYPE_INTEGER)};
            var5 = "TABLE_NAME";
            break;
         case 11:
            this.setMetaTableName("PARAMETERS");
            var4 = new Column[]{this.column("SPECIFIC_CATALOG"), this.column("SPECIFIC_SCHEMA"), this.column("SPECIFIC_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_INTEGER), this.column("PARAMETER_MODE"), this.column("IS_RESULT"), this.column("AS_LOCATOR"), this.column("PARAMETER_NAME"), this.column("DATA_TYPE"), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_SET_CATALOG"), this.column("CHARACTER_SET_SCHEMA"), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("MAXIMUM_CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("DTD_IDENTIFIER"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("PARAMETER_DEFAULT"), this.column("GEOMETRY_TYPE"), this.column("GEOMETRY_SRID", TypeInfo.TYPE_INTEGER)};
            break;
         case 12:
            this.setMetaTableName("REFERENTIAL_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("UNIQUE_CONSTRAINT_CATALOG"), this.column("UNIQUE_CONSTRAINT_SCHEMA"), this.column("UNIQUE_CONSTRAINT_NAME"), this.column("MATCH_OPTION"), this.column("UPDATE_RULE"), this.column("DELETE_RULE")};
            var5 = "CONSTRAINT_NAME";
            break;
         case 13:
            this.setMetaTableName("ROUTINES");
            var4 = new Column[]{this.column("SPECIFIC_CATALOG"), this.column("SPECIFIC_SCHEMA"), this.column("SPECIFIC_NAME"), this.column("ROUTINE_CATALOG"), this.column("ROUTINE_SCHEMA"), this.column("ROUTINE_NAME"), this.column("ROUTINE_TYPE"), this.column("DATA_TYPE"), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_SET_CATALOG"), this.column("CHARACTER_SET_SCHEMA"), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("MAXIMUM_CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("DTD_IDENTIFIER"), this.column("ROUTINE_BODY"), this.column("ROUTINE_DEFINITION"), this.column("EXTERNAL_NAME"), this.column("EXTERNAL_LANGUAGE"), this.column("PARAMETER_STYLE"), this.column("IS_DETERMINISTIC"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("GEOMETRY_TYPE"), this.column("GEOMETRY_SRID", TypeInfo.TYPE_INTEGER), this.column("REMARKS")};
            break;
         case 14:
            this.setMetaTableName("SCHEMATA");
            var4 = new Column[]{this.column("CATALOG_NAME"), this.column("SCHEMA_NAME"), this.column("SCHEMA_OWNER"), this.column("DEFAULT_CHARACTER_SET_CATALOG"), this.column("DEFAULT_CHARACTER_SET_SCHEMA"), this.column("DEFAULT_CHARACTER_SET_NAME"), this.column("SQL_PATH"), this.column("DEFAULT_COLLATION_NAME"), this.column("REMARKS")};
            break;
         case 15:
            this.setMetaTableName("SEQUENCES");
            var4 = new Column[]{this.column("SEQUENCE_CATALOG"), this.column("SEQUENCE_SCHEMA"), this.column("SEQUENCE_NAME"), this.column("DATA_TYPE"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("START_VALUE", TypeInfo.TYPE_BIGINT), this.column("MINIMUM_VALUE", TypeInfo.TYPE_BIGINT), this.column("MAXIMUM_VALUE", TypeInfo.TYPE_BIGINT), this.column("INCREMENT", TypeInfo.TYPE_BIGINT), this.column("CYCLE_OPTION"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("BASE_VALUE", TypeInfo.TYPE_BIGINT), this.column("CACHE", TypeInfo.TYPE_BIGINT), this.column("REMARKS")};
            var5 = "SEQUENCE_NAME";
            break;
         case 16:
            this.setMetaTableName("TABLES");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("TABLE_TYPE"), this.column("IS_INSERTABLE_INTO"), this.column("COMMIT_ACTION"), this.column("STORAGE_TYPE"), this.column("REMARKS"), this.column("LAST_MODIFICATION", TypeInfo.TYPE_BIGINT), this.column("TABLE_CLASS"), this.column("ROW_COUNT_ESTIMATE", TypeInfo.TYPE_BIGINT)};
            var5 = "TABLE_NAME";
            break;
         case 17:
            this.setMetaTableName("TABLE_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("CONSTRAINT_TYPE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("IS_DEFERRABLE"), this.column("INITIALLY_DEFERRED"), this.column("ENFORCED"), this.column("NULLS_DISTINCT"), this.column("INDEX_CATALOG"), this.column("INDEX_SCHEMA"), this.column("INDEX_NAME"), this.column("REMARKS")};
            var5 = "TABLE_NAME";
            break;
         case 18:
            this.setMetaTableName("TABLE_PRIVILEGES");
            var4 = new Column[]{this.column("GRANTOR"), this.column("GRANTEE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("PRIVILEGE_TYPE"), this.column("IS_GRANTABLE"), this.column("WITH_HIERARCHY")};
            var5 = "TABLE_NAME";
            break;
         case 19:
            this.setMetaTableName("TRIGGERS");
            var4 = new Column[]{this.column("TRIGGER_CATALOG"), this.column("TRIGGER_SCHEMA"), this.column("TRIGGER_NAME"), this.column("EVENT_MANIPULATION"), this.column("EVENT_OBJECT_CATALOG"), this.column("EVENT_OBJECT_SCHEMA"), this.column("EVENT_OBJECT_TABLE"), this.column("ACTION_ORIENTATION"), this.column("ACTION_TIMING"), this.column("IS_ROLLBACK", TypeInfo.TYPE_BOOLEAN), this.column("JAVA_CLASS"), this.column("QUEUE_SIZE", TypeInfo.TYPE_INTEGER), this.column("NO_WAIT", TypeInfo.TYPE_BOOLEAN), this.column("REMARKS")};
            var5 = "EVENT_OBJECT_TABLE";
            break;
         case 20:
            this.setMetaTableName("VIEWS");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("VIEW_DEFINITION"), this.column("CHECK_OPTION"), this.column("IS_UPDATABLE"), this.column("INSERTABLE_INTO"), this.column("IS_TRIGGER_UPDATABLE"), this.column("IS_TRIGGER_DELETABLE"), this.column("IS_TRIGGER_INSERTABLE_INTO"), this.column("STATUS"), this.column("REMARKS")};
            var5 = "TABLE_NAME";
            break;
         case 21:
            this.setMetaTableName("CONSTANTS");
            var6 = false;
            var4 = new Column[]{this.column("CONSTANT_CATALOG"), this.column("CONSTANT_SCHEMA"), this.column("CONSTANT_NAME"), this.column("VALUE_DEFINITION"), this.column("DATA_TYPE"), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_BIGINT), this.column("CHARACTER_SET_CATALOG"), this.column("CHARACTER_SET_SCHEMA"), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_CATALOG"), this.column("COLLATION_SCHEMA"), this.column("COLLATION_NAME"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("MAXIMUM_CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("DTD_IDENTIFIER"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("GEOMETRY_TYPE"), this.column("GEOMETRY_SRID", TypeInfo.TYPE_INTEGER), this.column("REMARKS")};
            var5 = "CONSTANT_NAME";
            break;
         case 22:
            this.setMetaTableName("ENUM_VALUES");
            var6 = false;
            var4 = new Column[]{this.column("OBJECT_CATALOG"), this.column("OBJECT_SCHEMA"), this.column("OBJECT_NAME"), this.column("OBJECT_TYPE"), this.column("ENUM_IDENTIFIER"), this.column("VALUE_NAME"), this.column("VALUE_ORDINAL")};
            break;
         case 23:
            this.setMetaTableName("INDEXES");
            var6 = false;
            var4 = new Column[]{this.column("INDEX_CATALOG"), this.column("INDEX_SCHEMA"), this.column("INDEX_NAME"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("INDEX_TYPE_NAME"), this.column("NULLS_DISTINCT"), this.column("IS_GENERATED", TypeInfo.TYPE_BOOLEAN), this.column("REMARKS"), this.column("INDEX_CLASS")};
            var5 = "TABLE_NAME";
            break;
         case 24:
            this.setMetaTableName("INDEX_COLUMNS");
            var6 = false;
            var4 = new Column[]{this.column("INDEX_CATALOG"), this.column("INDEX_SCHEMA"), this.column("INDEX_NAME"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_INTEGER), this.column("ORDERING_SPECIFICATION"), this.column("NULL_ORDERING"), this.column("IS_UNIQUE", TypeInfo.TYPE_BOOLEAN)};
            var5 = "TABLE_NAME";
            break;
         case 25:
            this.setMetaTableName("IN_DOUBT");
            var6 = false;
            var4 = new Column[]{this.column("TRANSACTION_NAME"), this.column("TRANSACTION_STATE")};
            break;
         case 26:
            this.setMetaTableName("LOCKS");
            var6 = false;
            var4 = new Column[]{this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("SESSION_ID", TypeInfo.TYPE_INTEGER), this.column("LOCK_TYPE")};
            break;
         case 27:
            this.setMetaTableName("QUERY_STATISTICS");
            var6 = false;
            var4 = new Column[]{this.column("SQL_STATEMENT"), this.column("EXECUTION_COUNT", TypeInfo.TYPE_INTEGER), this.column("MIN_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("MAX_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("CUMULATIVE_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("AVERAGE_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("STD_DEV_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("MIN_ROW_COUNT", TypeInfo.TYPE_BIGINT), this.column("MAX_ROW_COUNT", TypeInfo.TYPE_BIGINT), this.column("CUMULATIVE_ROW_COUNT", TypeInfo.TYPE_BIGINT), this.column("AVERAGE_ROW_COUNT", TypeInfo.TYPE_DOUBLE), this.column("STD_DEV_ROW_COUNT", TypeInfo.TYPE_DOUBLE)};
            break;
         case 28:
            this.setMetaTableName("RIGHTS");
            var6 = false;
            var4 = new Column[]{this.column("GRANTEE"), this.column("GRANTEETYPE"), this.column("GRANTEDROLE"), this.column("RIGHTS"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME")};
            var5 = "TABLE_NAME";
            break;
         case 29:
            this.setMetaTableName("ROLES");
            var6 = false;
            var4 = new Column[]{this.column("ROLE_NAME"), this.column("REMARKS")};
            break;
         case 30:
            this.setMetaTableName("SESSIONS");
            var6 = false;
            var4 = new Column[]{this.column("SESSION_ID", TypeInfo.TYPE_INTEGER), this.column("USER_NAME"), this.column("SERVER"), this.column("CLIENT_ADDR"), this.column("CLIENT_INFO"), this.column("SESSION_START", TypeInfo.TYPE_TIMESTAMP_TZ), this.column("ISOLATION_LEVEL"), this.column("EXECUTING_STATEMENT"), this.column("EXECUTING_STATEMENT_START", TypeInfo.TYPE_TIMESTAMP_TZ), this.column("CONTAINS_UNCOMMITTED", TypeInfo.TYPE_BOOLEAN), this.column("SESSION_STATE"), this.column("BLOCKER_ID", TypeInfo.TYPE_INTEGER), this.column("SLEEP_SINCE", TypeInfo.TYPE_TIMESTAMP_TZ)};
            break;
         case 31:
            this.setMetaTableName("SESSION_STATE");
            var6 = false;
            var4 = new Column[]{this.column("STATE_KEY"), this.column("STATE_COMMAND")};
            break;
         case 32:
            this.setMetaTableName("SETTINGS");
            var6 = false;
            var4 = new Column[]{this.column("SETTING_NAME"), this.column("SETTING_VALUE")};
            break;
         case 33:
            this.setMetaTableName("SYNONYMS");
            var6 = false;
            var4 = new Column[]{this.column("SYNONYM_CATALOG"), this.column("SYNONYM_SCHEMA"), this.column("SYNONYM_NAME"), this.column("SYNONYM_FOR"), this.column("SYNONYM_FOR_SCHEMA"), this.column("TYPE_NAME"), this.column("STATUS"), this.column("REMARKS")};
            var5 = "SYNONYM_NAME";
            break;
         case 34:
            this.setMetaTableName("USERS");
            var6 = false;
            var4 = new Column[]{this.column("USER_NAME"), this.column("IS_ADMIN", TypeInfo.TYPE_BOOLEAN), this.column("REMARKS")};
            break;
         default:
            throw DbException.getInternalError("type=" + var3);
      }

      this.setColumns(var4);
      if (var5 == null) {
         this.indexColumn = -1;
         this.metaIndex = null;
      } else {
         this.indexColumn = this.getColumn(this.database.sysIdentifier(var5)).getColumnId();
         IndexColumn[] var7 = IndexColumn.wrap(new Column[]{var4[this.indexColumn]});
         this.metaIndex = new MetaIndex(this, var7, false);
      }

      this.isView = var6;
   }

   public ArrayList<Row> generateRows(SessionLocal var1, SearchRow var2, SearchRow var3) {
      Value var4 = null;
      Value var5 = null;
      if (this.indexColumn >= 0) {
         if (var2 != null) {
            var4 = var2.getValue(this.indexColumn);
         }

         if (var3 != null) {
            var5 = var3.getValue(this.indexColumn);
         }
      }

      ArrayList var6 = Utils.newSmallArrayList();
      String var7 = this.database.getShortName();
      switch (this.type) {
         case 0:
            this.informationSchemaCatalogName(var1, var6, var7);
            break;
         case 1:
            this.checkConstraints(var1, var4, var5, var6, var7);
            break;
         case 2:
            this.collations(var1, var6, var7);
            break;
         case 3:
            this.columns(var1, var4, var5, var6, var7);
            break;
         case 4:
            this.columnPrivileges(var1, var4, var5, var6, var7);
            break;
         case 5:
            this.constraintColumnUsage(var1, var4, var5, var6, var7);
            break;
         case 6:
            this.domains(var1, var4, var5, var6, var7);
            break;
         case 7:
            this.domainConstraints(var1, var4, var5, var6, var7);
            break;
         case 8:
            this.elementTypesFields(var1, var6, var7, 8);
            break;
         case 9:
            this.elementTypesFields(var1, var6, var7, 9);
            break;
         case 10:
            this.keyColumnUsage(var1, var4, var5, var6, var7);
            break;
         case 11:
            this.parameters(var1, var6, var7);
            break;
         case 12:
            this.referentialConstraints(var1, var4, var5, var6, var7);
            break;
         case 13:
            this.routines(var1, var6, var7);
            break;
         case 14:
            this.schemata(var1, var6, var7);
            break;
         case 15:
            this.sequences(var1, var4, var5, var6, var7);
            break;
         case 16:
            this.tables(var1, var4, var5, var6, var7);
            break;
         case 17:
            this.tableConstraints(var1, var4, var5, var6, var7);
            break;
         case 18:
            this.tablePrivileges(var1, var4, var5, var6, var7);
            break;
         case 19:
            this.triggers(var1, var4, var5, var6, var7);
            break;
         case 20:
            this.views(var1, var4, var5, var6, var7);
            break;
         case 21:
            this.constants(var1, var4, var5, var6, var7);
            break;
         case 22:
            this.elementTypesFields(var1, var6, var7, 22);
            break;
         case 23:
            this.indexes(var1, var4, var5, var6, var7, false);
            break;
         case 24:
            this.indexes(var1, var4, var5, var6, var7, true);
            break;
         case 25:
            this.inDoubt(var1, var6);
            break;
         case 26:
            this.locks(var1, var6);
            break;
         case 27:
            this.queryStatistics(var1, var6);
            break;
         case 28:
            this.rights(var1, var4, var5, var6);
            break;
         case 29:
            this.roles(var1, var6);
            break;
         case 30:
            this.sessions(var1, var6);
            break;
         case 31:
            this.sessionState(var1, var6);
            break;
         case 32:
            this.settings(var1, var6);
            break;
         case 33:
            this.synonyms(var1, var6, var7);
            break;
         case 34:
            this.users(var1, var6);
            break;
         default:
            throw DbException.getInternalError("type=" + this.type);
      }

      return var6;
   }

   private void informationSchemaCatalogName(SessionLocal var1, ArrayList<Row> var2, String var3) {
      this.add(var1, var2, new Object[]{var3});
   }

   private void checkConstraints(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType().isCheck() && this.checkIndex(var1, var4x.getName(), var2, var3)).forEach((var4x) -> this.checkConstraints(var1, var4, var5, var4x));
   }

   private void checkConstraints(SessionLocal var1, ArrayList<Row> var2, String var3, Constraint var4) {
      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var4.getExpression().getSQL(0, 2)});
   }

   private void collations(SessionLocal var1, ArrayList<Row> var2, String var3) {
      String var4 = this.database.getMainSchema().getName();
      this.collations(var1, var2, var3, var4, "OFF", (String)null);

      for(Locale var8 : CompareMode.getCollationLocales(false)) {
         this.collations(var1, var2, var3, var4, CompareMode.getName(var8), var8.toLanguageTag());
      }

   }

   private void collations(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, String var6) {
      if ("und".equals(var6)) {
         var6 = null;
      }

      this.add(var1, var2, new Object[]{var3, var4, var5, "NO PAD", var6});
   }

   private void columns(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      String var6 = this.database.getMainSchema().getName();
      String var7 = this.database.getCompareMode().getName();
      this.getAllTables(var1, var2, var3).forEach((var6x) -> this.columns(var1, var4, var5, var6, var7, var6x));
   }

   private void columns(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, Table var6) {
      Column[] var7 = var6.getColumns();
      int var8 = 0;
      int var9 = var7.length;

      while(var8 < var9) {
         Column var10007 = var7[var8];
         ++var8;
         this.columns(var1, var2, var3, var4, var5, var6, var10007, var8);
      }

   }

   private void columns(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, Table var6, Column var7, int var8) {
      TypeInfo var9 = var7.getType();
      DataTypeInformation var10 = InformationSchemaTable.DataTypeInformation.valueOf(var9);
      String var11;
      String var12;
      String var13;
      String var14;
      if (var10.hasCharsetAndCollation) {
         var11 = var3;
         var12 = var4;
         var13 = "Unicode";
         var14 = var5;
      } else {
         var14 = null;
         var13 = null;
         var12 = null;
         var11 = null;
      }

      Domain var15 = var7.getDomain();
      String var16 = null;
      String var17 = null;
      String var18 = null;
      if (var15 != null) {
         var16 = var3;
         var17 = var15.getSchema().getName();
         var18 = var15.getName();
      }

      Sequence var31 = var7.getSequence();
      String var19;
      String var20;
      String var21;
      String var22;
      String var23;
      String var24;
      ValueBigint var25;
      ValueBigint var26;
      ValueBigint var27;
      ValueBigint var28;
      ValueBigint var29;
      ValueBigint var30;
      if (var31 != null) {
         var19 = null;
         var20 = "NEVER";
         var21 = null;
         var22 = "YES";
         var23 = var7.isGeneratedAlways() ? "ALWAYS" : "BY DEFAULT";
         var25 = ValueBigint.get(var31.getStartValue());
         var26 = ValueBigint.get(var31.getIncrement());
         var27 = ValueBigint.get(var31.getMaxValue());
         var28 = ValueBigint.get(var31.getMinValue());
         Sequence.Cycle var32 = var31.getCycle();
         var24 = var32.isCycle() ? "YES" : "NO";
         var29 = var32 != Sequence.Cycle.EXHAUSTED ? ValueBigint.get(var31.getBaseValue()) : null;
         var30 = ValueBigint.get(var31.getCacheSize());
      } else {
         if (var7.isGenerated()) {
            var19 = null;
            var20 = "ALWAYS";
            var21 = var7.getDefaultSQL();
         } else {
            var19 = var7.getDefaultSQL();
            var20 = "NEVER";
            var21 = null;
         }

         var22 = "NO";
         var24 = null;
         var23 = null;
         var30 = null;
         var29 = null;
         var28 = null;
         var27 = null;
         var26 = null;
         var25 = null;
      }

      this.add(var1, var2, new Object[]{var3, var6.getSchema().getName(), var6.getName(), var7.getName(), ValueInteger.get(var8), var19, var7.isNullable() ? "YES" : "NO", this.identifier(var10.dataType), var10.characterPrecision, var10.characterPrecision, var10.numericPrecision, var10.numericPrecisionRadix, var10.numericScale, var10.datetimePrecision, var10.intervalType, var10.intervalPrecision, var11, var12, var13, var11, var12, var14, var16, var17, var18, var10.maximumCardinality, Integer.toString(var8), var22, var23, var25, var26, var27, var28, var24, var20, var21, var10.declaredDataType, var10.declaredNumericPrecision, var10.declaredNumericScale, var10.geometryType, var10.geometrySrid, var29, var30, var7.getOnUpdateSQL(), ValueBoolean.get(var7.getVisible()), ValueBoolean.get(var7.isDefaultOnNull()), ValueInteger.get(var7.getSelectivity()), var7.getComment()});
   }

   private void columnPrivileges(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      for(Right var7 : this.database.getAllRights()) {
         DbObject var8 = var7.getGrantedObject();
         if (var8 instanceof Table) {
            Table var9 = (Table)var8;
            if (this.checkIndex(var1, var9.getName(), var2, var3)) {
               DbObject var10 = var7.getGrantee();
               int var11 = var7.getRightMask();

               for(Column var15 : var9.getColumns()) {
                  this.addPrivileges(var1, var4, var10, var5, var9, var15.getName(), var11);
               }
            }
         }
      }

   }

   private void constraintColumnUsage(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      this.getAllConstraints(var1).forEach((var6) -> this.constraintColumnUsage(var1, var2, var3, var4, var5, var6));
   }

   private void constraintColumnUsage(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5, Constraint var6) {
      switch (var6.getConstraintType()) {
         case CHECK:
         case DOMAIN:
            HashSet var12 = new HashSet();
            var6.getExpression().isEverything(ExpressionVisitor.getColumnsVisitor(var12, (Table)null));

            for(Column var16 : var12) {
               Table var10 = var16.getTable();
               if (this.checkIndex(var1, var10.getName(), var2, var3)) {
                  this.addConstraintColumnUsage(var1, var4, var5, var6, var16);
               }
            }
            break;
         case REFERENTIAL:
            Table var7 = var6.getRefTable();
            if (this.checkIndex(var1, var7.getName(), var2, var3)) {
               for(Column var9 : var6.getReferencedColumns(var7)) {
                  this.addConstraintColumnUsage(var1, var4, var5, var6, var9);
               }
            }
         case PRIMARY_KEY:
         case UNIQUE:
            Table var11 = var6.getTable();
            if (this.checkIndex(var1, var11.getName(), var2, var3)) {
               for(Column var15 : var6.getReferencedColumns(var11)) {
                  this.addConstraintColumnUsage(var1, var4, var5, var6, var15);
               }
            }
      }

   }

   private void domains(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      String var6 = this.database.getMainSchema().getName();
      String var7 = this.database.getCompareMode().getName();

      for(Schema var9 : this.database.getAllSchemas()) {
         for(Domain var11 : var9.getAllDomains()) {
            String var12 = var11.getName();
            if (this.checkIndex(var1, var12, var2, var3)) {
               this.domains(var1, var4, var5, var6, var7, var11, var12);
            }
         }
      }

   }

   private void domains(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, Domain var6, String var7) {
      Domain var8 = var6.getDomain();
      TypeInfo var9 = var6.getDataType();
      DataTypeInformation var10 = InformationSchemaTable.DataTypeInformation.valueOf(var9);
      String var11;
      String var12;
      String var13;
      String var14;
      if (var10.hasCharsetAndCollation) {
         var11 = var3;
         var12 = var4;
         var13 = "Unicode";
         var14 = var5;
      } else {
         var14 = null;
         var13 = null;
         var12 = null;
         var11 = null;
      }

      this.add(var1, var2, new Object[]{var3, var6.getSchema().getName(), var7, var10.dataType, var10.characterPrecision, var10.characterPrecision, var11, var12, var13, var11, var12, var14, var10.numericPrecision, var10.numericPrecisionRadix, var10.numericScale, var10.datetimePrecision, var10.intervalType, var10.intervalPrecision, var6.getDefaultSQL(), var10.maximumCardinality, "TYPE", var10.declaredDataType, var10.declaredNumericPrecision, var10.declaredNumericScale, var10.geometryType, var10.geometrySrid, var6.getOnUpdateSQL(), var8 != null ? var3 : null, var8 != null ? var8.getSchema().getName() : null, var8 != null ? var8.getName() : null, var6.getComment()});
   }

   private void domainConstraints(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      for(Schema var7 : this.database.getAllSchemas()) {
         for(Constraint var9 : var7.getAllConstraints()) {
            if (var9.getConstraintType() == Constraint.Type.DOMAIN) {
               ConstraintDomain var10 = (ConstraintDomain)var9;
               Domain var11 = var10.getDomain();
               String var12 = var11.getName();
               if (this.checkIndex(var1, var12, var2, var3)) {
                  this.domainConstraints(var1, var4, var5, var10, var11, var12);
               }
            }
         }
      }

   }

   private void domainConstraints(SessionLocal var1, ArrayList<Row> var2, String var3, ConstraintDomain var4, Domain var5, String var6) {
      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var3, var5.getSchema().getName(), var6, "NO", "NO", var4.getComment()});
   }

   private void elementTypesFields(SessionLocal var1, ArrayList<Row> var2, String var3, int var4) {
      String var5 = this.database.getMainSchema().getName();
      String var6 = this.database.getCompareMode().getName();

      label98:
      for(Schema var8 : this.database.getAllSchemas()) {
         String var9 = var8.getName();

         for(Table var11 : var8.getAllTablesAndViews(var1)) {
            this.elementTypesFieldsForTable(var1, var2, var3, var4, var5, var6, var9, var11);
         }

         for(Domain var28 : var8.getAllDomains()) {
            this.elementTypesFieldsRow(var1, var2, var3, var4, var5, var6, var9, var28.getName(), "DOMAIN", "TYPE", var28.getDataType());
         }

         Iterator var26 = var8.getAllFunctionsAndAggregates().iterator();

         while(true) {
            String var12;
            FunctionAlias.JavaMethod[] var13;
            while(true) {
               if (!var26.hasNext()) {
                  for(Constant var30 : var8.getAllConstants()) {
                     this.elementTypesFieldsRow(var1, var2, var3, var4, var5, var6, var9, var30.getName(), "CONSTANT", "TYPE", var30.getValue().getType());
                  }
                  continue label98;
               }

               UserDefinedFunction var29 = (UserDefinedFunction)var26.next();
               if (var29 instanceof FunctionAlias) {
                  var12 = var29.getName();

                  try {
                     var13 = ((FunctionAlias)var29).getJavaMethods();
                     break;
                  } catch (DbException var22) {
                  }
               }
            }

            for(int var14 = 0; var14 < var13.length; ++var14) {
               FunctionAlias.JavaMethod var15 = var13[var14];
               TypeInfo var16 = var15.getDataType();
               String var17 = var12 + "_" + (var14 + 1);
               if (var16 != null && var16.getValueType() != 0) {
                  this.elementTypesFieldsRow(var1, var2, var3, var4, var5, var6, var9, var17, "ROUTINE", "RESULT", var16);
               }

               Class[] var18 = var15.getColumnClasses();
               int var19 = 1;
               int var20 = var15.hasConnectionParam() ? 1 : 0;

               for(int var21 = var18.length; var20 < var21; ++var20) {
                  this.elementTypesFieldsRow(var1, var2, var3, var4, var5, var6, var9, var17, "ROUTINE", Integer.toString(var19), ValueToObjectConverter2.classToType(var18[var20]));
                  ++var19;
               }
            }
         }
      }

      for(Table var24 : var1.getLocalTempTables()) {
         this.elementTypesFieldsForTable(var1, var2, var3, var4, var5, var6, var24.getSchema().getName(), var24);
      }

   }

   private void elementTypesFieldsForTable(SessionLocal var1, ArrayList<Row> var2, String var3, int var4, String var5, String var6, String var7, Table var8) {
      String var9 = var8.getName();
      Column[] var10 = var8.getColumns();

      for(int var11 = 0; var11 < var10.length; ++var11) {
         this.elementTypesFieldsRow(var1, var2, var3, var4, var5, var6, var7, var9, "TABLE", Integer.toString(var11 + 1), var10[var11].getType());
      }

   }

   private void elementTypesFieldsRow(SessionLocal var1, ArrayList<Row> var2, String var3, int var4, String var5, String var6, String var7, String var8, String var9, String var10, TypeInfo var11) {
      switch (var11.getValueType()) {
         case 36:
            if (var4 == 22) {
               this.enumValues(var1, var2, var3, var7, var8, var9, var10, var11);
            }
            break;
         case 40:
            var11 = (TypeInfo)var11.getExtTypeInfo();
            String var20 = var10 + "_";
            if (var4 == 8) {
               this.elementTypes(var1, var2, var3, var5, var6, var7, var8, var9, var10, var20, var11);
            }

            this.elementTypesFieldsRow(var1, var2, var3, var4, var5, var6, var7, var8, var9, var20, var11);
            break;
         case 41:
            ExtTypeInfoRow var12 = (ExtTypeInfoRow)var11.getExtTypeInfo();
            int var13 = 0;

            for(Map.Entry var15 : var12.getFields()) {
               var11 = (TypeInfo)var15.getValue();
               String var16 = (String)var15.getKey();
               ++var13;
               String var17 = var10 + "_" + var13;
               if (var4 == 9) {
                  this.fields(var1, var2, var3, var5, var6, var7, var8, var9, var10, var16, var13, var17, var11);
               }

               this.elementTypesFieldsRow(var1, var2, var3, var4, var5, var6, var7, var8, var9, var17, var11);
            }
      }

   }

   private void elementTypes(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, String var6, String var7, String var8, String var9, String var10, TypeInfo var11) {
      DataTypeInformation var12 = InformationSchemaTable.DataTypeInformation.valueOf(var11);
      String var13;
      String var14;
      String var15;
      String var16;
      if (var12.hasCharsetAndCollation) {
         var13 = var3;
         var14 = var4;
         var15 = "Unicode";
         var16 = var5;
      } else {
         var16 = null;
         var15 = null;
         var14 = null;
         var13 = null;
      }

      this.add(var1, var2, new Object[]{var3, var6, var7, var8, var9, var12.dataType, var12.characterPrecision, var12.characterPrecision, var13, var14, var15, var13, var14, var16, var12.numericPrecision, var12.numericPrecisionRadix, var12.numericScale, var12.datetimePrecision, var12.intervalType, var12.intervalPrecision, var12.maximumCardinality, var10, var12.declaredDataType, var12.declaredNumericPrecision, var12.declaredNumericScale, var12.geometryType, var12.geometrySrid});
   }

   private void fields(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, String var6, String var7, String var8, String var9, String var10, int var11, String var12, TypeInfo var13) {
      DataTypeInformation var14 = InformationSchemaTable.DataTypeInformation.valueOf(var13);
      String var15;
      String var16;
      String var17;
      String var18;
      if (var14.hasCharsetAndCollation) {
         var15 = var3;
         var16 = var4;
         var17 = "Unicode";
         var18 = var5;
      } else {
         var18 = null;
         var17 = null;
         var16 = null;
         var15 = null;
      }

      this.add(var1, var2, new Object[]{var3, var6, var7, var8, var9, var10, ValueInteger.get(var11), var14.dataType, var14.characterPrecision, var14.characterPrecision, var15, var16, var17, var15, var16, var18, var14.numericPrecision, var14.numericPrecisionRadix, var14.numericScale, var14.datetimePrecision, var14.intervalType, var14.intervalPrecision, var14.maximumCardinality, var12, var14.declaredDataType, var14.declaredNumericPrecision, var14.declaredNumericScale, var14.geometryType, var14.geometrySrid});
   }

   private void keyColumnUsage(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      this.getAllConstraints(var1).forEach((var6) -> {
         Constraint.Type var7 = var6.getConstraintType();
         IndexColumn[] var8;
         if (var7.isUnique()) {
            var8 = ((ConstraintUnique)var6).getColumns();
         } else {
            if (var7 != Constraint.Type.REFERENTIAL) {
               return;
            }

            var8 = ((ConstraintReferential)var6).getColumns();
         }

         Table var9 = var6.getTable();
         String var10 = var9.getName();
         if (this.checkIndex(var1, var10, var2, var3)) {
            this.keyColumnUsage(var1, var4, var5, var6, var7, var8, var9, var10);
         }
      });
   }

   private void keyColumnUsage(SessionLocal var1, ArrayList<Row> var2, String var3, Constraint var4, Constraint.Type var5, IndexColumn[] var6, Table var7, String var8) {
      ConstraintUnique var9;
      if (var5 == Constraint.Type.REFERENTIAL) {
         var9 = var4.getReferencedConstraint();
      } else {
         var9 = null;
      }

      for(int var10 = 0; var10 < var6.length; ++var10) {
         IndexColumn var11 = var6[var10];
         ValueInteger var12 = ValueInteger.get(var10 + 1);
         ValueInteger var13 = null;
         if (var9 != null) {
            Column var14 = ((ConstraintReferential)var4).getRefColumns()[var10].column;
            IndexColumn[] var15 = var9.getColumns();

            for(int var16 = 0; var16 < var15.length; ++var16) {
               if (var15[var16].column.equals(var14)) {
                  var13 = ValueInteger.get(var16 + 1);
                  break;
               }
            }
         }

         this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var3, var7.getSchema().getName(), var8, var11.columnName, var12, var13});
      }

   }

   private void parameters(SessionLocal var1, ArrayList<Row> var2, String var3) {
      String var4 = this.database.getMainSchema().getName();
      String var5 = this.database.getCompareMode().getName();

      label54:
      for(Schema var7 : this.database.getAllSchemas()) {
         Iterator var8 = var7.getAllFunctionsAndAggregates().iterator();

         while(true) {
            UserDefinedFunction var9;
            FunctionAlias.JavaMethod[] var10;
            while(true) {
               if (!var8.hasNext()) {
                  continue label54;
               }

               var9 = (UserDefinedFunction)var8.next();
               if (var9 instanceof FunctionAlias) {
                  try {
                     var10 = ((FunctionAlias)var9).getJavaMethods();
                     break;
                  } catch (DbException var17) {
                  }
               }
            }

            for(int var11 = 0; var11 < var10.length; ++var11) {
               FunctionAlias.JavaMethod var12 = var10[var11];
               Class[] var13 = var12.getColumnClasses();
               int var14 = 1;
               int var15 = var12.hasConnectionParam() ? 1 : 0;

               for(int var16 = var13.length; var15 < var16; ++var15) {
                  this.parameters(var1, var2, var3, var4, var5, var7.getName(), var9.getName() + "_" + (var11 + 1), ValueToObjectConverter2.classToType(var13[var15]), var14);
                  ++var14;
               }
            }
         }
      }

   }

   private void parameters(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, String var6, String var7, TypeInfo var8, int var9) {
      DataTypeInformation var10 = InformationSchemaTable.DataTypeInformation.valueOf(var8);
      String var11;
      String var12;
      String var13;
      String var14;
      if (var10.hasCharsetAndCollation) {
         var11 = var3;
         var12 = var4;
         var13 = "Unicode";
         var14 = var5;
      } else {
         var14 = null;
         var13 = null;
         var12 = null;
         var11 = null;
      }

      this.add(var1, var2, new Object[]{var3, var6, var7, ValueInteger.get(var9), "IN", "NO", DataType.isLargeObject(var8.getValueType()) ? "YES" : "NO", "P" + var9, this.identifier(var10.dataType), var10.characterPrecision, var10.characterPrecision, var11, var12, var13, var11, var12, var14, var10.numericPrecision, var10.numericPrecisionRadix, var10.numericScale, var10.datetimePrecision, var10.intervalType, var10.intervalPrecision, var10.maximumCardinality, Integer.toString(var9), var10.declaredDataType, var10.declaredNumericPrecision, var10.declaredNumericScale, null, var10.geometryType, var10.geometrySrid});
   }

   private void referentialConstraints(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType() == Constraint.Type.REFERENTIAL && this.checkIndex(var1, var4x.getName(), var2, var3)).forEach((var4x) -> this.referentialConstraints(var1, var4, var5, (ConstraintReferential)var4x));
   }

   private void referentialConstraints(SessionLocal var1, ArrayList<Row> var2, String var3, ConstraintReferential var4) {
      ConstraintUnique var5 = var4.getReferencedConstraint();
      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var3, var5.getSchema().getName(), var5.getName(), "NONE", var4.getUpdateAction().getSqlName(), var4.getDeleteAction().getSqlName()});
   }

   private void routines(SessionLocal var1, ArrayList<Row> var2, String var3) {
      boolean var4 = var1.getUser().isAdmin();
      String var5 = this.database.getMainSchema().getName();
      String var6 = this.database.getCompareMode().getName();

      label65:
      for(Schema var8 : this.database.getAllSchemas()) {
         String var9 = var8.getName();
         Iterator var10 = var8.getAllFunctionsAndAggregates().iterator();

         while(true) {
            String var12;
            FunctionAlias var13;
            FunctionAlias.JavaMethod[] var14;
            while(true) {
               if (!var10.hasNext()) {
                  continue label65;
               }

               UserDefinedFunction var11 = (UserDefinedFunction)var10.next();
               var12 = var11.getName();
               if (var11 instanceof FunctionAlias) {
                  var13 = (FunctionAlias)var11;

                  try {
                     var14 = var13.getJavaMethods();
                     break;
                  } catch (DbException var20) {
                  }
               } else {
                  this.routines(var1, var2, var3, var5, var6, var9, var12, var12, "AGGREGATE", (String)null, var11.getJavaClassName(), TypeInfo.TYPE_NULL, false, var11.getComment());
               }
            }

            for(int var15 = 0; var15 < var14.length; ++var15) {
               FunctionAlias.JavaMethod var16 = var14[var15];
               TypeInfo var17 = var16.getDataType();
               String var18;
               if (var17 != null && var17.getValueType() == 0) {
                  var18 = "PROCEDURE";
                  var17 = null;
               } else {
                  var18 = "FUNCTION";
               }

               String var19 = var13.getJavaClassName();
               this.routines(var1, var2, var3, var5, var6, var9, var12, var12 + "_" + (var15 + 1), var18, var4 ? var13.getSource() : null, var19 != null ? var19 + "." + var13.getJavaMethodName() : null, var17, var13.isDeterministic(), var13.getComment());
            }
         }
      }

   }

   private void routines(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, String var6, String var7, String var8, String var9, String var10, String var11, TypeInfo var12, boolean var13, String var14) {
      DataTypeInformation var15 = var12 != null ? InformationSchemaTable.DataTypeInformation.valueOf(var12) : InformationSchemaTable.DataTypeInformation.NULL;
      String var16;
      String var17;
      String var18;
      String var19;
      if (var15.hasCharsetAndCollation) {
         var16 = var3;
         var17 = var4;
         var18 = "Unicode";
         var19 = var5;
      } else {
         var19 = null;
         var18 = null;
         var17 = null;
         var16 = null;
      }

      this.add(var1, var2, new Object[]{var3, var6, var8, var3, var6, var7, var9, this.identifier(var15.dataType), var15.characterPrecision, var15.characterPrecision, var16, var17, var18, var16, var17, var19, var15.numericPrecision, var15.numericPrecisionRadix, var15.numericScale, var15.datetimePrecision, var15.intervalType, var15.intervalPrecision, var15.maximumCardinality, "RESULT", "EXTERNAL", var10, var11, "JAVA", "GENERAL", var13 ? "YES" : "NO", var15.declaredDataType, var15.declaredNumericPrecision, var15.declaredNumericScale, var15.geometryType, var15.geometrySrid, var14});
   }

   private void schemata(SessionLocal var1, ArrayList<Row> var2, String var3) {
      String var4 = this.database.getMainSchema().getName();
      String var5 = this.database.getCompareMode().getName();

      for(Schema var7 : this.database.getAllSchemas()) {
         this.add(var1, var2, new Object[]{var3, var7.getName(), this.identifier(var7.getOwner().getName()), var3, var4, "Unicode", null, var5, var7.getComment()});
      }

   }

   private void sequences(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      for(Schema var7 : this.database.getAllSchemas()) {
         for(Sequence var9 : var7.getAllSequences()) {
            if (!var9.getBelongsToTable()) {
               String var10 = var9.getName();
               if (this.checkIndex(var1, var10, var2, var3)) {
                  this.sequences(var1, var4, var5, var9, var10);
               }
            }
         }
      }

   }

   private void sequences(SessionLocal var1, ArrayList<Row> var2, String var3, Sequence var4, String var5) {
      DataTypeInformation var6 = InformationSchemaTable.DataTypeInformation.valueOf(var4.getDataType());
      Sequence.Cycle var7 = var4.getCycle();
      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var5, var6.dataType, ValueInteger.get(var4.getEffectivePrecision()), var6.numericPrecisionRadix, var6.numericScale, ValueBigint.get(var4.getStartValue()), ValueBigint.get(var4.getMinValue()), ValueBigint.get(var4.getMaxValue()), ValueBigint.get(var4.getIncrement()), var7.isCycle() ? "YES" : "NO", var6.declaredDataType, var6.declaredNumericPrecision, var6.declaredNumericScale, var7 != Sequence.Cycle.EXHAUSTED ? ValueBigint.get(var4.getBaseValue()) : null, ValueBigint.get(var4.getCacheSize()), var4.getComment()});
   }

   private void tables(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      this.getAllTables(var1, var2, var3).forEach((var4x) -> this.tables(var1, var4, var5, var4x));
   }

   private void tables(SessionLocal var1, ArrayList<Row> var2, String var3, Table var4) {
      String var5;
      String var6;
      if (var4.isTemporary()) {
         var5 = var4.getOnCommitTruncate() ? "DELETE" : (var4.getOnCommitDrop() ? "DROP" : "PRESERVE");
         var6 = var4.isGlobalTemporary() ? "GLOBAL TEMPORARY" : "LOCAL TEMPORARY";
      } else {
         var5 = null;
         switch (var4.getTableType()) {
            case TABLE_LINK:
               var6 = "TABLE LINK";
               break;
            case EXTERNAL_TABLE_ENGINE:
               var6 = "EXTERNAL";
               break;
            default:
               var6 = var4.isPersistIndexes() ? "CACHED" : "MEMORY";
         }
      }

      long var7 = var4.getMaxDataModificationId();
      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var4.getSQLTableType(), var4.isInsertable() ? "YES" : "NO", var5, var6, var4.getComment(), var7 != Long.MAX_VALUE ? ValueBigint.get(var7) : null, var4.getClass().getName(), ValueBigint.get(var4.getRowCountApproximation(var1))});
   }

   private void tableConstraints(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType() != Constraint.Type.DOMAIN && this.checkIndex(var1, var4x.getTable().getName(), var2, var3)).forEach((var4x) -> this.tableConstraints(var1, var4, var5, var4x));
   }

   private void tableConstraints(SessionLocal var1, ArrayList<Row> var2, String var3, Constraint var4) {
      Constraint.Type var5 = var4.getConstraintType();
      Table var6 = var4.getTable();
      Index var7 = var4.getIndex();
      boolean var8;
      if (var5 != Constraint.Type.REFERENTIAL) {
         var8 = true;
      } else {
         var8 = this.database.getReferentialIntegrity() && var6.getCheckForeignKeyConstraints() && var4.getRefTable().getCheckForeignKeyConstraints();
      }

      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var5.getSqlName(), var3, var6.getSchema().getName(), var6.getName(), "NO", "NO", var8 ? "YES" : "NO", var5 == Constraint.Type.UNIQUE ? nullsDistinctToString(((ConstraintUnique)var4).getNullsDistinct()) : null, var7 != null ? var3 : null, var7 != null ? var7.getSchema().getName() : null, var7 != null ? var7.getName() : null, var4.getComment()});
   }

   private void tablePrivileges(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      for(Right var7 : this.database.getAllRights()) {
         DbObject var8 = var7.getGrantedObject();
         if (var8 instanceof Table) {
            Table var9 = (Table)var8;
            if (this.checkIndex(var1, var9.getName(), var2, var3)) {
               this.addPrivileges(var1, var4, var7.getGrantee(), var5, var9, (String)null, var7.getRightMask());
            }
         }
      }

   }

   private void triggers(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      for(Schema var7 : this.database.getAllSchemas()) {
         for(TriggerObject var9 : var7.getAllTriggers()) {
            Table var10 = var9.getTable();
            String var11 = var10.getName();
            if (this.checkIndex(var1, var11, var2, var3)) {
               int var12 = var9.getTypeMask();
               if ((var12 & 1) != 0) {
                  this.triggers(var1, var4, var5, var9, "INSERT", var10, var11);
               }

               if ((var12 & 2) != 0) {
                  this.triggers(var1, var4, var5, var9, "UPDATE", var10, var11);
               }

               if ((var12 & 4) != 0) {
                  this.triggers(var1, var4, var5, var9, "DELETE", var10, var11);
               }

               if ((var12 & 8) != 0) {
                  this.triggers(var1, var4, var5, var9, "SELECT", var10, var11);
               }
            }
         }
      }

   }

   private void triggers(SessionLocal var1, ArrayList<Row> var2, String var3, TriggerObject var4, String var5, Table var6, String var7) {
      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var5, var3, var6.getSchema().getName(), var7, var4.isRowBased() ? "ROW" : "STATEMENT", var4.isInsteadOf() ? "INSTEAD OF" : (var4.isBefore() ? "BEFORE" : "AFTER"), ValueBoolean.get(var4.isOnRollback()), var4.getTriggerClassName(), ValueInteger.get(var4.getQueueSize()), ValueBoolean.get(var4.isNoWait()), var4.getComment()});
   }

   private void views(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      this.getAllTables(var1, var2, var3).filter(Table::isView).forEach((var4x) -> this.views(var1, var4, var5, var4x));
   }

   private void views(SessionLocal var1, ArrayList<Row> var2, String var3, Table var4) {
      String var6 = "VALID";
      String var5;
      if (var4 instanceof TableView) {
         TableView var7 = (TableView)var4;
         var5 = var7.getQuerySQL();
         if (var7.isInvalid()) {
            var6 = "INVALID";
         }
      } else {
         var5 = null;
      }

      int var11 = 0;
      ArrayList var8 = var4.getTriggers();
      if (var8 != null) {
         for(TriggerObject var10 : var8) {
            if (var10.isInsteadOf()) {
               var11 |= var10.getTypeMask();
            }
         }
      }

      this.add(var1, var2, new Object[]{var3, var4.getSchema().getName(), var4.getName(), var5, "NONE", "NO", "NO", (var11 & 2) != 0 ? "YES" : "NO", (var11 & 4) != 0 ? "YES" : "NO", (var11 & 1) != 0 ? "YES" : "NO", var6, var4.getComment()});
   }

   private void constants(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5) {
      String var6 = this.database.getMainSchema().getName();
      String var7 = this.database.getCompareMode().getName();

      for(Schema var9 : this.database.getAllSchemas()) {
         for(Constant var11 : var9.getAllConstants()) {
            String var12 = var11.getName();
            if (this.checkIndex(var1, var12, var2, var3)) {
               this.constants(var1, var4, var5, var6, var7, var11, var12);
            }
         }
      }

   }

   private void constants(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, Constant var6, String var7) {
      ValueExpression var8 = var6.getValue();
      TypeInfo var9 = var8.getType();
      DataTypeInformation var10 = InformationSchemaTable.DataTypeInformation.valueOf(var9);
      String var11;
      String var12;
      String var13;
      String var14;
      if (var10.hasCharsetAndCollation) {
         var11 = var3;
         var12 = var4;
         var13 = "Unicode";
         var14 = var5;
      } else {
         var14 = null;
         var13 = null;
         var12 = null;
         var11 = null;
      }

      this.add(var1, var2, new Object[]{var3, var6.getSchema().getName(), var7, var8.getSQL(0), var10.dataType, var10.characterPrecision, var10.characterPrecision, var11, var12, var13, var11, var12, var14, var10.numericPrecision, var10.numericPrecisionRadix, var10.numericScale, var10.datetimePrecision, var10.intervalType, var10.intervalPrecision, var10.maximumCardinality, "TYPE", var10.declaredDataType, var10.declaredNumericPrecision, var10.declaredNumericScale, var10.geometryType, var10.geometrySrid, var6.getComment()});
   }

   private void enumValues(SessionLocal var1, ArrayList<Row> var2, String var3, String var4, String var5, String var6, String var7, TypeInfo var8) {
      ExtTypeInfoEnum var9 = (ExtTypeInfoEnum)var8.getExtTypeInfo();
      if (var9 != null) {
         int var10 = 0;
         int var11 = var1.zeroBasedEnums() ? 0 : 1;

         for(int var12 = var9.getCount(); var10 < var12; ++var11) {
            this.add(var1, var2, new Object[]{var3, var4, var5, var6, var7, var9.getEnumerator(var10), ValueInteger.get(var11)});
            ++var10;
         }

      }
   }

   private void indexes(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4, String var5, boolean var6) {
      this.getAllTables(var1, var2, var3).forEach((var5x) -> this.indexes(var1, var4, var5, var6, var5x));
   }

   private void indexes(SessionLocal var1, ArrayList<Row> var2, String var3, boolean var4, Table var5) {
      for(Index var7 : var5.getIndexes()) {
         if (var7.getCreateSQL() != null) {
            if (var4) {
               this.indexColumns(var1, var2, var3, var5, var7);
            } else {
               this.indexes(var1, var2, var3, var5, var7);
            }
         }
      }

   }

   private void indexes(SessionLocal var1, ArrayList<Row> var2, String var3, Table var4, Index var5) {
      IndexType var6 = var5.getIndexType();
      this.add(var1, var2, new Object[]{var3, var5.getSchema().getName(), var5.getName(), var3, var4.getSchema().getName(), var4.getName(), var6.getSQL(false), nullsDistinctToString(var6.getNullsDistinct()), ValueBoolean.get(var6.getBelongsToConstraint()), var5.getComment(), var5.getClass().getName()});
   }

   private void indexColumns(SessionLocal var1, ArrayList<Row> var2, String var3, Table var4, Index var5) {
      IndexColumn[] var6 = var5.getIndexColumns();
      int var7 = var5.getUniqueColumnCount();
      int var8 = 0;
      int var9 = var6.length;

      while(var8 < var9) {
         IndexColumn var10 = var6[var8];
         int var11 = var10.sortType;
         Object[] var10003 = new Object[]{var3, var5.getSchema().getName(), var5.getName(), var3, var4.getSchema().getName(), var4.getName(), var10.column.getName(), null, null, null, null};
         ++var8;
         var10003[7] = ValueInteger.get(var8);
         var10003[8] = (var11 & 1) == 0 ? "ASC" : "DESC";
         var10003[9] = (var11 & 2) != 0 ? "FIRST" : ((var11 & 4) != 0 ? "LAST" : null);
         var10003[10] = ValueBoolean.get(var8 <= var7);
         this.add(var1, var2, var10003);
      }

   }

   private void inDoubt(SessionLocal var1, ArrayList<Row> var2) {
      if (var1.getUser().isAdmin()) {
         for(InDoubtTransaction var5 : this.database.getInDoubtTransactions()) {
            this.add(var1, var2, new Object[]{var5.getTransactionName(), var5.getStateDescription()});
         }
      }

   }

   private void locks(SessionLocal var1, ArrayList<Row> var2) {
      if (var1.getUser().isAdmin()) {
         for(SessionLocal var6 : this.database.getSessions(false)) {
            this.locks(var1, var2, var6);
         }
      } else {
         this.locks(var1, var2, var1);
      }

   }

   private void locks(SessionLocal var1, ArrayList<Row> var2, SessionLocal var3) {
      for(Table var5 : var3.getLocks()) {
         this.add(var1, var2, new Object[]{var5.getSchema().getName(), var5.getName(), ValueInteger.get(var3.getId()), var5.isLockedExclusivelyBy(var3) ? "WRITE" : "READ"});
      }

   }

   private void queryStatistics(SessionLocal var1, ArrayList<Row> var2) {
      QueryStatisticsData var3 = this.database.getQueryStatisticsData();
      if (var3 != null) {
         for(QueryStatisticsData.QueryEntry var5 : var3.getQueries()) {
            this.add(var1, var2, new Object[]{var5.sqlStatement, ValueInteger.get(var5.count), ValueDouble.get((double)var5.executionTimeMinNanos / (double)1000000.0F), ValueDouble.get((double)var5.executionTimeMaxNanos / (double)1000000.0F), ValueDouble.get((double)var5.executionTimeCumulativeNanos / (double)1000000.0F), ValueDouble.get(var5.executionTimeMeanNanos / (double)1000000.0F), ValueDouble.get(var5.getExecutionTimeStandardDeviation() / (double)1000000.0F), ValueBigint.get(var5.rowCountMin), ValueBigint.get(var5.rowCountMax), ValueBigint.get(var5.rowCountCumulative), ValueDouble.get(var5.rowCountMean), ValueDouble.get(var5.getRowCountStandardDeviation())});
         }
      }

   }

   private void rights(SessionLocal var1, Value var2, Value var3, ArrayList<Row> var4) {
      if (var1.getUser().isAdmin()) {
         for(Right var6 : this.database.getAllRights()) {
            Role var7 = var6.getGrantedRole();
            DbObject var8 = var6.getGrantee();
            String var9 = var8.getType() == 2 ? "USER" : "ROLE";
            if (var7 == null) {
               DbObject var10 = var6.getGrantedObject();
               Schema var11 = null;
               Table var12 = null;
               if (var10 != null) {
                  if (var10 instanceof Schema) {
                     var11 = (Schema)var10;
                  } else if (var10 instanceof Table) {
                     var12 = (Table)var10;
                     var11 = var12.getSchema();
                  }
               }

               String var13 = var12 != null ? var12.getName() : "";
               String var14 = var11 != null ? var11.getName() : "";
               if (this.checkIndex(var1, var13, var2, var3)) {
                  this.add(var1, var4, new Object[]{this.identifier(var8.getName()), var9, null, var6.getRights(), var14, var13});
               }
            } else {
               this.add(var1, var4, new Object[]{this.identifier(var8.getName()), var9, this.identifier(var7.getName()), null, null, null});
            }
         }

      }
   }

   private void roles(SessionLocal var1, ArrayList<Row> var2) {
      boolean var3 = var1.getUser().isAdmin();

      for(RightOwner var5 : this.database.getAllUsersAndRoles()) {
         if (var5 instanceof Role) {
            Role var6 = (Role)var5;
            if (var3 || var1.getUser().isRoleGranted(var6)) {
               this.add(var1, var2, new Object[]{this.identifier(var6.getName()), var6.getComment()});
            }
         }
      }

   }

   private void sessions(SessionLocal var1, ArrayList<Row> var2) {
      if (var1.getUser().isAdmin()) {
         for(SessionLocal var6 : this.database.getSessions(false)) {
            this.sessions(var1, var2, var6);
         }
      } else {
         this.sessions(var1, var2, var1);
      }

   }

   private void sessions(SessionLocal var1, ArrayList<Row> var2, SessionLocal var3) {
      NetworkConnectionInfo var4 = var3.getNetworkConnectionInfo();
      Command var5 = var3.getCurrentCommand();
      int var6 = var3.getBlockingSessionId();
      User var7 = var3.getUser();
      if (var7 != null) {
         this.add(var1, var2, new Object[]{ValueInteger.get(var3.getId()), var7.getName(), var4 == null ? null : var4.getServer(), var4 == null ? null : var4.getClient(), var4 == null ? null : var4.getClientInfo(), var3.getSessionStart(), var3.getIsolationLevel().getSQL(), var5 == null ? null : var5.toString(), var5 == null ? null : var3.getCommandStartOrEnd(), ValueBoolean.get(var3.hasPendingTransaction()), String.valueOf(var3.getState()), var6 == 0 ? null : ValueInteger.get(var6), var3.getState() == SessionLocal.State.SLEEP ? var3.getCommandStartOrEnd() : null});
      }
   }

   private void sessionState(SessionLocal var1, ArrayList<Row> var2) {
      for(String var6 : var1.getVariableNames()) {
         Value var7 = var1.getVariable(var6);
         StringBuilder var8 = (new StringBuilder()).append("SET @").append(var6).append(' ');
         var7.getSQL(var8, 0);
         this.add(var1, var2, new Object[]{"@" + var6, var8.toString()});
      }

      for(Table var11 : var1.getLocalTempTables()) {
         this.add(var1, var2, new Object[]{"TABLE " + var11.getName(), var11.getCreateSQL()});
      }

      String[] var10 = var1.getSchemaSearchPath();
      if (var10 != null && var10.length > 0) {
         StringBuilder var12 = new StringBuilder("SET SCHEMA_SEARCH_PATH ");
         int var14 = 0;

         for(int var16 = var10.length; var14 < var16; ++var14) {
            if (var14 > 0) {
               var12.append(", ");
            }

            StringUtils.quoteIdentifier(var12, var10[var14]);
         }

         this.add(var1, var2, new Object[]{"SCHEMA_SEARCH_PATH", var12.toString()});
      }

      String var13 = var1.getCurrentSchemaName();
      if (var13 != null) {
         this.add(var1, var2, new Object[]{"SCHEMA", StringUtils.quoteIdentifier(new StringBuilder("SET SCHEMA "), var13).toString()});
      }

      TimeZoneProvider var15 = var1.currentTimeZone();
      if (!var15.equals(DateTimeUtils.getTimeZone())) {
         this.add(var1, var2, new Object[]{"TIME ZONE", StringUtils.quoteStringSQL(new StringBuilder("SET TIME ZONE "), var15.getId()).toString()});
      }

   }

   private void settings(SessionLocal var1, ArrayList<Row> var2) {
      for(Setting var4 : this.database.getAllSettings()) {
         String var5 = var4.getStringValue();
         if (var5 == null) {
            var5 = Integer.toString(var4.getIntValue());
         }

         this.add(var1, var2, new Object[]{this.identifier(var4.getName()), var5});
      }

      this.add(var1, var2, new Object[]{"info.BUILD_ID", "240"});
      this.add(var1, var2, new Object[]{"info.VERSION_MAJOR", "2"});
      this.add(var1, var2, new Object[]{"info.VERSION_MINOR", "4"});
      this.add(var1, var2, new Object[]{"info.VERSION", Constants.FULL_VERSION});
      if (var1.getUser().isAdmin()) {
         String[] var8 = new String[]{"java.runtime.version", "java.vm.name", "java.vendor", "os.name", "os.arch", "os.version", "sun.os.patch.level", "file.separator", "path.separator", "line.separator", "user.country", "user.language", "user.variant", "file.encoding"};

         for(String var7 : var8) {
            this.add(var1, var2, new Object[]{"property." + var7, Utils.getProperty(var7, "")});
         }
      }

      this.add(var1, var2, new Object[]{"QUERY_TIMEOUT", Integer.toString(var1.getQueryTimeout())});
      this.add(var1, var2, new Object[]{"TIME ZONE", var1.currentTimeZone().getId()});
      this.add(var1, var2, new Object[]{"TRUNCATE_LARGE_LENGTH", var1.isTruncateLargeLength() ? "TRUE" : "FALSE"});
      this.add(var1, var2, new Object[]{"VARIABLE_BINARY", var1.isVariableBinary() ? "TRUE" : "FALSE"});
      this.add(var1, var2, new Object[]{"OLD_INFORMATION_SCHEMA", var1.isOldInformationSchema() ? "TRUE" : "FALSE"});
      BitSet var9 = var1.getNonKeywords();
      if (var9 != null) {
         this.add(var1, var2, new Object[]{"NON_KEYWORDS", ParserBase.formatNonKeywords(var9)});
      }

      this.database.populateInfo((var3, var4x) -> this.add(var1, var2, new Object[]{var3, var4x}));
   }

   private void synonyms(SessionLocal var1, ArrayList<Row> var2, String var3) {
      for(TableSynonym var5 : this.database.getAllSynonyms()) {
         this.add(var1, var2, new Object[]{var3, var5.getSchema().getName(), var5.getName(), var5.getSynonymForName(), var5.getSynonymForSchema().getName(), "SYNONYM", "VALID", var5.getComment()});
      }

   }

   private void users(SessionLocal var1, ArrayList<Row> var2) {
      User var3 = var1.getUser();
      if (var3.isAdmin()) {
         for(RightOwner var5 : this.database.getAllUsersAndRoles()) {
            if (var5 instanceof User) {
               this.users(var1, var2, (User)var5);
            }
         }
      } else {
         this.users(var1, var2, var3);
      }

   }

   private void users(SessionLocal var1, ArrayList<Row> var2, User var3) {
      this.add(var1, var2, new Object[]{this.identifier(var3.getName()), ValueBoolean.get(var3.isAdmin()), var3.getComment()});
   }

   private void addConstraintColumnUsage(SessionLocal var1, ArrayList<Row> var2, String var3, Constraint var4, Column var5) {
      Table var6 = var5.getTable();
      this.add(var1, var2, new Object[]{var3, var6.getSchema().getName(), var6.getName(), var5.getName(), var3, var4.getSchema().getName(), var4.getName()});
   }

   private void addPrivileges(SessionLocal var1, ArrayList<Row> var2, DbObject var3, String var4, Table var5, String var6, int var7) {
      if ((var7 & 1) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "SELECT");
      }

      if ((var7 & 4) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "INSERT");
      }

      if ((var7 & 8) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "UPDATE");
      }

      if ((var7 & 2) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "DELETE");
      }

   }

   private void addPrivilege(SessionLocal var1, ArrayList<Row> var2, DbObject var3, String var4, Table var5, String var6, String var7) {
      String var8 = "NO";
      if (var3.getType() == 2) {
         User var9 = (User)var3;
         if (var9.isAdmin()) {
            var8 = "YES";
         }
      }

      if (var6 == null) {
         this.add(var1, var2, new Object[]{null, this.identifier(var3.getName()), var4, var5.getSchema().getName(), var5.getName(), var7, var8, "NO"});
      } else {
         this.add(var1, var2, new Object[]{null, this.identifier(var3.getName()), var4, var5.getSchema().getName(), var5.getName(), var6, var7, var8});
      }

   }

   private static String nullsDistinctToString(NullsDistinct var0) {
      if (var0 != null) {
         switch (var0) {
            case DISTINCT:
               return "YES";
            case ALL_DISTINCT:
               return "ALL";
            case NOT_DISTINCT:
               return "NO";
         }
      }

      return null;
   }

   public long getMaxDataModificationId() {
      switch (this.type) {
         case 15:
         case 25:
         case 26:
         case 30:
         case 31:
         case 32:
            return Long.MAX_VALUE;
         case 16:
         case 17:
         case 18:
         case 19:
         case 20:
         case 21:
         case 22:
         case 23:
         case 24:
         case 27:
         case 28:
         case 29:
         default:
            return this.database.getModificationDataId();
      }
   }

   public boolean isView() {
      return this.isView;
   }

   public long getRowCount(SessionLocal var1) {
      return this.getRowCount(var1, false);
   }

   public long getRowCountApproximation(SessionLocal var1) {
      return this.getRowCount(var1, true);
   }

   private long getRowCount(SessionLocal var1, boolean var2) {
      switch (this.type) {
         case 0:
            return 1L;
         case 2:
            Locale[] var8 = CompareMode.getCollationLocales(var2);
            if (var8 != null) {
               return (long)(var8.length + 1);
            }
            break;
         case 14:
            return (long)var1.getDatabase().getAllSchemas().size();
         case 25:
            if (var1.getUser().isAdmin()) {
               return (long)var1.getDatabase().getInDoubtTransactions().size();
            }

            return 0L;
         case 29:
            if (var1.getUser().isAdmin()) {
               long var7 = 0L;

               for(RightOwner var10 : var1.getDatabase().getAllUsersAndRoles()) {
                  if (var10 instanceof Role) {
                     ++var7;
                  }
               }

               return var7;
            }
            break;
         case 30:
            if (var1.getUser().isAdmin()) {
               return (long)var1.getDatabase().getSessionCount();
            }

            return 1L;
         case 34:
            if (var1.getUser().isAdmin()) {
               long var3 = 0L;

               for(RightOwner var6 : var1.getDatabase().getAllUsersAndRoles()) {
                  if (var6 instanceof User) {
                     ++var3;
                  }
               }

               return var3;
            }

            return 1L;
      }

      if (var2) {
         return 1000L;
      } else {
         throw DbException.getInternalError(this.toString());
      }
   }

   public boolean canGetRowCount(SessionLocal var1) {
      switch (this.type) {
         case 0:
         case 2:
         case 14:
         case 25:
         case 30:
         case 34:
            return true;
         case 29:
            if (var1.getUser().isAdmin()) {
               return true;
            }
         default:
            return false;
      }
   }

   static final class DataTypeInformation {
      static final DataTypeInformation NULL = new DataTypeInformation((String)null, (Value)null, (Value)null, (Value)null, (Value)null, (Value)null, (Value)null, (Value)null, (Value)null, false, (String)null, (Value)null, (Value)null, (String)null, (Value)null);
      final String dataType;
      final Value characterPrecision;
      final Value numericPrecision;
      final Value numericPrecisionRadix;
      final Value numericScale;
      final Value datetimePrecision;
      final Value intervalPrecision;
      final Value intervalType;
      final Value maximumCardinality;
      final boolean hasCharsetAndCollation;
      final String declaredDataType;
      final Value declaredNumericPrecision;
      final Value declaredNumericScale;
      final String geometryType;
      final Value geometrySrid;

      static DataTypeInformation valueOf(TypeInfo var0) {
         int var1 = var0.getValueType();
         String var2 = Value.getTypeName(var1);
         ValueBigint var3 = null;
         ValueInteger var4 = null;
         ValueInteger var5 = null;
         ValueInteger var6 = null;
         ValueInteger var7 = null;
         ValueInteger var8 = null;
         ValueInteger var9 = null;
         String var10 = null;
         boolean var11 = false;
         String var12 = null;
         ValueInteger var13 = null;
         ValueInteger var14 = null;
         String var15 = null;
         ValueInteger var16 = null;
         switch (var1) {
            case 1:
            case 2:
            case 3:
            case 4:
               var11 = true;
            case 5:
            case 6:
            case 7:
            case 35:
            case 38:
               var3 = ValueBigint.get(var0.getPrecision());
            case 8:
            case 36:
            case 39:
            default:
               break;
            case 9:
            case 10:
            case 11:
            case 12:
               var4 = ValueInteger.get(MathUtils.convertLongToInt(var0.getPrecision()));
               var5 = ValueInteger.get(0);
               var6 = ValueInteger.get(2);
               var12 = var2;
               break;
            case 13:
               var4 = ValueInteger.get(MathUtils.convertLongToInt(var0.getPrecision()));
               var5 = ValueInteger.get(var0.getScale());
               var6 = ValueInteger.get(10);
               var12 = var0.getExtTypeInfo() != null ? "DECIMAL" : "NUMERIC";
               if (var0.getDeclaredPrecision() >= 0L) {
                  var13 = var4;
               }

               if (var0.getDeclaredScale() >= 0) {
                  var14 = var5;
               }
               break;
            case 14:
            case 15:
               var4 = ValueInteger.get(MathUtils.convertLongToInt(var0.getPrecision()));
               var6 = ValueInteger.get(2);
               long var20 = var0.getDeclaredPrecision();
               if (var20 >= 0L) {
                  var12 = "FLOAT";
                  if (var20 > 0L) {
                     var13 = ValueInteger.get((int)var20);
                  }
               } else {
                  var12 = var2;
               }
               break;
            case 16:
               var4 = ValueInteger.get(MathUtils.convertLongToInt(var0.getPrecision()));
               var6 = ValueInteger.get(10);
               var12 = var2;
               if (var0.getDeclaredPrecision() >= 0L) {
                  var13 = var4;
               }
               break;
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
            case 33:
            case 34:
               var10 = IntervalQualifier.valueOf(var1 - 22).toString();
               var2 = "INTERVAL";
               var8 = ValueInteger.get(MathUtils.convertLongToInt(var0.getPrecision()));
            case 17:
            case 18:
            case 19:
            case 20:
            case 21:
               var7 = ValueInteger.get(var0.getScale());
               break;
            case 37:
               ExtTypeInfoGeometry var17 = (ExtTypeInfoGeometry)var0.getExtTypeInfo();
               if (var17 != null) {
                  int var18 = var17.getType();
                  if (var18 != 0) {
                     var15 = EWKTUtils.formatGeometryTypeAndDimensionSystem(new StringBuilder(), var18).toString();
                  }

                  Integer var19 = var17.getSrid();
                  if (var19 != null) {
                     var16 = ValueInteger.get(var19);
                  }
               }
               break;
            case 40:
               var9 = ValueInteger.get(MathUtils.convertLongToInt(var0.getPrecision()));
         }

         return new DataTypeInformation(var2, var3, var4, var6, var5, var7, var8, (Value)(var10 != null ? ValueVarchar.get(var10) : ValueNull.INSTANCE), var9, var11, var12, var13, var14, var15, var16);
      }

      private DataTypeInformation(String var1, Value var2, Value var3, Value var4, Value var5, Value var6, Value var7, Value var8, Value var9, boolean var10, String var11, Value var12, Value var13, String var14, Value var15) {
         this.dataType = var1;
         this.characterPrecision = var2;
         this.numericPrecision = var3;
         this.numericPrecisionRadix = var4;
         this.numericScale = var5;
         this.datetimePrecision = var6;
         this.intervalPrecision = var7;
         this.intervalType = var8;
         this.maximumCardinality = var9;
         this.hasCharsetAndCollation = var10;
         this.declaredDataType = var11;
         this.declaredNumericPrecision = var12;
         this.declaredNumericScale = var13;
         this.geometryType = var14;
         this.geometrySrid = var15;
      }
   }
}
