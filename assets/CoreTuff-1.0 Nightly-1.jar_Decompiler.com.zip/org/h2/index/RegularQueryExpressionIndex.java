package org.h2.index;

import java.util.ArrayList;
import org.h2.command.query.AllColumnsForPlan;
import org.h2.command.query.Query;
import org.h2.engine.SessionLocal;
import org.h2.expression.Parameter;
import org.h2.result.SearchRow;
import org.h2.result.SortOrder;
import org.h2.table.Column;
import org.h2.table.IndexColumn;
import org.h2.table.QueryExpressionTable;
import org.h2.table.TableFilter;
import org.h2.util.IntArray;
import org.h2.value.Value;

public final class RegularQueryExpressionIndex extends QueryExpressionIndex implements SpatialIndex {
   private final int[] indexMasks;
   private final long evaluatedAt;

   public RegularQueryExpressionIndex(QueryExpressionTable var1, String var2, ArrayList<Parameter> var3, SessionLocal var4, int[] var5) {
      super(var1, var2, var3);
      this.indexMasks = var5;
      Query var6 = var4.prepareQueryExpression(var2, var1.getQueryScope());
      if (var5 != null && var6.allowGlobalConditions()) {
         var6 = this.addConditions(var1, var2, var3, var4, var5, var6);
      }

      var6.preparePlan();
      this.query = var6;
      this.evaluatedAt = var1.getTopQuery() == null ? System.nanoTime() : 0L;
   }

   private Query addConditions(QueryExpressionTable var1, String var2, ArrayList<Parameter> var3, SessionLocal var4, int[] var5, Query var6) {
      int var7 = var1.getParameterOffset(var3);
      IntArray var8 = new IntArray();
      int var9 = 0;

      for(int var10 = 0; var10 < var5.length; ++var10) {
         int var11 = var5[var10];
         if (var11 != 0) {
            ++var9;
            int var12 = Integer.bitCount(var11);

            for(int var13 = 0; var13 < var12; ++var13) {
               var8.add(var10);
            }
         }
      }

      int var17 = var8.size();
      ArrayList var18 = new ArrayList(var17);
      int var19 = 0;

      while(var19 < var17) {
         int var22 = var8.get(var19);
         var18.add(var1.getColumn(var22));
         int var14 = var5[var22];
         if ((var14 & 1) != 0) {
            Parameter var15 = new Parameter(var7 + var19);
            var6.addGlobalCondition(var15, var22, 6);
            ++var19;
         }

         if ((var14 & 2) != 0) {
            Parameter var25 = new Parameter(var7 + var19);
            var6.addGlobalCondition(var25, var22, 5);
            ++var19;
         }

         if ((var14 & 4) != 0) {
            Parameter var26 = new Parameter(var7 + var19);
            var6.addGlobalCondition(var26, var22, 4);
            ++var19;
         }

         if ((var14 & 16) != 0) {
            Parameter var27 = new Parameter(var7 + var19);
            var6.addGlobalCondition(var27, var22, 8);
            ++var19;
         }
      }

      this.columns = (Column[])var18.toArray(new Column[0]);
      this.indexColumns = new IndexColumn[var9];
      this.columnIds = new int[var9];
      var19 = 0;

      for(int var23 = 0; var19 < 2; ++var19) {
         for(int var24 = 0; var24 < var5.length; ++var24) {
            int var28 = var5[var24];
            if (var28 != 0) {
               if (var19 == 0) {
                  if ((var28 & 1) == 0) {
                     continue;
                  }
               } else if ((var28 & 1) != 0) {
                  continue;
               }

               Column var16 = var1.getColumn(var24);
               this.indexColumns[var23] = new IndexColumn(var16);
               this.columnIds[var23] = var16.getColumnId();
               ++var23;
            }
         }
      }

      String var21 = var6.getPlanSQL(0);
      if (!var21.equals(var2)) {
         var6 = var4.prepareQueryExpression(var21, var1.getQueryScope());
      }

      return var6;
   }

   public boolean isExpired() {
      return this.table.getTopQuery() == null && System.nanoTime() - this.evaluatedAt > 10000000000L;
   }

   public double getCost(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6, boolean var7) {
      return this.query.getCost();
   }

   public Cursor find(SessionLocal var1, SearchRow var2, SearchRow var3, boolean var4) {
      return this.find(var1, var2, var3, (SearchRow)null);
   }

   public Cursor findByGeometry(SessionLocal var1, SearchRow var2, SearchRow var3, boolean var4, SearchRow var5) {
      assert !var4;

      return this.find(var1, var2, var3, var5);
   }

   private Cursor find(SessionLocal var1, SearchRow var2, SearchRow var3, SearchRow var4) {
      ArrayList var5 = this.query.getParameters();
      if (this.originalParameters != null) {
         for(Parameter var7 : this.originalParameters) {
            if (var7 != null) {
               int var8 = var7.getIndex();
               Value var9 = var7.getValue(var1);
               setParameter(var5, var8, var9);
            }
         }
      }

      int var10;
      if (var2 != null) {
         var10 = var2.getColumnCount();
      } else if (var3 != null) {
         var10 = var3.getColumnCount();
      } else if (var4 != null) {
         var10 = var4.getColumnCount();
      } else {
         var10 = 0;
      }

      int var11 = this.table.getParameterOffset(this.originalParameters);

      for(int var12 = 0; var12 < var10; ++var12) {
         int var13 = this.indexMasks[var12];
         if ((var13 & 1) != 0) {
            setParameter(var5, var11++, var2.getValue(var12));
         }

         if ((var13 & 2) != 0) {
            setParameter(var5, var11++, var2.getValue(var12));
         }

         if ((var13 & 4) != 0) {
            setParameter(var5, var11++, var3.getValue(var12));
         }

         if ((var13 & 16) != 0) {
            setParameter(var5, var11++, var4.getValue(var12));
         }
      }

      return new QueryExpressionCursor(this, this.query.query(0L), var2, var3);
   }

   private static void setParameter(ArrayList<Parameter> var0, int var1, Value var2) {
      if (var1 < var0.size()) {
         Parameter var3 = (Parameter)var0.get(var1);
         var3.setValue(var2);
      }
   }
}
