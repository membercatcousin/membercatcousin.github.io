package org.h2.expression;

import java.util.Arrays;
import java.util.function.Predicate;
import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.table.ColumnResolver;
import org.h2.table.TableFilter;
import org.h2.value.TypeInfo;

public abstract class OperationN extends Expression implements ExpressionWithVariableParameters {
   protected Expression[] args;
   protected int argsCount;
   protected TypeInfo type;

   protected OperationN(Expression[] var1) {
      this.args = var1;
   }

   public void addParameter(Expression var1) {
      int var2 = this.args.length;
      if (this.argsCount >= var2) {
         this.args = (Expression[])Arrays.copyOf(this.args, var2 * 2);
      }

      this.args[this.argsCount++] = var1;
   }

   public void doneWithParameters() throws DbException {
      if (this.args.length != this.argsCount) {
         this.args = (Expression[])Arrays.copyOf(this.args, this.argsCount);
      }

   }

   public TypeInfo getType() {
      return this.type;
   }

   public void mapColumns(ColumnResolver var1, int var2, int var3) {
      for(Expression var7 : this.args) {
         var7.mapColumns(var1, var2, var3);
      }

   }

   protected boolean optimizeArguments(SessionLocal var1, boolean var2) {
      int var3 = 0;

      for(int var4 = this.args.length; var3 < var4; ++var3) {
         Expression var5 = this.args[var3].optimize(var1);
         this.args[var3] = var5;
         if (var2 && !var5.isConstant()) {
            var2 = false;
         }
      }

      return var2;
   }

   protected final void inlineSubexpressions(Predicate<Expression> var1) {
      int var2 = 0;

      for(int var3 = this.args.length; var2 < var3; ++var2) {
         Expression var4 = this.args[var2];
         if (var1.test(var4)) {
            this.inlineSubexpressions(var1, var2, var3, var4);
            break;
         }
      }

   }

   private void inlineSubexpressions(Predicate<Expression> var1, int var2, int var3, Expression var4) {
      int var5 = var4.getSubexpressionCount();
      boolean var6 = false;
      boolean var7 = false;
      int var8 = var3;
      if (var5 != 1) {
         var7 = true;
         var8 = var3 + (var5 - 1);
      }

      for(int var9 = var2 + 1; var9 < var3; ++var9) {
         Expression var10 = this.args[var9];
         if (var1.test(var10)) {
            var6 = true;
            int var11 = var10.getSubexpressionCount();
            if (var11 != 1) {
               var7 = true;
               var8 += var11 - 1;
            }
         }
      }

      Expression[] var13 = this.args;
      if (var7) {
         this.args = new Expression[var8];
         System.arraycopy(var13, 0, this.args, 0, var2);
      }

      this.copyArgs(var4, var2, var5);
      if (var6) {
         int var14 = var2 + var5;

         while(true) {
            ++var2;
            if (var2 >= var3) {
               break;
            }

            Expression var15 = var13[var2];
            if (var1.test(var15)) {
               int var12 = var15.getSubexpressionCount();
               this.copyArgs(var15, var14, var12);
               var14 += var12;
            } else {
               this.args[var14++] = var15;
            }
         }
      } else if (var7) {
         System.arraycopy(var13, var2 + 1, this.args, var2 + var5, var3 - var2 - 1);
      }

   }

   private void copyArgs(Expression var1, int var2, int var3) {
      if (var1 instanceof OperationN) {
         System.arraycopy(((OperationN)var1).args, 0, this.args, var2, var3);
      } else {
         for(int var4 = 0; var4 < var3; ++var4) {
            this.args[var2 + var4] = var1.getSubexpression(var4);
         }
      }

   }

   public void setEvaluatable(TableFilter var1, boolean var2) {
      for(Expression var6 : this.args) {
         var6.setEvaluatable(var1, var2);
      }

   }

   public void updateAggregate(SessionLocal var1, int var2) {
      for(Expression var6 : this.args) {
         var6.updateAggregate(var1, var2);
      }

   }

   public boolean isEverything(ExpressionVisitor var1) {
      for(Expression var5 : this.args) {
         if (!var5.isEverything(var1)) {
            return false;
         }
      }

      return true;
   }

   public int getCost() {
      int var1 = this.args.length + 1;

      for(Expression var5 : this.args) {
         var1 += var5.getCost();
      }

      return var1;
   }

   public int getSubexpressionCount() {
      return this.args.length;
   }

   public Expression getSubexpression(int var1) {
      return this.args[var1];
   }
}
