package org.h2.index;

import java.util.Objects;
import org.h2.engine.NullsDistinct;

public class IndexType {
   private boolean primaryKey;
   private boolean persistent;
   private boolean hash;
   private boolean scan;
   private boolean spatial;
   private boolean belongsToConstraint;
   private NullsDistinct nullsDistinct;

   public static IndexType createPrimaryKey(boolean var0, boolean var1) {
      IndexType var2 = new IndexType();
      var2.primaryKey = true;
      var2.persistent = var0;
      var2.hash = var1;
      return var2;
   }

   public static IndexType createUnique(boolean var0, boolean var1, int var2, NullsDistinct var3) {
      IndexType var4 = new IndexType();
      var4.persistent = var0;
      var4.hash = var1;
      var4.nullsDistinct = var2 == 1 && var3 == NullsDistinct.ALL_DISTINCT ? NullsDistinct.DISTINCT : (NullsDistinct)Objects.requireNonNull(var3);
      return var4;
   }

   public static IndexType createNonUnique(boolean var0) {
      return createNonUnique(var0, false, false);
   }

   public static IndexType createNonUnique(boolean var0, boolean var1, boolean var2) {
      IndexType var3 = new IndexType();
      var3.persistent = var0;
      var3.hash = var1;
      var3.spatial = var2;
      return var3;
   }

   public static IndexType createScan(boolean var0) {
      IndexType var1 = new IndexType();
      var1.persistent = var0;
      var1.scan = true;
      return var1;
   }

   public void setBelongsToConstraint(boolean var1) {
      this.belongsToConstraint = var1;
   }

   public boolean getBelongsToConstraint() {
      return this.belongsToConstraint;
   }

   public boolean isHash() {
      return this.hash;
   }

   public boolean isSpatial() {
      return this.spatial;
   }

   public boolean isPersistent() {
      return this.persistent;
   }

   public boolean isPrimaryKey() {
      return this.primaryKey;
   }

   public boolean isUnique() {
      return this.primaryKey || this.nullsDistinct != null;
   }

   public String getSQL(boolean var1) {
      StringBuilder var2 = new StringBuilder();
      if (this.primaryKey) {
         var2.append("PRIMARY KEY");
         if (this.hash) {
            var2.append(" HASH");
         }
      } else {
         if (this.nullsDistinct != null) {
            var2.append("UNIQUE ");
            if (var1) {
               this.nullsDistinct.getSQL(var2, 0).append(' ');
            }
         }

         if (this.hash) {
            var2.append("HASH ");
         }

         if (this.spatial) {
            var2.append("SPATIAL ");
         }

         var2.append("INDEX");
      }

      return var2.toString();
   }

   public boolean isScan() {
      return this.scan;
   }

   public NullsDistinct getNullsDistinct() {
      return this.nullsDistinct;
   }

   public NullsDistinct getEffectiveNullsDistinct() {
      return this.nullsDistinct != null ? this.nullsDistinct : (this.primaryKey ? NullsDistinct.NOT_DISTINCT : null);
   }
}
