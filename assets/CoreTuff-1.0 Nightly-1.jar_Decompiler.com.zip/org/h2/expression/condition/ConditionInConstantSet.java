package org.h2.expression.condition;

import java.util.ArrayList;
import java.util.TreeSet;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionColumn;
import org.h2.expression.ExpressionList;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.ValueExpression;
import org.h2.index.IndexCondition;
import org.h2.table.ColumnResolver;
import org.h2.table.TableFilter;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueBoolean;
import org.h2.value.ValueNull;
import org.h2.value.ValueRow;

public final class ConditionInConstantSet extends ConditionIn {
   private final TreeSet<Value> valueSet;
   private boolean hasNull;
   private final TypeInfo type;

   ConditionInConstantSet(SessionLocal var1, Expression var2, boolean var3, boolean var4, ArrayList<Expression> var5) {
      super(var2, var3, var4, var5);
      this.valueSet = new TreeSet(var1);
      TypeInfo var6 = var2.getType();

      for(Expression var8 : var5) {
         var6 = TypeInfo.getHigherType(var6, var8.getType());
      }

      this.type = var6;

      for(Expression var10 : var5) {
         this.add(var10.getValue(var1), var1);
      }

   }

   private void add(Value var1, SessionLocal var2) {
      if ((var1 = var1.convertTo(this.type, var2)).containsNull()) {
         this.hasNull = true;
      } else {
         this.valueSet.add(var1);
      }

   }

   Value getValue(SessionLocal var1, Value var2) {
      if ((var2 = var2.convertTo(this.type, var1)).containsNull()) {
         return ValueNull.INSTANCE;
      } else {
         boolean var3 = this.valueSet.contains(var2);
         return (Value)(!var3 && this.hasNull ? ValueNull.INSTANCE : ValueBoolean.get(this.not ^ var3));
      }
   }

   public void mapColumns(ColumnResolver var1, int var2, int var3) {
      this.left.mapColumns(var1, var2, var3);
   }

   public Expression optimize(SessionLocal var1) {
      this.left = this.left.optimize(var1);
      return this;
   }

   public Expression getNotIfPossible(SessionLocal var1) {
      return this.whenOperand ? null : new ConditionInConstantSet(var1, this.left, !this.not, false, this.valueList);
   }

   void createUniqueIndexConditions(TableFilter var1, ExpressionList var2) {
      int var3 = var2.getSubexpressionCount();

      for(int var4 = 0; var4 < var3; ++var4) {
         Expression var5 = var2.getSubexpression(var4);
         if (var5 instanceof ExpressionColumn) {
            ExpressionColumn var6 = (ExpressionColumn)var5;
            if (var1 == var6.getTableFilter()) {
               ArrayList var7 = new ArrayList(this.valueList.size());

               for(Expression var9 : this.valueList) {
                  if (var9 instanceof ExpressionList) {
                     ExpressionList var10 = (ExpressionList)var9;
                     if (var10.isArray() || var10.getSubexpressionCount() != var3) {
                        return;
                     }

                     var7.add(var10.getSubexpression(var4));
                  } else {
                     if (!(var9 instanceof ValueExpression)) {
                        return;
                     }

                     Value var14 = var9.getValue((SessionLocal)null);
                     if (var14.getValueType() != 41) {
                        return;
                     }

                     Value[] var11 = ((ValueRow)var14).getList();
                     if (var3 != var11.length) {
                        return;
                     }

                     var7.add(ValueExpression.get(var11[var4]));
                  }
               }

               TypeInfo var12 = var6.getType();

               for(Expression var15 : var7) {
                  var12 = TypeInfo.getHigherType(var12, var15.getType());
               }

               createIndexConditions(var1, var6, var7, var12);
            }
         }
      }

   }

   void createIndexConditions(TableFilter var1, ExpressionColumn var2, ArrayList<Expression> var3) {
      createIndexConditions(var1, var2, var3, this.type);
   }

   private static void createIndexConditions(TableFilter var0, ExpressionColumn var1, ArrayList<Expression> var2, TypeInfo var3) {
      TypeInfo var4 = var1.getType();
      if (TypeInfo.haveSameOrdering(var4, TypeInfo.getHigherType(var4, var3))) {
         var0.addIndexCondition(IndexCondition.getInList(var1, var2));
      }

   }

   public void setEvaluatable(TableFilter var1, boolean var2) {
      this.left.setEvaluatable(var1, var2);
   }

   public void updateAggregate(SessionLocal var1, int var2) {
      this.left.updateAggregate(var1, var2);
   }

   public boolean isEverything(ExpressionVisitor var1) {
      return this.left.isEverything(var1);
   }

   public int getCost() {
      return this.left.getCost();
   }

   Expression getAdditional(SessionLocal var1, Comparison var2) {
      if (!this.not && !this.whenOperand && this.left.isEverything(ExpressionVisitor.DETERMINISTIC_VISITOR)) {
         Expression var3 = var2.getIfEquals(this.left);
         if (var3 != null && var3.isConstant()) {
            ArrayList var4 = new ArrayList(this.valueList.size() + 1);
            var4.addAll(this.valueList);
            var4.add(var3);
            return new ConditionInConstantSet(var1, this.left, false, false, var4);
         }
      }

      return null;
   }
}
