package org.h2.bnf.context;

import java.util.HashMap;
import java.util.HashSet;
import org.h2.bnf.Bnf;
import org.h2.bnf.BnfVisitor;
import org.h2.bnf.Rule;
import org.h2.bnf.RuleElement;
import org.h2.bnf.RuleHead;
import org.h2.bnf.RuleList;
import org.h2.bnf.Sentence;
import org.h2.message.DbException;
import org.h2.util.ParserUtil;
import org.h2.util.StringUtils;

public class DbContextRule implements Rule {
   public static final int COLUMN = 0;
   public static final int TABLE = 1;
   public static final int TABLE_ALIAS = 2;
   public static final int NEW_TABLE_ALIAS = 3;
   public static final int COLUMN_ALIAS = 4;
   public static final int SCHEMA = 5;
   public static final int PROCEDURE = 6;
   private final DbContents contents;
   private final int type;
   private String columnType;

   public DbContextRule(DbContents var1, int var2) {
      this.contents = var1;
      this.type = var2;
   }

   public void setColumnType(String var1) {
      this.columnType = var1;
   }

   public void setLinks(HashMap<String, RuleHead> var1) {
   }

   public void accept(BnfVisitor var1) {
   }

   public boolean autoComplete(Sentence var1) {
      String var2 = var1.getQuery();
      String var3 = var2;
      switch (this.type) {
         case 0:
            HashSet var23 = var1.getTables();
            String var26 = null;
            DbTableOrView var29 = var1.getLastMatchedTable();
            if (var29 != null && var29.getColumns() != null) {
               for(DbColumn var41 : var29.getColumns()) {
                  String var44 = var2;
                  String var47 = var41.getName();
                  if (var41.getQuotedName().length() > var47.length()) {
                     var47 = var41.getQuotedName();
                     var44 = var2;
                  }

                  if (StringUtils.startsWithIgnoringCase(var44, var47) && this.testColumnType(var41)) {
                     String var49 = var3.substring(var47.length());
                     if (var26 != null && var49.length() >= var26.length()) {
                        if ((var3.isEmpty() || StringUtils.startsWithIgnoringCase(var47, var44)) && var3.length() < var47.length()) {
                           var1.add(var41.getName(), var41.getName().substring(var3.length()), 0);
                        }
                     } else {
                        var26 = var49;
                     }
                  }
               }
            }

            for(DbSchema var42 : this.contents.getSchemas()) {
               for(DbTableOrView var14 : var42.getTables()) {
                  if ((var14 == var29 || var23 == null || var23.contains(var14)) && var14 != null && var14.getColumns() != null) {
                     for(DbColumn var18 : var14.getColumns()) {
                        String var19 = var18.getName();
                        if (this.testColumnType(var18)) {
                           if (StringUtils.startsWithIgnoringCase(var2, var19)) {
                              String var20 = var3.substring(var19.length());
                              if (var26 == null || var20.length() < var26.length()) {
                                 var26 = var20;
                              }
                           } else if ((var3.isEmpty() || StringUtils.startsWithIgnoringCase(var19, var2)) && var3.length() < var19.length()) {
                              var1.add(var18.getName(), var18.getName().substring(var3.length()), 0);
                           }
                        }
                     }
                  }
               }
            }

            if (var26 != null) {
               var3 = var26;
            }
            break;
         case 1:
            DbSchema var22 = var1.getLastMatchedSchema();
            if (var22 == null) {
               var22 = this.contents.getDefaultSchema();
            }

            DbTableOrView[] var25 = var22.getTables();
            String var28 = null;
            DbTableOrView var31 = null;

            for(DbTableOrView var43 : var25) {
               String var46 = var43.getName();
               String var13 = StringUtils.quoteIdentifier(var46);
               if (!StringUtils.startsWithIgnoringCase(var2, var46) && !StringUtils.startsWithIgnoringCase("\"" + var2, var13)) {
                  if ((var3.isEmpty() || StringUtils.startsWithIgnoringCase(var46, var2) || StringUtils.startsWithIgnoringCase(var13, var2)) && var3.length() < var46.length()) {
                     var1.add(var43.getQuotedName(), var43.getQuotedName().substring(var3.length()), 0);
                  }
               } else if (var28 == null || var46.length() > var28.length()) {
                  var28 = var46;
                  var31 = var43;
               }
            }

            if (var28 != null) {
               var1.setLastMatchedTable(var31);
               var1.addTable(var31);
               var3 = var3.substring(var28.length());
            }
            break;
         case 2:
            var3 = autoCompleteTableAlias(var1, false);
            break;
         case 3:
            var3 = autoCompleteTableAlias(var1, true);
            break;
         case 4:
            int var21 = 0;
            if (var2.indexOf(32) >= 0) {
               int var24 = var2.length();
               int var27;
               if (Character.isJavaIdentifierStart(var27 = var2.codePointAt(var21)) && var27 != 36) {
                  while((var21 += Character.charCount(var27)) < var24 && Character.isJavaIdentifierPart(var27 = var2.codePointAt(var21))) {
                  }

                  String var30 = var2.substring(0, var21);
                  if (!ParserUtil.isKeyword(var30, false)) {
                     var3 = var2.substring(var30.length());
                  }
               }
            }
            break;
         case 5:
            DbSchema[] var4 = this.contents.getSchemas();
            String var5 = null;
            DbSchema var6 = null;

            for(DbSchema var10 : var4) {
               String var11 = var10.name;
               String var12 = StringUtils.quoteIdentifier(var11);
               if (StringUtils.startsWithIgnoringCase(var2, var11)) {
                  if (var5 == null || var11.length() > var5.length()) {
                     var5 = var11;
                     var6 = var10;
                  }
               } else if (StringUtils.startsWith(var2, var12)) {
                  if (var5 == null || var11.length() > var5.length()) {
                     var5 = var12;
                     var6 = var10;
                  }
               } else if ((var3.isEmpty() || StringUtils.startsWithIgnoringCase(var11, var2) || StringUtils.startsWithIgnoringCase(var12, var2)) && var3.length() < var11.length()) {
                  var1.add(var11, var11.substring(var3.length()), this.type);
                  String var10001 = var10.quotedName + ".";
                  String var10002 = var10.quotedName;
                  var1.add(var10001, var10002.substring(var3.length()) + ".", 0);
               }
            }

            if (var5 != null) {
               var1.setLastMatchedSchema(var6);
               var3 = var3.substring(var5.length());
            }
            break;
         case 6:
            this.autoCompleteProcedure(var1);
            break;
         default:
            throw DbException.getInternalError("type=" + this.type);
      }

      if (var3.equals(var2)) {
         return false;
      } else {
         while(Bnf.startWithSpace(var3)) {
            var3 = var3.substring(1);
         }

         var1.setQuery(var3);
         return true;
      }
   }

   private boolean testColumnType(DbColumn var1) {
      if (this.columnType == null) {
         return true;
      } else {
         String var2 = var1.getDataType();
         if (!this.columnType.contains("CHAR") && !this.columnType.contains("CLOB")) {
            if (!this.columnType.contains("BINARY") && !this.columnType.contains("BLOB")) {
               return var2.contains(this.columnType);
            } else {
               return var2.contains("BINARY") || var2.contains("BLOB");
            }
         } else {
            return var2.contains("CHAR") || var2.contains("CLOB");
         }
      }
   }

   private void autoCompleteProcedure(Sentence var1) {
      DbSchema var2 = var1.getLastMatchedSchema();
      if (var2 == null) {
         var2 = this.contents.getDefaultSchema();
      }

      String var3 = var1.getQueryUpper();
      String var4 = var3;
      int var5 = var3.indexOf(40);
      if (var5 != -1) {
         var4 = StringUtils.trimSubstring(var3, 0, var5);
      }

      RuleElement var6 = new RuleElement("(", "Function");
      RuleElement var7 = new RuleElement(")", "Function");
      RuleElement var8 = new RuleElement(",", "Function");

      for(DbProcedure var12 : var2.getProcedures()) {
         String var13 = var12.getName();
         if (var13.startsWith(var4)) {
            RuleElement var14 = new RuleElement(var13, "Function");
            RuleList var15 = new RuleList(var14, var6, false);
            if (var3.contains("(")) {
               for(DbColumn var19 : var12.getParameters()) {
                  if (var19.getPosition() > 1) {
                     var15 = new RuleList(var15, var8, false);
                  }

                  DbContextRule var20 = new DbContextRule(this.contents, 0);
                  String var21 = var19.getDataType();
                  if (var21.contains("(")) {
                     var21 = var21.substring(0, var21.indexOf(40));
                  }

                  var20.setColumnType(var21);
                  var15 = new RuleList(var15, var20, false);
               }

               var15 = new RuleList(var15, var7, false);
            }

            var15.autoComplete(var1);
         }
      }

   }

   private static String autoCompleteTableAlias(Sentence var0, boolean var1) {
      String var2 = var0.getQuery();
      String var3 = var0.getQueryUpper();

      int var4;
      for(var4 = 0; var4 < var3.length(); ++var4) {
         char var5 = var3.charAt(var4);
         if (var5 != '_' && !Character.isLetterOrDigit(var5)) {
            break;
         }
      }

      if (var4 == 0) {
         return var2;
      } else {
         String var14 = var3.substring(0, var4);
         if (!"SET".equals(var14) && !ParserUtil.isKeyword(var14, false)) {
            if (var1) {
               var0.addAlias(var14, var0.getLastTable());
            }

            HashMap var6 = var0.getAliases();
            if ((var6 == null || !var6.containsKey(var14)) && var0.getLastTable() != null) {
               HashSet var7 = var0.getTables();
               if (var7 != null) {
                  String var8 = null;

                  for(DbTableOrView var10 : var7) {
                     String var11 = StringUtils.toUpperEnglish(var10.getName());
                     if (!var14.startsWith(var11) || var8 != null && var11.length() <= var8.length()) {
                        if (var2.isEmpty() || var11.startsWith(var14)) {
                           var0.add(var11 + ".", var11.substring(var2.length()) + ".", 0);
                        }
                     } else {
                        var0.setLastMatchedTable(var10);
                        var8 = var11;
                     }
                  }

                  if (var8 != null) {
                     var2 = var2.substring(var8.length());
                     if (var2.isEmpty()) {
                        var0.add(var14 + ".", ".", 0);
                     }

                     return var2;
                  }
               }

               return var2;
            } else if (var1 && var2.length() == var14.length()) {
               return var2;
            } else {
               var2 = var2.substring(var14.length());
               if (var2.isEmpty()) {
                  var0.add(var14 + ".", ".", 0);
               }

               return var2;
            }
         } else {
            return var2;
         }
      }
   }
}
