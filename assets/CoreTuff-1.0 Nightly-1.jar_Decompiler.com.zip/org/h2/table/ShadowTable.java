package org.h2.table;

import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.result.ResultInterface;
import org.h2.schema.Schema;

public class ShadowTable extends VirtualConstructedTable {
   public ShadowTable(Schema var1, String var2, Column[] var3) {
      super(var1, 0, var2);
      this.setColumns(var3);
   }

   public ResultInterface getResult(SessionLocal var1) {
      throw DbException.getInternalError("shadow table");
   }

   public boolean isDeterministic() {
      return false;
   }

   public boolean canGetRowCount(SessionLocal var1) {
      return false;
   }

   public long getRowCount(SessionLocal var1) {
      return Long.MAX_VALUE;
   }

   public long getRowCountApproximation(SessionLocal var1) {
      return Long.MAX_VALUE;
   }
}
