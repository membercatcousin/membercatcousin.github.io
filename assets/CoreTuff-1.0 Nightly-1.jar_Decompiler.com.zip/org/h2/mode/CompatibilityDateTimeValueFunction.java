package org.h2.mode;

import org.h2.engine.SessionLocal;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.Operation0;
import org.h2.expression.function.NamedExpression;
import org.h2.util.DateTimeUtils;
import org.h2.util.TimeZoneProvider;
import org.h2.value.ExtTypeInfo;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueTimestamp;
import org.h2.value.ValueTimestampTimeZone;

final class CompatibilityDateTimeValueFunction extends Operation0 implements NamedExpression {
   static final int SYSDATE = 0;
   static final int SYSTIMESTAMP = 1;
   private static final String[] NAMES = new String[]{"SYSDATE", "SYSTIMESTAMP"};
   private final int function;
   private final int scale;
   private final TypeInfo type;

   CompatibilityDateTimeValueFunction(int var1, int var2) {
      this.function = var1;
      this.scale = var2;
      if (var1 == 0) {
         this.type = TypeInfo.getTypeInfo(20, 0L, 0, (ExtTypeInfo)null);
      } else {
         this.type = TypeInfo.getTypeInfo(21, 0L, var2, (ExtTypeInfo)null);
      }

   }

   public Value getValue(SessionLocal var1) {
      ValueTimestampTimeZone var2 = var1.currentTimestamp();
      long var3 = var2.getDateValue();
      long var5 = var2.getTimeNanos();
      int var7 = var2.getTimeZoneOffsetSeconds();
      int var8 = TimeZoneProvider.getDefault().getTimeZoneOffsetUTC(DateTimeUtils.getEpochSeconds(var3, var5, var7));
      if (var7 != var8) {
         var2 = DateTimeUtils.timestampTimeZoneAtOffset(var3, var5, var7, var8);
      }

      return (Value)(this.function == 0 ? ValueTimestamp.fromDateValueAndNanos(var2.getDateValue(), var2.getTimeNanos() / 1000000000L * 1000000000L) : var2.castTo(this.type, var1));
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      var1.append(this.getName());
      if (this.scale >= 0) {
         var1.append('(').append(this.scale).append(')');
      }

      return var1;
   }

   public boolean isEverything(ExpressionVisitor var1) {
      switch (var1.getType()) {
         case 2:
            return false;
         default:
            return true;
      }
   }

   public TypeInfo getType() {
      return this.type;
   }

   public int getCost() {
      return 1;
   }

   public String getName() {
      return NAMES[this.function];
   }
}
