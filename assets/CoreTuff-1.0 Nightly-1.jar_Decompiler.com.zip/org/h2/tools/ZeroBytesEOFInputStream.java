package org.h2.tools;

import java.io.IOException;
import java.io.InputStream;

public class ZeroBytesEOFInputStream extends InputStream {
   private final InputStream wrapped;
   private int consecutiveZeroReads = 0;
   private static final int MAX_ZERO_READS = 10;
   private boolean eofReached = false;

   public ZeroBytesEOFInputStream(InputStream var1) {
      this.wrapped = var1;
   }

   public int read() throws IOException {
      if (this.eofReached) {
         return -1;
      } else {
         while(this.consecutiveZeroReads < 10) {
            int var1 = this.wrapped.read();
            if (var1 == -1) {
               this.eofReached = true;
               return -1;
            }

            if (var1 >= 0) {
               this.consecutiveZeroReads = 0;
               return var1;
            }

            ++this.consecutiveZeroReads;
         }

         this.eofReached = true;
         return -1;
      }
   }

   public int read(byte[] var1) throws IOException {
      return this.read(var1, 0, var1.length);
   }

   public int read(byte[] var1, int var2, int var3) throws IOException {
      if (this.eofReached) {
         return -1;
      } else {
         while(this.consecutiveZeroReads < 10) {
            int var4 = this.wrapped.read(var1, var2, var3);
            if (var4 == -1) {
               this.eofReached = true;
               return -1;
            }

            if (var4 > 0) {
               this.consecutiveZeroReads = 0;
               return var4;
            }

            ++this.consecutiveZeroReads;

            try {
               Thread.sleep(10L);
            } catch (InterruptedException var6) {
               Thread.currentThread().interrupt();
               throw new IOException("Interrupted while reading compressed stream", var6);
            }
         }

         this.eofReached = true;
         return -1;
      }
   }

   public long skip(long var1) throws IOException {
      return this.wrapped.skip(var1);
   }

   public int available() throws IOException {
      return this.wrapped.available();
   }

   public void close() throws IOException {
      this.wrapped.close();
   }

   public synchronized void mark(int var1) {
      this.wrapped.mark(var1);
   }

   public synchronized void reset() throws IOException {
      this.wrapped.reset();
      this.consecutiveZeroReads = 0;
      this.eofReached = false;
   }

   public boolean markSupported() {
      return this.wrapped.markSupported();
   }
}
