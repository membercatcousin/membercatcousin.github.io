package org.h2.tools;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import org.h2.message.DbException;
import org.h2.mvstore.MVStore;
import org.h2.store.FileLister;
import org.h2.store.fs.FilePath;
import org.h2.store.fs.FileUtils;
import org.h2.store.fs.encrypt.FileEncrypt;
import org.h2.store.fs.encrypt.FilePathEncrypt;
import org.h2.util.Tool;

public class ChangeFileEncryption extends Tool {
   private String directory;
   private String cipherType;
   private byte[] decryptKey;
   private byte[] encryptKey;

   public static void main(String... var0) {
      try {
         (new ChangeFileEncryption()).runTool(var0);
      } catch (SQLException var2) {
         var2.printStackTrace(System.err);
         System.exit(1);
      }

   }

   public void runTool(String... var1) throws SQLException {
      String var2 = ".";
      String var3 = null;
      char[] var4 = null;
      char[] var5 = null;
      String var6 = null;
      boolean var7 = false;

      for(int var8 = 0; var1 != null && var8 < var1.length; ++var8) {
         String var9 = var1[var8];
         if (var9.equals("-dir")) {
            ++var8;
            var2 = var1[var8];
         } else if (var9.equals("-cipher")) {
            ++var8;
            var3 = var1[var8];
         } else if (var9.equals("-db")) {
            ++var8;
            var6 = var1[var8];
         } else if (var9.equals("-decrypt")) {
            ++var8;
            var4 = var1[var8].toCharArray();
         } else if (var9.equals("-encrypt")) {
            ++var8;
            var5 = var1[var8].toCharArray();
         } else if (var9.equals("-quiet")) {
            var7 = true;
         } else {
            if (var9.equals("-help") || var9.equals("-?")) {
               this.showUsage();
               return;
            }

            this.showUsageAndThrowUnsupportedOption(var9);
         }
      }

      if ((var5 != null || var4 != null) && var3 != null) {
         try {
            this.process(var2, var6, var3, var4, var5, var7);
         } catch (Exception var10) {
            throw DbException.toSQLException(var10);
         }
      } else {
         this.showUsage();
         throw new SQLException("Encryption or decryption password not set, or cipher not set");
      }
   }

   public static void execute(String var0, String var1, String var2, char[] var3, char[] var4, boolean var5) throws SQLException {
      try {
         (new ChangeFileEncryption()).process(var0, var1, var2, var3, var4, var5);
      } catch (Exception var7) {
         throw DbException.toSQLException(var7);
      }
   }

   private void process(String var1, String var2, String var3, char[] var4, char[] var5, boolean var6) throws SQLException {
      var1 = FileLister.getDir(var1);
      ChangeFileEncryption var7 = new ChangeFileEncryption();
      if (var5 != null) {
         for(char var11 : var5) {
            if (var11 == ' ') {
               throw new SQLException("The file password may not contain spaces");
            }
         }

         var7.encryptKey = FilePathEncrypt.getPasswordBytes(var5);
      }

      if (var4 != null) {
         var7.decryptKey = FilePathEncrypt.getPasswordBytes(var4);
      }

      var7.out = this.out;
      var7.directory = var1;
      var7.cipherType = var3;
      ArrayList var13 = FileLister.getDatabaseFiles(var1, var2, true);
      FileLister.tryUnlockDatabase(var13, "encryption");
      var13 = FileLister.getDatabaseFiles(var1, var2, false);
      if (var13.isEmpty() && !var6) {
         this.printNoDatabaseFilesFound(var1, var2);
      }

      for(String var17 : var13) {
         String var19 = var1 + "/temp.db";
         FileUtils.delete(var19);
         FileUtils.move(var17, var19);
         FileUtils.move(var19, var17);
      }

      for(String var18 : var13) {
         if (!FileUtils.isDirectory(var18)) {
            var7.process(var18, var6, var4);
         }
      }

   }

   private void process(String var1, boolean var2, char[] var3) throws SQLException {
      if (var1.endsWith(".mv.db")) {
         try {
            this.copyMvStore(var1, var2, var3);
         } catch (IOException var5) {
            throw DbException.convertIOException(var5, "Error encrypting / decrypting file " + var1);
         }
      }
   }

   private void copyMvStore(String var1, boolean var2, char[] var3) throws IOException, SQLException {
      if (!FileUtils.isDirectory(var1)) {
         try {
            MVStore var4 = (new MVStore.Builder()).fileName(var1).readOnly().encryptionKey(var3).open();
            var4.close();
         } catch (IllegalStateException var19) {
            throw new SQLException("error decrypting file " + var1, var19);
         }

         String var23 = this.directory + "/temp.db";
         FileChannel var5 = getFileChannel(var1, "r", this.decryptKey);

         try {
            InputStream var6 = Channels.newInputStream(var5);

            try {
               FileUtils.delete(var23);
               OutputStream var7 = Channels.newOutputStream(getFileChannel(var23, "rw", this.encryptKey));

               try {
                  byte[] var8 = new byte[4096];
                  long var9 = var5.size();
                  long var11 = var9;

                  int var24;
                  for(long var13 = System.nanoTime(); var9 > 0L; var9 -= (long)var24) {
                     if (!var2 && System.nanoTime() - var13 > TimeUnit.SECONDS.toNanos(1L)) {
                        this.out.println(var1 + ": " + (100L - 100L * var9 / var11) + "%");
                        var13 = System.nanoTime();
                     }

                     int var15 = (int)Math.min((long)var8.length, var9);
                     var24 = var6.read(var8, 0, var15);
                     var7.write(var8, 0, var24);
                  }
               } catch (Throwable var20) {
                  if (var7 != null) {
                     try {
                        var7.close();
                     } catch (Throwable var18) {
                        var20.addSuppressed(var18);
                     }
                  }

                  throw var20;
               }

               if (var7 != null) {
                  var7.close();
               }
            } catch (Throwable var21) {
               if (var6 != null) {
                  try {
                     var6.close();
                  } catch (Throwable var17) {
                     var21.addSuppressed(var17);
                  }
               }

               throw var21;
            }

            if (var6 != null) {
               var6.close();
            }
         } catch (Throwable var22) {
            if (var5 != null) {
               try {
                  var5.close();
               } catch (Throwable var16) {
                  var22.addSuppressed(var16);
               }
            }

            throw var22;
         }

         if (var5 != null) {
            var5.close();
         }

         FileUtils.delete(var1);
         FileUtils.move(var23, var1);
      }
   }

   private static FileChannel getFileChannel(String var0, String var1, byte[] var2) throws IOException {
      Object var3 = FilePath.get(var0).open(var1);
      if (var2 != null) {
         var3 = new FileEncrypt(var0, var2, (FileChannel)var3);
      }

      return (FileChannel)var3;
   }
}
