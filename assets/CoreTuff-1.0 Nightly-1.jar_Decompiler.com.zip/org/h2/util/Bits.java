package org.h2.util;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.nio.ByteOrder;
import java.util.UUID;

public final class Bits {
   public static final VarHandle INT_VH_BE;
   public static final VarHandle INT_VH_LE;
   public static final VarHandle LONG_VH_BE;
   public static final VarHandle LONG_VH_LE;
   public static final VarHandle DOUBLE_VH_BE;
   public static final VarHandle DOUBLE_VH_LE;

   public static byte[] uuidToBytes(long var0, long var2) {
      byte[] var4 = new byte[16];
      LONG_VH_BE.set(var4, 0, var0);
      LONG_VH_BE.set(var4, 8, var2);
      return var4;
   }

   public static byte[] uuidToBytes(UUID var0) {
      return uuidToBytes(var0.getMostSignificantBits(), var0.getLeastSignificantBits());
   }

   private Bits() {
   }

   static {
      INT_VH_BE = MethodHandles.byteArrayViewVarHandle(int[].class, ByteOrder.BIG_ENDIAN);
      INT_VH_LE = MethodHandles.byteArrayViewVarHandle(int[].class, ByteOrder.LITTLE_ENDIAN);
      LONG_VH_BE = MethodHandles.byteArrayViewVarHandle(long[].class, ByteOrder.BIG_ENDIAN);
      LONG_VH_LE = MethodHandles.byteArrayViewVarHandle(long[].class, ByteOrder.LITTLE_ENDIAN);
      DOUBLE_VH_BE = MethodHandles.byteArrayViewVarHandle(double[].class, ByteOrder.BIG_ENDIAN);
      DOUBLE_VH_LE = MethodHandles.byteArrayViewVarHandle(double[].class, ByteOrder.LITTLE_ENDIAN);
   }
}
