package org.h2.expression;

import java.util.Map;
import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.mvstore.db.Store;
import org.h2.util.ParserUtil;
import org.h2.util.json.JSONObject;
import org.h2.util.json.JSONValue;
import org.h2.value.ExtTypeInfoRow;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueJson;
import org.h2.value.ValueNull;
import org.h2.value.ValueRow;

public final class FieldReference extends Operation1 {
   private final String fieldName;
   private int ordinal;

   public FieldReference(Expression var1, String var2) {
      super(var1);
      this.fieldName = var2;
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      return ParserUtil.quoteIdentifier(this.arg.getEnclosedSQL(var1, var2).append('.'), this.fieldName, var2);
   }

   public Value getValue(SessionLocal var1) {
      Value var2 = this.arg.getValue(var1);
      if (var2 != ValueNull.INSTANCE) {
         if (this.ordinal >= 0) {
            return ((ValueRow)var2).getList()[this.ordinal];
         }

         JSONValue var3 = var2.convertToAnyJson().getDecomposition();
         if (var3 instanceof JSONObject) {
            JSONValue var4 = ((JSONObject)var3).getFirst(this.fieldName);
            if (var4 != null) {
               return ValueJson.fromJson(var4);
            }
         }
      }

      return ValueNull.INSTANCE;
   }

   public Expression optimize(SessionLocal var1) {
      this.arg = this.arg.optimize(var1);
      TypeInfo var2 = this.arg.getType();
      int var3 = var2.getValueType();
      switch (var3) {
         case 38:
            this.type = TypeInfo.TYPE_JSON;
            this.ordinal = -1;
            return (Expression)(this.arg.isConstant() ? TypedValueExpression.get(this.getValue(var1), var2) : this);
         case 41:
            int var4 = 0;

            for(Map.Entry var6 : ((ExtTypeInfoRow)var2.getExtTypeInfo()).getFields()) {
               if (this.fieldName.equals(var6.getKey())) {
                  var2 = (TypeInfo)var6.getValue();
                  this.type = var2;
                  this.ordinal = var4;
                  return (Expression)(this.arg.isConstant() ? TypedValueExpression.get(this.getValue(var1), var2) : this);
               }

               ++var4;
            }

            throw DbException.get(42122, (String)this.fieldName);
         default:
            throw Store.getInvalidExpressionTypeException("JSON | ROW", this.arg);
      }
   }
}
