package org.h2.constraint;

public enum ConstraintActionType {
   NO_ACTION("NO ACTION"),
   RESTRICT,
   CASCADE,
   SET_DEFAULT("SET DEFAULT"),
   SET_NULL("SET NULL");

   private final String sqlName;

   private ConstraintActionType() {
      this.sqlName = this.name();
   }

   private ConstraintActionType(String var3) {
      this.sqlName = var3;
   }

   public String getSqlName() {
      return this.sqlName;
   }

   public boolean isNoActionOrRestrict() {
      return this == NO_ACTION || this == RESTRICT;
   }
}
