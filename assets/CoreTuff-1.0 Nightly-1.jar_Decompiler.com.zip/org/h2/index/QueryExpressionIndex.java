package org.h2.index;

import java.util.ArrayList;
import org.h2.command.query.Query;
import org.h2.engine.SessionLocal;
import org.h2.expression.Parameter;
import org.h2.message.DbException;
import org.h2.result.Row;
import org.h2.table.Column;
import org.h2.table.IndexColumn;
import org.h2.table.QueryExpressionTable;

public abstract class QueryExpressionIndex extends Index {
   final QueryExpressionTable table;
   final String querySQL;
   final ArrayList<Parameter> originalParameters;
   Query query;

   QueryExpressionIndex(QueryExpressionTable var1, String var2, ArrayList<Parameter> var3) {
      super(var1, 0, (String)null, (IndexColumn[])null, 0, IndexType.createNonUnique(false));
      this.table = var1;
      this.querySQL = var2;
      this.originalParameters = var3;
      this.columns = new Column[0];
   }

   public abstract boolean isExpired();

   public String getPlanSQL() {
      return this.query == null ? null : this.query.getPlanSQL(11);
   }

   public Query getQuery() {
      return this.query;
   }

   public void close(SessionLocal var1) {
   }

   public void add(SessionLocal var1, Row var2) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".add");
   }

   public void remove(SessionLocal var1, Row var2) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".remove");
   }

   public void remove(SessionLocal var1) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".remove");
   }

   public void truncate(SessionLocal var1) {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".truncate");
   }

   public void checkRename() {
      throw DbException.getUnsupportedException(this.getClass().getSimpleName() + ".checkRename");
   }

   public boolean needRebuild() {
      return false;
   }

   public long getRowCount(SessionLocal var1) {
      return 0L;
   }

   public long getRowCountApproximation(SessionLocal var1) {
      return 0L;
   }
}
