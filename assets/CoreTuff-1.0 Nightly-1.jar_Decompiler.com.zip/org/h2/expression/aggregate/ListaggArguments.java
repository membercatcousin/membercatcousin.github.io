package org.h2.expression.aggregate;

import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;

public final class ListaggArguments {
   private Expression separator;
   private boolean onOverflowTruncate;
   private Expression filter;
   private boolean withoutCount;

   public void setSeparator(Expression var1) {
      this.separator = var1;
   }

   public Expression getSeparator() {
      return this.separator;
   }

   public String getEffectiveSeparator() {
      if (this.separator != null) {
         String var1 = this.separator.getValue((SessionLocal)null).getString();
         return var1 != null ? var1 : "";
      } else {
         return ",";
      }
   }

   public void setOnOverflowTruncate(boolean var1) {
      this.onOverflowTruncate = var1;
   }

   public boolean getOnOverflowTruncate() {
      return this.onOverflowTruncate;
   }

   public void setFilter(Expression var1) {
      this.filter = var1;
   }

   public Expression getFilter() {
      return this.filter;
   }

   public String getEffectiveFilter() {
      if (this.filter != null) {
         String var1 = this.filter.getValue((SessionLocal)null).getString();
         return var1 != null ? var1 : "";
      } else {
         return "...";
      }
   }

   public void setWithoutCount(boolean var1) {
      this.withoutCount = var1;
   }

   public boolean isWithoutCount() {
      return this.withoutCount;
   }
}
