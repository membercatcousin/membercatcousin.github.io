package org.h2.table;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Locale;
import org.h2.command.Command;
import org.h2.command.ParserBase;
import org.h2.command.dml.Help;
import org.h2.constraint.Constraint;
import org.h2.constraint.ConstraintActionType;
import org.h2.constraint.ConstraintDomain;
import org.h2.constraint.ConstraintReferential;
import org.h2.constraint.ConstraintUnique;
import org.h2.engine.Constants;
import org.h2.engine.DbObject;
import org.h2.engine.QueryStatisticsData;
import org.h2.engine.Right;
import org.h2.engine.RightOwner;
import org.h2.engine.Role;
import org.h2.engine.SessionLocal;
import org.h2.engine.Setting;
import org.h2.engine.User;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.ValueExpression;
import org.h2.index.Index;
import org.h2.index.MetaIndex;
import org.h2.message.DbException;
import org.h2.result.Row;
import org.h2.result.SearchRow;
import org.h2.schema.Constant;
import org.h2.schema.Domain;
import org.h2.schema.FunctionAlias;
import org.h2.schema.Schema;
import org.h2.schema.SchemaObject;
import org.h2.schema.Sequence;
import org.h2.schema.TriggerObject;
import org.h2.schema.UserDefinedFunction;
import org.h2.store.InDoubtTransaction;
import org.h2.tools.Csv;
import org.h2.util.DateTimeUtils;
import org.h2.util.MathUtils;
import org.h2.util.NetworkConnectionInfo;
import org.h2.util.StringUtils;
import org.h2.util.TimeZoneProvider;
import org.h2.util.Utils;
import org.h2.value.CompareMode;
import org.h2.value.DataType;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueBigint;
import org.h2.value.ValueBoolean;
import org.h2.value.ValueDouble;
import org.h2.value.ValueInteger;
import org.h2.value.ValueSmallint;
import org.h2.value.ValueToObjectConverter2;

public final class InformationSchemaTableLegacy extends MetaTable {
   private static final String CHARACTER_SET_NAME = "Unicode";
   private static final int TABLES = 0;
   private static final int COLUMNS = 1;
   private static final int INDEXES = 2;
   private static final int TABLE_TYPES = 3;
   private static final int TYPE_INFO = 4;
   private static final int CATALOGS = 5;
   private static final int SETTINGS = 6;
   private static final int HELP = 7;
   private static final int SEQUENCES = 8;
   private static final int USERS = 9;
   private static final int ROLES = 10;
   private static final int RIGHTS = 11;
   private static final int FUNCTION_ALIASES = 12;
   private static final int SCHEMATA = 13;
   private static final int TABLE_PRIVILEGES = 14;
   private static final int COLUMN_PRIVILEGES = 15;
   private static final int COLLATIONS = 16;
   private static final int VIEWS = 17;
   private static final int IN_DOUBT = 18;
   private static final int CROSS_REFERENCES = 19;
   private static final int FUNCTION_COLUMNS = 20;
   private static final int CONSTRAINTS = 21;
   private static final int CONSTANTS = 22;
   private static final int DOMAINS = 23;
   private static final int TRIGGERS = 24;
   private static final int SESSIONS = 25;
   private static final int LOCKS = 26;
   private static final int SESSION_STATE = 27;
   private static final int QUERY_STATISTICS = 28;
   private static final int SYNONYMS = 29;
   private static final int TABLE_CONSTRAINTS = 30;
   private static final int DOMAIN_CONSTRAINTS = 31;
   private static final int KEY_COLUMN_USAGE = 32;
   private static final int REFERENTIAL_CONSTRAINTS = 33;
   private static final int CHECK_CONSTRAINTS = 34;
   private static final int CONSTRAINT_COLUMN_USAGE = 35;
   public static final int META_TABLE_TYPE_COUNT = 36;

   public InformationSchemaTableLegacy(Schema var1, int var2, int var3) {
      super(var1, var2, var3);
      String var5 = null;
      Column[] var4;
      switch (var3) {
         case 0:
            this.setMetaTableName("TABLES");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("TABLE_TYPE"), this.column("STORAGE_TYPE"), this.column("SQL"), this.column("REMARKS"), this.column("LAST_MODIFICATION", TypeInfo.TYPE_BIGINT), this.column("ID", TypeInfo.TYPE_INTEGER), this.column("TYPE_NAME"), this.column("TABLE_CLASS"), this.column("ROW_COUNT_ESTIMATE", TypeInfo.TYPE_BIGINT)};
            var5 = "TABLE_NAME";
            break;
         case 1:
            this.setMetaTableName("COLUMNS");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_INTEGER), this.column("COLUMN_DEFAULT"), this.column("IS_NULLABLE"), this.column("DATA_TYPE", TypeInfo.TYPE_INTEGER), this.column("CHARACTER_MAXIMUM_LENGTH", TypeInfo.TYPE_INTEGER), this.column("CHARACTER_OCTET_LENGTH", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("DATETIME_PRECISION", TypeInfo.TYPE_INTEGER), this.column("INTERVAL_TYPE"), this.column("INTERVAL_PRECISION", TypeInfo.TYPE_INTEGER), this.column("CHARACTER_SET_NAME"), this.column("COLLATION_NAME"), this.column("DOMAIN_CATALOG"), this.column("DOMAIN_SCHEMA"), this.column("DOMAIN_NAME"), this.column("IS_GENERATED"), this.column("GENERATION_EXPRESSION"), this.column("TYPE_NAME"), this.column("NULLABLE", TypeInfo.TYPE_INTEGER), this.column("IS_COMPUTED", TypeInfo.TYPE_BOOLEAN), this.column("SELECTIVITY", TypeInfo.TYPE_INTEGER), this.column("SEQUENCE_NAME"), this.column("REMARKS"), this.column("SOURCE_DATA_TYPE", TypeInfo.TYPE_SMALLINT), this.column("COLUMN_TYPE"), this.column("COLUMN_ON_UPDATE"), this.column("IS_VISIBLE"), this.column("CHECK_CONSTRAINT")};
            var5 = "TABLE_NAME";
            break;
         case 2:
            this.setMetaTableName("INDEXES");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("NON_UNIQUE", TypeInfo.TYPE_BOOLEAN), this.column("INDEX_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_SMALLINT), this.column("COLUMN_NAME"), this.column("CARDINALITY", TypeInfo.TYPE_INTEGER), this.column("PRIMARY_KEY", TypeInfo.TYPE_BOOLEAN), this.column("INDEX_TYPE_NAME"), this.column("IS_GENERATED", TypeInfo.TYPE_BOOLEAN), this.column("INDEX_TYPE", TypeInfo.TYPE_SMALLINT), this.column("ASC_OR_DESC"), this.column("PAGES", TypeInfo.TYPE_INTEGER), this.column("FILTER_CONDITION"), this.column("REMARKS"), this.column("SQL"), this.column("ID", TypeInfo.TYPE_INTEGER), this.column("SORT_TYPE", TypeInfo.TYPE_INTEGER), this.column("CONSTRAINT_NAME"), this.column("INDEX_CLASS")};
            var5 = "TABLE_NAME";
            break;
         case 3:
            this.setMetaTableName("TABLE_TYPES");
            var4 = new Column[]{this.column("TYPE")};
            break;
         case 4:
            this.setMetaTableName("TYPE_INFO");
            var4 = new Column[]{this.column("TYPE_NAME"), this.column("DATA_TYPE", TypeInfo.TYPE_INTEGER), this.column("PRECISION", TypeInfo.TYPE_INTEGER), this.column("PREFIX"), this.column("SUFFIX"), this.column("PARAMS"), this.column("AUTO_INCREMENT", TypeInfo.TYPE_BOOLEAN), this.column("MINIMUM_SCALE", TypeInfo.TYPE_SMALLINT), this.column("MAXIMUM_SCALE", TypeInfo.TYPE_SMALLINT), this.column("RADIX", TypeInfo.TYPE_INTEGER), this.column("POS", TypeInfo.TYPE_INTEGER), this.column("CASE_SENSITIVE", TypeInfo.TYPE_BOOLEAN), this.column("NULLABLE", TypeInfo.TYPE_SMALLINT), this.column("SEARCHABLE", TypeInfo.TYPE_SMALLINT)};
            break;
         case 5:
            this.setMetaTableName("CATALOGS");
            var4 = new Column[]{this.column("CATALOG_NAME")};
            break;
         case 6:
            this.setMetaTableName("SETTINGS");
            var4 = new Column[]{this.column("NAME"), this.column("VALUE")};
            break;
         case 7:
            this.setMetaTableName("HELP");
            var4 = new Column[]{this.column("ID", TypeInfo.TYPE_INTEGER), this.column("SECTION"), this.column("TOPIC"), this.column("SYNTAX"), this.column("TEXT")};
            break;
         case 8:
            this.setMetaTableName("SEQUENCES");
            var4 = new Column[]{this.column("SEQUENCE_CATALOG"), this.column("SEQUENCE_SCHEMA"), this.column("SEQUENCE_NAME"), this.column("DATA_TYPE"), this.column("NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_PRECISION_RADIX", TypeInfo.TYPE_INTEGER), this.column("NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("START_VALUE", TypeInfo.TYPE_BIGINT), this.column("MINIMUM_VALUE", TypeInfo.TYPE_BIGINT), this.column("MAXIMUM_VALUE", TypeInfo.TYPE_BIGINT), this.column("INCREMENT", TypeInfo.TYPE_BIGINT), this.column("CYCLE_OPTION"), this.column("DECLARED_DATA_TYPE"), this.column("DECLARED_NUMERIC_PRECISION", TypeInfo.TYPE_INTEGER), this.column("DECLARED_NUMERIC_SCALE", TypeInfo.TYPE_INTEGER), this.column("CURRENT_VALUE", TypeInfo.TYPE_BIGINT), this.column("IS_GENERATED", TypeInfo.TYPE_BOOLEAN), this.column("REMARKS"), this.column("CACHE", TypeInfo.TYPE_BIGINT), this.column("ID", TypeInfo.TYPE_INTEGER), this.column("MIN_VALUE", TypeInfo.TYPE_BIGINT), this.column("MAX_VALUE", TypeInfo.TYPE_BIGINT), this.column("IS_CYCLE", TypeInfo.TYPE_BOOLEAN)};
            break;
         case 9:
            this.setMetaTableName("USERS");
            var4 = new Column[]{this.column("NAME"), this.column("ADMIN"), this.column("REMARKS"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            break;
         case 10:
            this.setMetaTableName("ROLES");
            var4 = new Column[]{this.column("NAME"), this.column("REMARKS"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            break;
         case 11:
            this.setMetaTableName("RIGHTS");
            var4 = new Column[]{this.column("GRANTEE"), this.column("GRANTEETYPE"), this.column("GRANTEDROLE"), this.column("RIGHTS"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            var5 = "TABLE_NAME";
            break;
         case 12:
            this.setMetaTableName("FUNCTION_ALIASES");
            var4 = new Column[]{this.column("ALIAS_CATALOG"), this.column("ALIAS_SCHEMA"), this.column("ALIAS_NAME"), this.column("JAVA_CLASS"), this.column("JAVA_METHOD"), this.column("DATA_TYPE", TypeInfo.TYPE_INTEGER), this.column("TYPE_NAME"), this.column("COLUMN_COUNT", TypeInfo.TYPE_INTEGER), this.column("RETURNS_RESULT", TypeInfo.TYPE_SMALLINT), this.column("REMARKS"), this.column("ID", TypeInfo.TYPE_INTEGER), this.column("SOURCE")};
            break;
         case 13:
            this.setMetaTableName("SCHEMATA");
            var4 = new Column[]{this.column("CATALOG_NAME"), this.column("SCHEMA_NAME"), this.column("SCHEMA_OWNER"), this.column("DEFAULT_CHARACTER_SET_NAME"), this.column("DEFAULT_COLLATION_NAME"), this.column("IS_DEFAULT", TypeInfo.TYPE_BOOLEAN), this.column("REMARKS"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            break;
         case 14:
            this.setMetaTableName("TABLE_PRIVILEGES");
            var4 = new Column[]{this.column("GRANTOR"), this.column("GRANTEE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("PRIVILEGE_TYPE"), this.column("IS_GRANTABLE")};
            var5 = "TABLE_NAME";
            break;
         case 15:
            this.setMetaTableName("COLUMN_PRIVILEGES");
            var4 = new Column[]{this.column("GRANTOR"), this.column("GRANTEE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("PRIVILEGE_TYPE"), this.column("IS_GRANTABLE")};
            var5 = "TABLE_NAME";
            break;
         case 16:
            this.setMetaTableName("COLLATIONS");
            var4 = new Column[]{this.column("NAME"), this.column("KEY")};
            break;
         case 17:
            this.setMetaTableName("VIEWS");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("VIEW_DEFINITION"), this.column("CHECK_OPTION"), this.column("IS_UPDATABLE"), this.column("STATUS"), this.column("REMARKS"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            var5 = "TABLE_NAME";
            break;
         case 18:
            this.setMetaTableName("IN_DOUBT");
            var4 = new Column[]{this.column("TRANSACTION"), this.column("STATE")};
            break;
         case 19:
            this.setMetaTableName("CROSS_REFERENCES");
            var4 = new Column[]{this.column("PKTABLE_CATALOG"), this.column("PKTABLE_SCHEMA"), this.column("PKTABLE_NAME"), this.column("PKCOLUMN_NAME"), this.column("FKTABLE_CATALOG"), this.column("FKTABLE_SCHEMA"), this.column("FKTABLE_NAME"), this.column("FKCOLUMN_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_SMALLINT), this.column("UPDATE_RULE", TypeInfo.TYPE_SMALLINT), this.column("DELETE_RULE", TypeInfo.TYPE_SMALLINT), this.column("FK_NAME"), this.column("PK_NAME"), this.column("DEFERRABILITY", TypeInfo.TYPE_SMALLINT)};
            var5 = "PKTABLE_NAME";
            break;
         case 20:
            this.setMetaTableName("FUNCTION_COLUMNS");
            var4 = new Column[]{this.column("ALIAS_CATALOG"), this.column("ALIAS_SCHEMA"), this.column("ALIAS_NAME"), this.column("JAVA_CLASS"), this.column("JAVA_METHOD"), this.column("COLUMN_COUNT", TypeInfo.TYPE_INTEGER), this.column("POS", TypeInfo.TYPE_INTEGER), this.column("COLUMN_NAME"), this.column("DATA_TYPE", TypeInfo.TYPE_INTEGER), this.column("TYPE_NAME"), this.column("PRECISION", TypeInfo.TYPE_INTEGER), this.column("SCALE", TypeInfo.TYPE_SMALLINT), this.column("RADIX", TypeInfo.TYPE_SMALLINT), this.column("NULLABLE", TypeInfo.TYPE_SMALLINT), this.column("COLUMN_TYPE", TypeInfo.TYPE_SMALLINT), this.column("REMARKS"), this.column("COLUMN_DEFAULT")};
            break;
         case 21:
            this.setMetaTableName("CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("CONSTRAINT_TYPE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("UNIQUE_INDEX_NAME"), this.column("CHECK_EXPRESSION"), this.column("COLUMN_LIST"), this.column("REMARKS"), this.column("SQL"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            var5 = "TABLE_NAME";
            break;
         case 22:
            this.setMetaTableName("CONSTANTS");
            var4 = new Column[]{this.column("CONSTANT_CATALOG"), this.column("CONSTANT_SCHEMA"), this.column("CONSTANT_NAME"), this.column("DATA_TYPE", TypeInfo.TYPE_INTEGER), this.column("REMARKS"), this.column("SQL"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            break;
         case 23:
            this.setMetaTableName("DOMAINS");
            var4 = new Column[]{this.column("DOMAIN_CATALOG"), this.column("DOMAIN_SCHEMA"), this.column("DOMAIN_NAME"), this.column("DOMAIN_DEFAULT"), this.column("DOMAIN_ON_UPDATE"), this.column("DATA_TYPE", TypeInfo.TYPE_INTEGER), this.column("PRECISION", TypeInfo.TYPE_INTEGER), this.column("SCALE", TypeInfo.TYPE_INTEGER), this.column("TYPE_NAME"), this.column("PARENT_DOMAIN_CATALOG"), this.column("PARENT_DOMAIN_SCHEMA"), this.column("PARENT_DOMAIN_NAME"), this.column("SELECTIVITY", TypeInfo.TYPE_INTEGER), this.column("REMARKS"), this.column("SQL"), this.column("ID", TypeInfo.TYPE_INTEGER), this.column("COLUMN_DEFAULT"), this.column("IS_NULLABLE"), this.column("CHECK_CONSTRAINT")};
            break;
         case 24:
            this.setMetaTableName("TRIGGERS");
            var4 = new Column[]{this.column("TRIGGER_CATALOG"), this.column("TRIGGER_SCHEMA"), this.column("TRIGGER_NAME"), this.column("TRIGGER_TYPE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("BEFORE", TypeInfo.TYPE_BOOLEAN), this.column("JAVA_CLASS"), this.column("QUEUE_SIZE", TypeInfo.TYPE_INTEGER), this.column("NO_WAIT", TypeInfo.TYPE_BOOLEAN), this.column("REMARKS"), this.column("SQL"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            break;
         case 25:
            this.setMetaTableName("SESSIONS");
            var4 = new Column[]{this.column("ID", TypeInfo.TYPE_INTEGER), this.column("USER_NAME"), this.column("SERVER"), this.column("CLIENT_ADDR"), this.column("CLIENT_INFO"), this.column("SESSION_START", TypeInfo.TYPE_TIMESTAMP_TZ), this.column("ISOLATION_LEVEL"), this.column("STATEMENT"), this.column("STATEMENT_START", TypeInfo.TYPE_TIMESTAMP_TZ), this.column("CONTAINS_UNCOMMITTED", TypeInfo.TYPE_BOOLEAN), this.column("STATE"), this.column("BLOCKER_ID", TypeInfo.TYPE_INTEGER), this.column("SLEEP_SINCE", TypeInfo.TYPE_TIMESTAMP_TZ)};
            break;
         case 26:
            this.setMetaTableName("LOCKS");
            var4 = new Column[]{this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("SESSION_ID", TypeInfo.TYPE_INTEGER), this.column("LOCK_TYPE")};
            break;
         case 27:
            this.setMetaTableName("SESSION_STATE");
            var4 = new Column[]{this.column("KEY"), this.column("SQL")};
            break;
         case 28:
            this.setMetaTableName("QUERY_STATISTICS");
            var4 = new Column[]{this.column("SQL_STATEMENT"), this.column("EXECUTION_COUNT", TypeInfo.TYPE_INTEGER), this.column("MIN_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("MAX_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("CUMULATIVE_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("AVERAGE_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("STD_DEV_EXECUTION_TIME", TypeInfo.TYPE_DOUBLE), this.column("MIN_ROW_COUNT", TypeInfo.TYPE_BIGINT), this.column("MAX_ROW_COUNT", TypeInfo.TYPE_BIGINT), this.column("CUMULATIVE_ROW_COUNT", TypeInfo.TYPE_BIGINT), this.column("AVERAGE_ROW_COUNT", TypeInfo.TYPE_DOUBLE), this.column("STD_DEV_ROW_COUNT", TypeInfo.TYPE_DOUBLE)};
            break;
         case 29:
            this.setMetaTableName("SYNONYMS");
            var4 = new Column[]{this.column("SYNONYM_CATALOG"), this.column("SYNONYM_SCHEMA"), this.column("SYNONYM_NAME"), this.column("SYNONYM_FOR"), this.column("SYNONYM_FOR_SCHEMA"), this.column("TYPE_NAME"), this.column("STATUS"), this.column("REMARKS"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            var5 = "SYNONYM_NAME";
            break;
         case 30:
            this.setMetaTableName("TABLE_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("CONSTRAINT_TYPE"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("IS_DEFERRABLE"), this.column("INITIALLY_DEFERRED"), this.column("REMARKS"), this.column("SQL"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            var5 = "TABLE_NAME";
            break;
         case 31:
            this.setMetaTableName("DOMAIN_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("DOMAIN_CATALOG"), this.column("DOMAIN_SCHEMA"), this.column("DOMAIN_NAME"), this.column("IS_DEFERRABLE"), this.column("INITIALLY_DEFERRED"), this.column("REMARKS"), this.column("SQL"), this.column("ID", TypeInfo.TYPE_INTEGER)};
            break;
         case 32:
            this.setMetaTableName("KEY_COLUMN_USAGE");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("ORDINAL_POSITION", TypeInfo.TYPE_INTEGER), this.column("POSITION_IN_UNIQUE_CONSTRAINT", TypeInfo.TYPE_INTEGER), this.column("INDEX_CATALOG"), this.column("INDEX_SCHEMA"), this.column("INDEX_NAME")};
            var5 = "TABLE_NAME";
            break;
         case 33:
            this.setMetaTableName("REFERENTIAL_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("UNIQUE_CONSTRAINT_CATALOG"), this.column("UNIQUE_CONSTRAINT_SCHEMA"), this.column("UNIQUE_CONSTRAINT_NAME"), this.column("MATCH_OPTION"), this.column("UPDATE_RULE"), this.column("DELETE_RULE")};
            break;
         case 34:
            this.setMetaTableName("CHECK_CONSTRAINTS");
            var4 = new Column[]{this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME"), this.column("CHECK_CLAUSE")};
            break;
         case 35:
            this.setMetaTableName("CONSTRAINT_COLUMN_USAGE");
            var4 = new Column[]{this.column("TABLE_CATALOG"), this.column("TABLE_SCHEMA"), this.column("TABLE_NAME"), this.column("COLUMN_NAME"), this.column("CONSTRAINT_CATALOG"), this.column("CONSTRAINT_SCHEMA"), this.column("CONSTRAINT_NAME")};
            var5 = "TABLE_NAME";
            break;
         default:
            throw DbException.getInternalError("type=" + var3);
      }

      this.setColumns(var4);
      if (var5 == null) {
         this.indexColumn = -1;
         this.metaIndex = null;
      } else {
         this.indexColumn = this.getColumn(this.database.sysIdentifier(var5)).getColumnId();
         IndexColumn[] var6 = IndexColumn.wrap(new Column[]{var4[this.indexColumn]});
         this.metaIndex = new MetaIndex(this, var6, false);
      }

   }

   private static String replaceNullWithEmpty(String var0) {
      return var0 == null ? "" : var0;
   }

   public ArrayList<Row> generateRows(SessionLocal var1, SearchRow var2, SearchRow var3) {
      Value var4 = this.indexColumn >= 0 && var2 != null ? var2.getValue(this.indexColumn) : null;
      Value var5 = this.indexColumn >= 0 && var3 != null ? var3.getValue(this.indexColumn) : null;
      ArrayList var6 = Utils.newSmallArrayList();
      String var7 = this.database.getShortName();
      boolean var8 = var1.getUser().isAdmin();
      switch (this.type) {
         case 0:
            this.getAllTables(var1, var4, var5).forEach((var5x) -> {
               String var6x;
               if (var5x.isTemporary()) {
                  if (var5x.isGlobalTemporary()) {
                     var6x = "GLOBAL TEMPORARY";
                  } else {
                     var6x = "LOCAL TEMPORARY";
                  }
               } else {
                  var6x = var5x.isPersistIndexes() ? "CACHED" : "MEMORY";
               }

               String var7x = var5x.getCreateSQL();
               if (!var8 && var7x != null && var7x.contains("--hide--")) {
                  var7x = "-";
               }

               this.add(var1, var6, new Object[]{var7, var5x.getSchema().getName(), var5x.getName(), var5x.getTableType().toString(), var6x, var7x, replaceNullWithEmpty(var5x.getComment()), ValueBigint.get(var5x.getMaxDataModificationId()), ValueInteger.get(var5x.getId()), null, var5x.getClass().getName(), ValueBigint.get(var5x.getRowCountApproximation(var1))});
            });
            break;
         case 1:
            this.getAllTables(var1, var4, var5).forEach((var4x) -> {
               Column[] var5 = var4x.getColumns();
               String var6x = this.database.getCompareMode().getName();

               for(int var7x = 0; var7x < var5.length; ++var7x) {
                  Column var8 = var5[var7x];
                  Domain var9 = var8.getDomain();
                  TypeInfo var10 = var8.getType();
                  ValueInteger var11 = ValueInteger.get(MathUtils.convertLongToInt(var10.getPrecision()));
                  ValueInteger var12 = ValueInteger.get(var10.getScale());
                  Sequence var13 = var8.getSequence();
                  int var15 = var10.getValueType();
                  boolean var14;
                  switch (var15) {
                     case 17:
                     case 18:
                     case 19:
                     case 20:
                     case 21:
                     case 27:
                     case 31:
                     case 33:
                     case 34:
                        var14 = true;
                        break;
                     case 22:
                     case 23:
                     case 24:
                     case 25:
                     case 26:
                     case 28:
                     case 29:
                     case 30:
                     case 32:
                     default:
                        var14 = false;
                  }

                  boolean var16 = var8.isGenerated();
                  boolean var17 = DataType.isIntervalType(var15);
                  String var18 = var8.getCreateSQLWithoutName();
                  this.add(var1, var6, new Object[]{var7, var4x.getSchema().getName(), var4x.getName(), var8.getName(), ValueInteger.get(var7x + 1), var16 ? null : var8.getDefaultSQL(), var8.isNullable() ? "YES" : "NO", ValueInteger.get(DataType.convertTypeToSQLType(var10)), var11, var11, var11, ValueInteger.get(10), var12, var14 ? var12 : null, var17 ? var18.substring(9) : null, var17 ? var11 : null, "Unicode", var6x, var9 != null ? var7 : null, var9 != null ? var9.getSchema().getName() : null, var9 != null ? var9.getName() : null, var16 ? "ALWAYS" : "NEVER", var16 ? var8.getDefaultSQL() : null, this.identifier(var17 ? "INTERVAL" : var10.getDeclaredTypeName()), ValueInteger.get(var8.isNullable() ? 1 : 0), ValueBoolean.get(var16), ValueInteger.get(var8.getSelectivity()), var13 == null ? null : var13.getName(), replaceNullWithEmpty(var8.getComment()), null, var18, var8.getOnUpdateSQL(), ValueBoolean.get(var8.getVisible()), null});
               }

            });
            break;
         case 2:
            this.getAllTables(var1, var4, var5).forEach((var4x) -> {
               Iterable var5 = var4x.getConstraints();

               for(Index var7x : var4x.getIndexes()) {
                  if (var7x.getCreateSQL() != null) {
                     String var8 = null;

                     for(Constraint var10 : var5) {
                        if (var10.usesIndex(var7x)) {
                           if (var7x.getIndexType().isPrimaryKey()) {
                              if (var10.getConstraintType() == Constraint.Type.PRIMARY_KEY) {
                                 var8 = var10.getName();
                              }
                           } else {
                              var8 = var10.getName();
                           }
                        }
                     }

                     IndexColumn[] var15 = var7x.getIndexColumns();
                     int var16 = var7x.getUniqueColumnCount();
                     String var11 = var7x.getClass().getName();

                     for(int var12 = 0; var12 < var15.length; ++var12) {
                        IndexColumn var13 = var15[var12];
                        Column var14 = var13.column;
                        this.add(var1, var6, new Object[]{var7, var4x.getSchema().getName(), var4x.getName(), ValueBoolean.get(var12 >= var16), var7x.getName(), ValueSmallint.get((short)(var12 + 1)), var14.getName(), ValueInteger.get(0), ValueBoolean.get(var7x.getIndexType().isPrimaryKey()), var7x.getIndexType().getSQL(false), ValueBoolean.get(var7x.getIndexType().getBelongsToConstraint()), ValueSmallint.get((short)3), (var13.sortType & 1) != 0 ? "D" : "A", ValueInteger.get(0), "", replaceNullWithEmpty(var7x.getComment()), var7x.getCreateSQL(), ValueInteger.get(var7x.getId()), ValueInteger.get(var13.sortType), var8, var11});
                     }
                  }
               }

            });
            break;
         case 3:
            this.add(var1, var6, new Object[]{TableType.TABLE.toString()});
            this.add(var1, var6, new Object[]{TableType.TABLE_LINK.toString()});
            this.add(var1, var6, new Object[]{TableType.SYSTEM_TABLE.toString()});
            this.add(var1, var6, new Object[]{TableType.VIEW.toString()});
            this.add(var1, var6, new Object[]{TableType.EXTERNAL_TABLE_ENGINE.toString()});
            break;
         case 4:
            int var53 = 1;

            for(byte var79 = 42; var53 < var79; ++var53) {
               DataType var103 = DataType.getDataType(var53);
               this.add(var1, var6, new Object[]{Value.getTypeName(var103.type), ValueInteger.get(var103.sqlType), ValueInteger.get(MathUtils.convertLongToInt(var103.maxPrecision)), var103.prefix, var103.suffix, var103.params, ValueBoolean.FALSE, ValueSmallint.get(MathUtils.convertIntToShort(var103.minScale)), ValueSmallint.get(MathUtils.convertIntToShort(var103.maxScale)), DataType.isNumericType(var53) ? ValueInteger.get(10) : null, ValueInteger.get(var103.type), ValueBoolean.get(var103.caseSensitive), ValueSmallint.get((short)1), ValueSmallint.get((short)3)});
            }
            break;
         case 5:
            this.add(var1, var6, new Object[]{var7});
            break;
         case 6:
            for(Setting var77 : this.database.getAllSettings()) {
               String var101 = var77.getStringValue();
               if (var101 == null) {
                  var101 = Integer.toString(var77.getIntValue());
               }

               this.add(var1, var6, new Object[]{this.identifier(var77.getName()), var101});
            }

            this.add(var1, var6, new Object[]{"info.BUILD_ID", "240"});
            this.add(var1, var6, new Object[]{"info.VERSION_MAJOR", "2"});
            this.add(var1, var6, new Object[]{"info.VERSION_MINOR", "4"});
            this.add(var1, var6, new Object[]{"info.VERSION", Constants.FULL_VERSION});
            if (var8) {
               String[] var51 = new String[]{"java.runtime.version", "java.vm.name", "java.vendor", "os.name", "os.arch", "os.version", "sun.os.patch.level", "file.separator", "path.separator", "line.separator", "user.country", "user.language", "user.variant", "file.encoding"};

               for(String var129 : var51) {
                  this.add(var1, var6, new Object[]{"property." + var129, Utils.getProperty(var129, "")});
               }
            }

            this.add(var1, var6, new Object[]{"QUERY_TIMEOUT", Integer.toString(var1.getQueryTimeout())});
            this.add(var1, var6, new Object[]{"TIME ZONE", var1.currentTimeZone().getId()});
            this.add(var1, var6, new Object[]{"TRUNCATE_LARGE_LENGTH", var1.isTruncateLargeLength() ? "TRUE" : "FALSE"});
            this.add(var1, var6, new Object[]{"VARIABLE_BINARY", var1.isVariableBinary() ? "TRUE" : "FALSE"});
            this.add(var1, var6, new Object[]{"OLD_INFORMATION_SCHEMA", var1.isOldInformationSchema() ? "TRUE" : "FALSE"});
            BitSet var52 = var1.getNonKeywords();
            if (var52 != null) {
               this.add(var1, var6, new Object[]{"NON_KEYWORDS", ParserBase.formatNonKeywords(var52)});
            }

            this.database.populateInfo((var3x, var4x) -> this.add(var1, var6, new Object[]{var3x, var4x}));
            break;
         case 7:
            String var49 = "/org/h2/res/help.csv";

            try {
               byte[] var76 = Utils.getResource(var49);
               InputStreamReader var100 = new InputStreamReader(new ByteArrayInputStream(var76), StandardCharsets.UTF_8);
               Csv var118 = new Csv();
               var118.setLineCommentCharacter('#');
               ResultSet var128 = var118.read(var100, (String[])null);
               int var137 = var128.getMetaData().getColumnCount() - 1;
               String[] var142 = new String[5];

               for(int var146 = 0; var128.next(); ++var146) {
                  for(int var150 = 0; var150 < var137; ++var150) {
                     String var154 = var128.getString(1 + var150);
                     switch (var150) {
                        case 2:
                           var154 = Help.stripAnnotationsFromSyntax(var154);
                           break;
                        case 3:
                           var154 = Help.processHelpText(var154);
                     }

                     var142[var150] = var154.trim();
                  }

                  this.add(var1, var6, new Object[]{ValueInteger.get(var146), var142[0], var142[1], var142[2], var142[3]});
               }
               break;
            } catch (Exception var27) {
               throw DbException.convert(var27);
            }
         case 8:
            for(SchemaObject var75 : this.getAllSchemaObjects(3)) {
               Sequence var99 = (Sequence)var75;
               TypeInfo var117 = var99.getDataType();
               String var127 = Value.getTypeName(var117.getValueType());
               ValueInteger var136 = ValueInteger.get(var117.getScale());
               this.add(var1, var6, new Object[]{var7, var99.getSchema().getName(), var99.getName(), var127, ValueInteger.get(var99.getEffectivePrecision()), ValueInteger.get(10), var136, ValueBigint.get(var99.getStartValue()), ValueBigint.get(var99.getMinValue()), ValueBigint.get(var99.getMaxValue()), ValueBigint.get(var99.getIncrement()), var99.getCycle().isCycle() ? "YES" : "NO", var127, ValueInteger.get((int)var117.getPrecision()), var136, ValueBigint.get(var99.getCurrentValue()), ValueBoolean.get(var99.getBelongsToTable()), replaceNullWithEmpty(var99.getComment()), ValueBigint.get(var99.getCacheSize()), ValueInteger.get(var99.getId()), ValueBigint.get(var99.getMinValue()), ValueBigint.get(var99.getMaxValue()), ValueBoolean.get(var99.getCycle().isCycle())});
            }
            break;
         case 9:
            for(RightOwner var74 : this.database.getAllUsersAndRoles()) {
               if (var74 instanceof User) {
                  User var98 = (User)var74;
                  if (var8 || var1.getUser() == var98) {
                     this.add(var1, var6, new Object[]{this.identifier(var98.getName()), String.valueOf(var98.isAdmin()), replaceNullWithEmpty(var98.getComment()), ValueInteger.get(var98.getId())});
                  }
               }
            }
            break;
         case 10:
            for(RightOwner var73 : this.database.getAllUsersAndRoles()) {
               if (var73 instanceof Role) {
                  Role var97 = (Role)var73;
                  if (var8 || var1.getUser().isRoleGranted(var97)) {
                     this.add(var1, var6, new Object[]{this.identifier(var97.getName()), replaceNullWithEmpty(var97.getComment()), ValueInteger.get(var97.getId())});
                  }
               }
            }
            break;
         case 11:
            if (var8) {
               for(Right var72 : this.database.getAllRights()) {
                  Role var96 = var72.getGrantedRole();
                  DbObject var116 = var72.getGrantee();
                  String var126 = var116.getType() == 2 ? "USER" : "ROLE";
                  if (var96 == null) {
                     DbObject var135 = var72.getGrantedObject();
                     Schema var141 = null;
                     Table var145 = null;
                     if (var135 != null) {
                        if (var135 instanceof Schema) {
                           var141 = (Schema)var135;
                        } else if (var135 instanceof Table) {
                           var145 = (Table)var135;
                           var141 = var145.getSchema();
                        }
                     }

                     String var149 = var145 != null ? var145.getName() : "";
                     String var153 = var141 != null ? var141.getName() : "";
                     if (this.checkIndex(var1, var149, var4, var5)) {
                        this.add(var1, var6, new Object[]{this.identifier(var116.getName()), var126, "", var72.getRights(), var153, var149, ValueInteger.get(var72.getId())});
                     }
                  } else {
                     this.add(var1, var6, new Object[]{this.identifier(var116.getName()), var126, this.identifier(var96.getName()), "", "", "", ValueInteger.get(var72.getId())});
                  }
               }
            }
            break;
         case 12:
            label568:
            for(Schema var71 : this.database.getAllSchemas()) {
               Iterator var95 = var71.getAllFunctionsAndAggregates().iterator();

               while(true) {
                  FunctionAlias var125;
                  FunctionAlias.JavaMethod[] var134;
                  while(true) {
                     if (!var95.hasNext()) {
                        continue label568;
                     }

                     UserDefinedFunction var115 = (UserDefinedFunction)var95.next();
                     if (var115 instanceof FunctionAlias) {
                        var125 = (FunctionAlias)var115;

                        try {
                           var134 = var125.getJavaMethods();
                           break;
                        } catch (DbException var26) {
                        }
                     } else {
                        this.add(var1, var6, new Object[]{var7, this.database.getMainSchema().getName(), var115.getName(), var115.getJavaClassName(), "", ValueInteger.get(0), "NULL", ValueInteger.get(1), ValueSmallint.get((short)2), replaceNullWithEmpty(var115.getComment()), ValueInteger.get(var115.getId()), ""});
                     }
                  }

                  for(FunctionAlias.JavaMethod var152 : var134) {
                     TypeInfo var155 = var152.getDataType();
                     if (var155 == null) {
                        var155 = TypeInfo.TYPE_NULL;
                     }

                     this.add(var1, var6, new Object[]{var7, var125.getSchema().getName(), var125.getName(), var125.getJavaClassName(), var125.getJavaMethodName(), ValueInteger.get(DataType.convertTypeToSQLType(var155)), var155.getDeclaredTypeName(), ValueInteger.get(var152.getParameterCount()), ValueSmallint.get((short)(var155.getValueType() == 0 ? 1 : 2)), replaceNullWithEmpty(var125.getComment()), ValueInteger.get(var125.getId()), var125.getSource()});
                  }
               }
            }
            break;
         case 13:
            String var43 = this.database.getCompareMode().getName();

            for(Schema var94 : this.database.getAllSchemas()) {
               this.add(var1, var6, new Object[]{var7, var94.getName(), this.identifier(var94.getOwner().getName()), "Unicode", var43, ValueBoolean.get(var94.getId() == 0), replaceNullWithEmpty(var94.getComment()), ValueInteger.get(var94.getId())});
            }
            break;
         case 14:
            for(Right var69 : this.database.getAllRights()) {
               DbObject var93 = var69.getGrantedObject();
               if (var93 instanceof Table) {
                  Table var114 = (Table)var93;
                  if (this.checkIndex(var1, var114.getName(), var4, var5)) {
                     this.addPrivileges(var1, var6, var69.getGrantee(), var7, var114, (String)null, var69.getRightMask());
                  }
               }
            }
            break;
         case 15:
            for(Right var68 : this.database.getAllRights()) {
               DbObject var92 = var68.getGrantedObject();
               if (var92 instanceof Table) {
                  Table var113 = (Table)var92;
                  if (this.checkIndex(var1, var113.getName(), var4, var5)) {
                     DbObject var124 = var68.getGrantee();
                     int var133 = var68.getRightMask();

                     for(Column var151 : var113.getColumns()) {
                        this.addPrivileges(var1, var6, var124, var7, var113, var151.getName(), var133);
                     }
                  }
               }
            }
            break;
         case 16:
            for(Locale var112 : CompareMode.getCollationLocales(false)) {
               this.add(var1, var6, new Object[]{CompareMode.getName(var112), var112.toString()});
            }
            break;
         case 17:
            this.getAllTables(var1, var4, var5).filter(Table::isView).forEach((var4x) -> this.add(var1, var6, new Object[]{var7, var4x.getSchema().getName(), var4x.getName(), var4x.getCreateSQL(), "NONE", "NO", var4x instanceof TableView && ((TableView)var4x).isInvalid() ? "INVALID" : "VALID", replaceNullWithEmpty(var4x.getComment()), ValueInteger.get(var4x.getId())}));
            break;
         case 18:
            ArrayList var39 = this.database.getInDoubtTransactions();
            if (var39 != null && var8) {
               for(InDoubtTransaction var90 : var39) {
                  this.add(var1, var6, new Object[]{var90.getTransactionName(), var90.getStateDescription()});
               }
            }
            break;
         case 19:
            this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType() == Constraint.Type.REFERENTIAL && this.checkIndex(var1, var4x.getName(), var4, var5)).forEach((var4x) -> {
               ConstraintReferential var5 = (ConstraintReferential)var4x;
               IndexColumn[] var6x = var5.getColumns();
               IndexColumn[] var7x = var5.getRefColumns();
               Table var8 = var5.getTable();
               Table var9 = var5.getRefTable();
               ValueSmallint var10 = ValueSmallint.get(getRefAction(var5.getUpdateAction()));
               ValueSmallint var11 = ValueSmallint.get(getRefAction(var5.getDeleteAction()));

               for(int var12 = 0; var12 < var6x.length; ++var12) {
                  this.add(var1, var6, new Object[]{var7, var9.getSchema().getName(), var9.getName(), var7x[var12].column.getName(), var7, var8.getSchema().getName(), var8.getName(), var6x[var12].column.getName(), ValueSmallint.get((short)(var12 + 1)), var10, var11, var5.getName(), var5.getReferencedConstraint().getName(), ValueSmallint.get((short)7)});
               }

            });
            break;
         case 20:
            label543:
            for(Schema var65 : this.database.getAllSchemas()) {
               Iterator var89 = var65.getAllFunctionsAndAggregates().iterator();

               while(true) {
                  FunctionAlias var123;
                  FunctionAlias.JavaMethod[] var132;
                  while(true) {
                     if (!var89.hasNext()) {
                        continue label543;
                     }

                     UserDefinedFunction var111 = (UserDefinedFunction)var89.next();
                     if (var111 instanceof FunctionAlias) {
                        var123 = (FunctionAlias)var111;

                        try {
                           var132 = var123.getJavaMethods();
                           break;
                        } catch (DbException var25) {
                        }
                     }
                  }

                  for(FunctionAlias.JavaMethod var18 : var132) {
                     TypeInfo var19 = var18.getDataType();
                     if (var19 != null && var19.getValueType() != 0) {
                        DataType var20 = DataType.getDataType(var19.getValueType());
                        this.add(var1, var6, new Object[]{var7, var123.getSchema().getName(), var123.getName(), var123.getJavaClassName(), var123.getJavaMethodName(), ValueInteger.get(var18.getParameterCount()), ValueInteger.get(0), "P0", ValueInteger.get(DataType.convertTypeToSQLType(var19)), var19.getDeclaredTypeName(), ValueInteger.get(MathUtils.convertLongToInt(var20.defaultPrecision)), ValueSmallint.get(MathUtils.convertIntToShort(var20.defaultScale)), ValueSmallint.get((short)10), ValueSmallint.get((short)2), ValueSmallint.get((short)5), "", null});
                     }

                     Class[] var156 = var18.getColumnClasses();

                     for(int var21 = 0; var21 < var156.length; ++var21) {
                        if (!var18.hasConnectionParam() || var21 != 0) {
                           Class var22 = var156[var21];
                           TypeInfo var23 = ValueToObjectConverter2.classToType(var22);
                           DataType var24 = DataType.getDataType(var23.getValueType());
                           this.add(var1, var6, new Object[]{var7, var123.getSchema().getName(), var123.getName(), var123.getJavaClassName(), var123.getJavaMethodName(), ValueInteger.get(var18.getParameterCount()), ValueInteger.get(var21 + (var18.hasConnectionParam() ? 0 : 1)), "P" + (var21 + 1), ValueInteger.get(DataType.convertTypeToSQLType(var23)), var23.getDeclaredTypeName(), ValueInteger.get(MathUtils.convertLongToInt(var24.defaultPrecision)), ValueSmallint.get(MathUtils.convertIntToShort(var24.defaultScale)), ValueSmallint.get((short)10), ValueSmallint.get((short)(var22.isPrimitive() ? 0 : 1)), ValueSmallint.get((short)1), "", null});
                        }
                     }
                  }
               }
            }
            break;
         case 21:
            this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType() != Constraint.Type.DOMAIN && this.checkIndex(var1, var4x.getTable().getName(), var4, var5)).forEach((var4x) -> {
               Constraint.Type var5 = var4x.getConstraintType();
               String var6x = null;
               IndexColumn[] var7x = null;
               Table var8 = var4x.getTable();
               Index var9 = var4x.getIndex();
               String var10 = null;
               if (var9 != null) {
                  var10 = var9.getName();
               }

               if (var5 == Constraint.Type.CHECK) {
                  var6x = var4x.getExpression().getSQL(0);
               } else if (var5.isUnique()) {
                  var7x = ((ConstraintUnique)var4x).getColumns();
               } else if (var5 == Constraint.Type.REFERENTIAL) {
                  var7x = ((ConstraintReferential)var4x).getColumns();
               }

               String var11 = null;
               if (var7x != null) {
                  StringBuilder var12 = new StringBuilder();
                  int var13 = 0;

                  for(int var14 = var7x.length; var13 < var14; ++var13) {
                     if (var13 > 0) {
                        var12.append(',');
                     }

                     var12.append(var7x[var13].column.getName());
                  }

                  var11 = var12.toString();
               }

               this.add(var1, var6, new Object[]{var7, var4x.getSchema().getName(), var4x.getName(), var5 == Constraint.Type.PRIMARY_KEY ? var5.getSqlName() : var5.name(), var7, var8.getSchema().getName(), var8.getName(), var10, var6x, var11, replaceNullWithEmpty(var4x.getComment()), var4x.getCreateSQL(), ValueInteger.get(var4x.getId())});
            });
            break;
         case 22:
            for(SchemaObject var64 : this.getAllSchemaObjects(11)) {
               Constant var88 = (Constant)var64;
               ValueExpression var110 = var88.getValue();
               this.add(var1, var6, new Object[]{var7, var88.getSchema().getName(), var88.getName(), ValueInteger.get(DataType.convertTypeToSQLType(var110.getType())), replaceNullWithEmpty(var88.getComment()), var110.getSQL(0), ValueInteger.get(var88.getId())});
            }
            break;
         case 23:
            for(SchemaObject var63 : this.getAllSchemaObjects(12)) {
               Domain var87 = (Domain)var63;
               Domain var109 = var87.getDomain();
               TypeInfo var122 = var87.getDataType();
               this.add(var1, var6, new Object[]{var7, var87.getSchema().getName(), var87.getName(), var87.getDefaultSQL(), var87.getOnUpdateSQL(), ValueInteger.get(DataType.convertTypeToSQLType(var122)), ValueInteger.get(MathUtils.convertLongToInt(var122.getPrecision())), ValueInteger.get(var122.getScale()), var122.getDeclaredTypeName(), var109 != null ? var7 : null, var109 != null ? var109.getSchema().getName() : null, var109 != null ? var109.getName() : null, ValueInteger.get(50), replaceNullWithEmpty(var87.getComment()), var87.getCreateSQL(), ValueInteger.get(var87.getId()), var87.getDefaultSQL(), "YES", null});
            }
            break;
         case 24:
            for(SchemaObject var62 : this.getAllSchemaObjects(4)) {
               TriggerObject var86 = (TriggerObject)var62;
               Table var108 = var86.getTable();
               this.add(var1, var6, new Object[]{var7, var86.getSchema().getName(), var86.getName(), var86.getTypeNameList(new StringBuilder()).toString(), var7, var108.getSchema().getName(), var108.getName(), ValueBoolean.get(var86.isBefore()), var86.getTriggerClassName(), ValueInteger.get(var86.getQueueSize()), ValueBoolean.get(var86.isNoWait()), replaceNullWithEmpty(var86.getComment()), var86.getCreateSQL(), ValueInteger.get(var86.getId())});
            }
            break;
         case 25:
            for(SessionLocal var107 : this.database.getSessions(false)) {
               if (var8 || var107 == var1) {
                  NetworkConnectionInfo var121 = var107.getNetworkConnectionInfo();
                  Command var131 = var107.getCurrentCommand();
                  int var15 = var107.getBlockingSessionId();
                  this.add(var1, var6, new Object[]{ValueInteger.get(var107.getId()), var107.getUser().getName(), var121 == null ? null : var121.getServer(), var121 == null ? null : var121.getClient(), var121 == null ? null : var121.getClientInfo(), var107.getSessionStart(), var107.getIsolationLevel().getSQL(), var131 == null ? null : var131.toString(), var131 == null ? null : var107.getCommandStartOrEnd(), ValueBoolean.get(var107.hasPendingTransaction()), String.valueOf(var107.getState()), var15 == 0 ? null : ValueInteger.get(var15), var107.getState() == SessionLocal.State.SLEEP ? var107.getCommandStartOrEnd() : null});
               }
            }
            break;
         case 26:
            for(SessionLocal var106 : this.database.getSessions(false)) {
               if (var8 || var106 == var1) {
                  for(Table var130 : var106.getLocks()) {
                     this.add(var1, var6, new Object[]{var130.getSchema().getName(), var130.getName(), ValueInteger.get(var106.getId()), var130.isLockedExclusivelyBy(var106) ? "WRITE" : "READ"});
                  }
               }
            }
            break;
         case 27:
            for(String var104 : var1.getVariableNames()) {
               Value var13 = var1.getVariable(var104);
               StringBuilder var14 = (new StringBuilder()).append("SET @").append(var104).append(' ');
               var13.getSQL(var14, 0);
               this.add(var1, var6, new Object[]{"@" + var104, var14.toString()});
            }

            for(Table var57 : var1.getLocalTempTables()) {
               this.add(var1, var6, new Object[]{"TABLE " + var57.getName(), var57.getCreateSQL()});
            }

            String[] var32 = var1.getSchemaSearchPath();
            if (var32 != null && var32.length > 0) {
               StringBuilder var58 = new StringBuilder("SET SCHEMA_SEARCH_PATH ");
               int var82 = 0;

               for(int var105 = var32.length; var82 < var105; ++var82) {
                  if (var82 > 0) {
                     var58.append(", ");
                  }

                  StringUtils.quoteIdentifier(var58, var32[var82]);
               }

               this.add(var1, var6, new Object[]{"SCHEMA_SEARCH_PATH", var58.toString()});
            }

            String var59 = var1.getCurrentSchemaName();
            if (var59 != null) {
               this.add(var1, var6, new Object[]{"SCHEMA", StringUtils.quoteIdentifier(new StringBuilder("SET SCHEMA "), var59).toString()});
            }

            TimeZoneProvider var83 = var1.currentTimeZone();
            if (!var83.equals(DateTimeUtils.getTimeZone())) {
               this.add(var1, var6, new Object[]{"TIME ZONE", StringUtils.quoteStringSQL(new StringBuilder("SET TIME ZONE "), var83.getId()).toString()});
            }
            break;
         case 28:
            QueryStatisticsData var29 = this.database.getQueryStatisticsData();
            if (var29 != null) {
               for(QueryStatisticsData.QueryEntry var80 : var29.getQueries()) {
                  this.add(var1, var6, new Object[]{var80.sqlStatement, ValueInteger.get(var80.count), ValueDouble.get((double)var80.executionTimeMinNanos / (double)1000000.0F), ValueDouble.get((double)var80.executionTimeMaxNanos / (double)1000000.0F), ValueDouble.get((double)var80.executionTimeCumulativeNanos / (double)1000000.0F), ValueDouble.get(var80.executionTimeMeanNanos / (double)1000000.0F), ValueDouble.get(var80.getExecutionTimeStandardDeviation() / (double)1000000.0F), ValueBigint.get(var80.rowCountMin), ValueBigint.get(var80.rowCountMax), ValueBigint.get(var80.rowCountCumulative), ValueDouble.get(var80.rowCountMean), ValueDouble.get(var80.getRowCountStandardDeviation())});
               }
            }
            break;
         case 29:
            for(TableSynonym var54 : this.database.getAllSynonyms()) {
               this.add(var1, var6, new Object[]{var7, var54.getSchema().getName(), var54.getName(), var54.getSynonymForName(), var54.getSynonymForSchema().getName(), "SYNONYM", "VALID", replaceNullWithEmpty(var54.getComment()), ValueInteger.get(var54.getId())});
            }
            break;
         case 30:
            this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType() != Constraint.Type.DOMAIN && this.checkIndex(var1, var4x.getTable().getName(), var4, var5)).forEach((var4x) -> {
               Constraint.Type var5 = var4x.getConstraintType();
               Table var6x = var4x.getTable();
               this.add(var1, var6, new Object[]{var7, var4x.getSchema().getName(), var4x.getName(), var5.getSqlName(), var7, var6x.getSchema().getName(), var6x.getName(), "NO", "NO", replaceNullWithEmpty(var4x.getComment()), var4x.getCreateSQL(), ValueInteger.get(var4x.getId())});
            });
            break;
         case 31:
            for(SchemaObject var10 : this.getAllSchemaObjects(5)) {
               if (((Constraint)var10).getConstraintType() == Constraint.Type.DOMAIN) {
                  ConstraintDomain var11 = (ConstraintDomain)var10;
                  Domain var12 = var11.getDomain();
                  this.add(var1, var6, new Object[]{var7, var11.getSchema().getName(), var11.getName(), var7, var12.getSchema().getName(), var12.getName(), "NO", "NO", replaceNullWithEmpty(var11.getComment()), var11.getCreateSQL(), ValueInteger.get(var11.getId())});
               }
            }
            break;
         case 32:
            this.getAllConstraints(var1).forEach((var6x) -> {
               Constraint.Type var7x = var6x.getConstraintType();
               IndexColumn[] var8;
               if (var7x.isUnique()) {
                  var8 = ((ConstraintUnique)var6x).getColumns();
               } else {
                  if (var7x != Constraint.Type.REFERENTIAL) {
                     return;
                  }

                  var8 = ((ConstraintReferential)var6x).getColumns();
               }

               Table var9 = var6x.getTable();
               String var10 = var9.getName();
               if (this.checkIndex(var1, var10, var4, var5)) {
                  ConstraintUnique var11;
                  if (var7x == Constraint.Type.REFERENTIAL) {
                     var11 = var6x.getReferencedConstraint();
                  } else {
                     var11 = null;
                  }

                  Index var12 = var6x.getIndex();

                  for(int var13 = 0; var13 < var8.length; ++var13) {
                     IndexColumn var14 = var8[var13];
                     ValueInteger var15 = ValueInteger.get(var13 + 1);
                     ValueInteger var16 = null;
                     if (var11 != null) {
                        Column var17 = ((ConstraintReferential)var6x).getRefColumns()[var13].column;
                        IndexColumn[] var18 = var11.getColumns();

                        for(int var19 = 0; var19 < var18.length; ++var19) {
                           if (var18[var19].column.equals(var17)) {
                              var16 = ValueInteger.get(var19 + 1);
                              break;
                           }
                        }
                     }

                     this.add(var1, var6, new Object[]{var7, var6x.getSchema().getName(), var6x.getName(), var7, var9.getSchema().getName(), var10, var14.columnName, var15, var16, var12 != null ? var7 : null, var12 != null ? var12.getSchema().getName() : null, var12 != null ? var12.getName() : null});
                  }

               }
            });
            break;
         case 33:
            this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType() == Constraint.Type.REFERENTIAL && this.checkIndex(var1, var4x.getName(), var4, var5)).forEach((var4x) -> {
               ConstraintReferential var5 = (ConstraintReferential)var4x;
               ConstraintUnique var6x = var5.getReferencedConstraint();
               this.add(var1, var6, new Object[]{var7, var5.getSchema().getName(), var5.getName(), var7, var6x.getSchema().getName(), var6x.getName(), "NONE", var5.getUpdateAction().getSqlName(), var5.getDeleteAction().getSqlName()});
            });
            break;
         case 34:
            this.getAllConstraints(var1).filter((var4x) -> var4x.getConstraintType().isCheck() && this.checkIndex(var1, var4x.getName(), var4, var5)).forEach((var4x) -> this.add(var1, var6, new Object[]{var7, var4x.getSchema().getName(), var4x.getName(), var4x.getExpression().getSQL(0, 2)}));
            break;
         case 35:
            this.getAllConstraints(var1).forEach((var6x) -> {
               switch (var6x.getConstraintType()) {
                  case CHECK:
                  case DOMAIN:
                     HashSet var12 = new HashSet();
                     var6x.getExpression().isEverything(ExpressionVisitor.getColumnsVisitor(var12, (Table)null));

                     for(Column var16 : var12) {
                        Table var10 = var16.getTable();
                        if (this.checkIndex(var1, var10.getName(), var4, var5)) {
                           this.addConstraintColumnUsage(var1, var6, var7, var6x, var16);
                        }
                     }
                     break;
                  case REFERENTIAL:
                     Table var7x = var6x.getRefTable();
                     if (this.checkIndex(var1, var7x.getName(), var4, var5)) {
                        for(Column var9 : var6x.getReferencedColumns(var7x)) {
                           this.addConstraintColumnUsage(var1, var6, var7, var6x, var9);
                        }
                     }
                  case PRIMARY_KEY:
                  case UNIQUE:
                     Table var11 = var6x.getTable();
                     if (this.checkIndex(var1, var11.getName(), var4, var5)) {
                        for(Column var15 : var6x.getReferencedColumns(var11)) {
                           this.addConstraintColumnUsage(var1, var6, var7, var6x, var15);
                        }
                     }
               }

            });
            break;
         default:
            throw DbException.getInternalError("type=" + this.type);
      }

      return var6;
   }

   private static short getRefAction(ConstraintActionType var0) {
      switch (var0) {
         case NO_ACTION:
            return 3;
         case CASCADE:
            return 0;
         case RESTRICT:
            return 1;
         case SET_DEFAULT:
            return 4;
         case SET_NULL:
            return 2;
         default:
            throw DbException.getInternalError("action=" + var0);
      }
   }

   private void addConstraintColumnUsage(SessionLocal var1, ArrayList<Row> var2, String var3, Constraint var4, Column var5) {
      Table var6 = var5.getTable();
      this.add(var1, var2, new Object[]{var3, var6.getSchema().getName(), var6.getName(), var5.getName(), var3, var4.getSchema().getName(), var4.getName()});
   }

   private void addPrivileges(SessionLocal var1, ArrayList<Row> var2, DbObject var3, String var4, Table var5, String var6, int var7) {
      if ((var7 & 1) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "SELECT");
      }

      if ((var7 & 4) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "INSERT");
      }

      if ((var7 & 8) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "UPDATE");
      }

      if ((var7 & 2) != 0) {
         this.addPrivilege(var1, var2, var3, var4, var5, var6, "DELETE");
      }

   }

   private void addPrivilege(SessionLocal var1, ArrayList<Row> var2, DbObject var3, String var4, Table var5, String var6, String var7) {
      String var8 = "NO";
      if (var3.getType() == 2) {
         User var9 = (User)var3;
         if (var9.isAdmin()) {
            var8 = "YES";
         }
      }

      if (var6 == null) {
         this.add(var1, var2, new Object[]{null, this.identifier(var3.getName()), var4, var5.getSchema().getName(), var5.getName(), var7, var8});
      } else {
         this.add(var1, var2, new Object[]{null, this.identifier(var3.getName()), var4, var5.getSchema().getName(), var5.getName(), var6, var7, var8});
      }

   }

   private ArrayList<SchemaObject> getAllSchemaObjects(int var1) {
      ArrayList var2 = new ArrayList();

      for(Schema var4 : this.database.getAllSchemas()) {
         var4.getAll(var1, var2);
      }

      return var2;
   }

   public long getMaxDataModificationId() {
      switch (this.type) {
         case 6:
         case 8:
         case 18:
         case 25:
         case 26:
         case 27:
            return Long.MAX_VALUE;
         default:
            return this.database.getModificationDataId();
      }
   }
}
