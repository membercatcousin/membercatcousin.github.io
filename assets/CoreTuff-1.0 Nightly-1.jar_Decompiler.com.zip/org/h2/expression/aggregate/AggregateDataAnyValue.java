package org.h2.expression.aggregate;

import java.util.ArrayList;
import java.util.Random;
import org.h2.engine.SessionLocal;
import org.h2.value.Value;
import org.h2.value.ValueNull;

final class AggregateDataAnyValue extends AggregateData {
   private static final int MAX_VALUES = 256;
   ArrayList<Value> values = new ArrayList();
   private long filter = -1L;

   void add(SessionLocal var1, Value var2) {
      if (var2 != ValueNull.INSTANCE) {
         long var3 = this.filter;
         if (var3 == Long.MIN_VALUE || (var1.getRandom().nextLong() | var3) == var3) {
            this.values.add(var2);
            if (this.values.size() == 256) {
               this.compact(var1);
            }
         }

      }
   }

   private void compact(SessionLocal var1) {
      this.filter <<= 1;
      Random var2 = var1.getRandom();
      int var3 = 0;

      for(int var4 = 0; var4 < 128; ++var4) {
         int var5 = var3;
         if (var2.nextBoolean()) {
            var5 = var3 + 1;
         }

         this.values.set(var4, (Value)this.values.get(var5));
         var3 += 2;
      }

      this.values.subList(128, 256).clear();
   }

   Value getValue(SessionLocal var1) {
      int var2 = this.values.size();
      return (Value)(var2 == 0 ? ValueNull.INSTANCE : (Value)this.values.get(var1.getRandom().nextInt(var2)));
   }
}
