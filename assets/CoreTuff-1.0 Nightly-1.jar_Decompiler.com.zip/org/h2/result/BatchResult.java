package org.h2.result;

import java.sql.SQLException;
import java.util.List;

public class BatchResult {
   private final long[] updateCounts;
   private final ResultInterface generatedKeys;
   private final List<SQLException> exceptions;

   public BatchResult(long[] var1, ResultInterface var2, List<SQLException> var3) {
      this.updateCounts = var1;
      this.generatedKeys = var2;
      this.exceptions = var3;
   }

   public long[] getUpdateCounts() {
      return this.updateCounts;
   }

   public ResultInterface getGeneratedKeys() {
      return this.generatedKeys;
   }

   public List<SQLException> getExceptions() {
      return this.exceptions;
   }
}
