package org.h2.table;

import java.util.ArrayList;
import java.util.List;
import org.h2.command.Prepared;
import org.h2.command.QueryScope;
import org.h2.command.query.AllColumnsForPlan;
import org.h2.command.query.Query;
import org.h2.engine.Database;
import org.h2.engine.SessionLocal;
import org.h2.index.Index;
import org.h2.index.QueryExpressionIndex;
import org.h2.index.RegularQueryExpressionIndex;
import org.h2.message.DbException;
import org.h2.result.SortOrder;
import org.h2.schema.Schema;
import org.h2.util.StringUtils;
import org.h2.util.Utils;

public final class TableView extends QueryExpressionTable {
   private String querySQL;
   private Column[] columnTemplates;
   private DbException createException;

   public TableView(Schema var1, int var2, String var3, String var4, Column[] var5, SessionLocal var6) {
      super(var1, var2, var3);
      this.init(var4, var5, var6);
   }

   protected QueryExpressionIndex createIndex(SessionLocal var1, int[] var2) {
      return new RegularQueryExpressionIndex(this, this.querySQL, (ArrayList)null, var1, var2);
   }

   public void replace(String var1, Column[] var2, SessionLocal var3, boolean var4) {
      String var5 = this.querySQL;
      Column[] var6 = this.columnTemplates;
      this.init(var1, var2, var3);
      DbException var7 = this.recompile(var3, var4, true);
      if (var7 != null) {
         this.init(var5, var6, var3);
         this.recompile(var3, true, false);
         throw var7;
      }
   }

   private synchronized void init(String var1, Column[] var2, SessionLocal var3) {
      this.querySQL = var1;
      this.columnTemplates = var2;
      this.initColumnsAndTables(var3);
   }

   private static Query compileViewQuery(SessionLocal var0, String var1) {
      var0.setParsingCreateView(true);

      Prepared var2;
      try {
         var2 = var0.prepare(var1, false, false, (QueryScope)null);
      } finally {
         var0.setParsingCreateView(false);
      }

      if (!(var2 instanceof Query)) {
         throw DbException.getSyntaxError(var1, 0);
      } else {
         return (Query)var2;
      }
   }

   public synchronized DbException recompile(SessionLocal var1, boolean var2, boolean var3) {
      try {
         compileViewQuery(var1, this.querySQL);
      } catch (DbException var8) {
         if (!var2) {
            return var8;
         }
      }

      ArrayList var4 = new ArrayList(this.getDependentViews());
      this.initColumnsAndTables(var1);

      for(TableView var6 : var4) {
         DbException var7 = var6.recompile(var1, var2, false);
         if (var7 != null && !var2) {
            return var7;
         }
      }

      if (var3) {
         clearIndexCaches(this.database);
      }

      return var2 ? null : this.createException;
   }

   private void initColumnsAndTables(SessionLocal var1) {
      this.removeCurrentViewFromOtherTables();

      Column[] var2;
      try {
         Query var3 = compileViewQuery(var1, this.querySQL);
         this.querySQL = var3.getPlanSQL(0);
         this.tables = new ArrayList(var3.getTables());
         var2 = this.initColumns(var1, this.columnTemplates, var3, false, false);
         this.createException = null;
         this.viewQuery = var3;
      } catch (DbException var4) {
         if (var4.getErrorCode() == 90156) {
            throw var4;
         }

         var4.addSQL(this.getCreateSQL());
         this.createException = var4;
         this.tables = Utils.<Table>newSmallArrayList();
         var2 = new Column[0];
      }

      this.setColumns(var2);
      if (this.getId() != 0) {
         this.addDependentViewToTables();
      }

   }

   public boolean isInvalid() {
      return this.createException != null;
   }

   public Query getTopQuery() {
      return null;
   }

   public String getDropSQL() {
      return this.getSQL(new StringBuilder("DROP VIEW IF EXISTS "), 0).append(" CASCADE").toString();
   }

   public String getCreateSQLForCopy(Table var1, String var2) {
      return this.getCreateSQL(false, true, var2);
   }

   public String getCreateSQL() {
      return this.getCreateSQL(false, true);
   }

   public String getCreateSQL(boolean var1, boolean var2) {
      return this.getCreateSQL(var1, var2, this.getSQL(0));
   }

   private String getCreateSQL(boolean var1, boolean var2, String var3) {
      StringBuilder var4 = new StringBuilder("CREATE ");
      if (var1) {
         var4.append("OR REPLACE ");
      }

      if (var2) {
         var4.append("FORCE ");
      }

      var4.append("VIEW ");
      var4.append(var3);
      if (this.comment != null) {
         var4.append(" COMMENT ");
         StringUtils.quoteStringSQL(var4, this.comment);
      }

      if (this.columns != null && this.columns.length > 0) {
         var4.append('(');
         Column.writeColumns(var4, this.columns, 0);
         var4.append(')');
      } else if (this.columnTemplates != null) {
         var4.append('(');
         Column.writeColumns(var4, this.columnTemplates, 0);
         var4.append(')');
      }

      return var4.append(" AS\n").append(this.querySQL).toString();
   }

   public boolean canDrop() {
      return true;
   }

   public TableType getTableType() {
      return TableType.VIEW;
   }

   public void removeChildrenAndResources(SessionLocal var1) {
      this.removeCurrentViewFromOtherTables();
      super.removeChildrenAndResources(var1);
      this.querySQL = null;
      clearIndexCaches(this.database);
      this.invalidate();
   }

   public static void clearIndexCaches(Database var0) {
      for(SessionLocal var4 : var0.getSessions(true)) {
         var4.clearViewIndexCache();
      }

   }

   public String getQuerySQL() {
      return this.querySQL;
   }

   public QueryScope getQueryScope() {
      return null;
   }

   public Index getScanIndex(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6) {
      if (this.createException != null) {
         String var7 = this.createException.getMessage();
         throw DbException.get(90109, this.createException, this.getTraceSQL(), var7);
      } else {
         return super.getScanIndex(var1, var2, var3, var4, var5, var6);
      }
   }

   public long getMaxDataModificationId() {
      return this.createException == null && this.viewQuery != null ? super.getMaxDataModificationId() : Long.MAX_VALUE;
   }

   private void removeCurrentViewFromOtherTables() {
      if (this.tables != null) {
         for(Table var2 : this.tables) {
            var2.removeDependentView(this);
         }

         this.tables.clear();
      }

   }

   private void addDependentViewToTables() {
      for(Table var2 : this.tables) {
         var2.addDependentView(this);
      }

   }

   public boolean isDeterministic() {
      return this.viewQuery == null ? false : super.isDeterministic();
   }

   public List<Table> getTables() {
      return this.tables;
   }
}
