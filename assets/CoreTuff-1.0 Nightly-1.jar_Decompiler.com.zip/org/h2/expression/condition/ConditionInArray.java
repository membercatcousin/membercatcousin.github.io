package org.h2.expression.condition;

import java.util.AbstractList;
import java.util.Arrays;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionColumn;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.Parameter;
import org.h2.expression.ValueExpression;
import org.h2.index.IndexCondition;
import org.h2.table.ColumnResolver;
import org.h2.table.TableFilter;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueArray;
import org.h2.value.ValueBoolean;
import org.h2.value.ValueNull;

public class ConditionInArray extends Condition {
   private Expression left;
   private final boolean whenOperand;
   private Expression right;
   private final boolean all;
   private final int compareType;

   public ConditionInArray(Expression var1, boolean var2, Expression var3, boolean var4, int var5) {
      this.left = var1;
      this.whenOperand = var2;
      this.right = var3;
      this.all = var4;
      this.compareType = var5;
   }

   public Value getValue(SessionLocal var1) {
      return this.getValue(var1, this.left.getValue(var1));
   }

   public boolean getWhenValue(SessionLocal var1, Value var2) {
      return !this.whenOperand ? super.getWhenValue(var1, var2) : this.getValue(var1, var2).isTrue();
   }

   private Value getValue(SessionLocal var1, Value var2) {
      Value var3 = this.right.getValue(var1);
      if (var3 == ValueNull.INSTANCE) {
         return ValueNull.INSTANCE;
      } else {
         Value[] var4 = var3.convertToAnyArray(var1).getList();
         if (var4.length == 0) {
            return ValueBoolean.get(this.all);
         } else if ((this.compareType & -2) == 6) {
            return this.getNullSafeValueSlow(var1, var4, var2);
         } else {
            return (Value)(var2.containsNull() ? ValueNull.INSTANCE : this.getValueSlow(var1, var4, var2));
         }
      }
   }

   private Value getValueSlow(SessionLocal var1, Value[] var2, Value var3) {
      boolean var4 = false;
      ValueBoolean var5 = ValueBoolean.get(!this.all);

      for(Value var9 : var2) {
         Value var10 = Comparison.compare(var1, var3, var9, this.compareType);
         if (var10 == ValueNull.INSTANCE) {
            var4 = true;
         } else if (var10 == var5) {
            return ValueBoolean.get(!this.all);
         }
      }

      if (var4) {
         return ValueNull.INSTANCE;
      } else {
         return ValueBoolean.get(this.all);
      }
   }

   private Value getNullSafeValueSlow(SessionLocal var1, Value[] var2, Value var3) {
      boolean var4 = this.all == (this.compareType == 7);

      for(Value var8 : var2) {
         if (var1.areEqual(var3, var8) == var4) {
            return ValueBoolean.get(!this.all);
         }
      }

      return ValueBoolean.get(this.all);
   }

   public boolean isWhenConditionOperand() {
      return this.whenOperand;
   }

   public Expression getNotIfPossible(SessionLocal var1) {
      return this.whenOperand ? null : new ConditionInArray(this.left, false, this.right, !this.all, Comparison.getNotCompareType(this.compareType));
   }

   public void mapColumns(ColumnResolver var1, int var2, int var3) {
      this.left.mapColumns(var1, var2, var3);
      this.right.mapColumns(var1, var2, var3);
   }

   public Expression optimize(SessionLocal var1) {
      this.right = this.right.optimize(var1);
      this.left = this.left.optimize(var1);
      return (Expression)(!this.whenOperand && this.left.isConstant() && this.right.isConstant() ? ValueExpression.getBoolean(this.getValue(var1)) : this);
   }

   public void createIndexConditions(SessionLocal var1, TableFilter var2) {
      if (!this.whenOperand && !this.all && this.compareType == 0 && this.left instanceof ExpressionColumn) {
         ExpressionColumn var3 = (ExpressionColumn)this.left;
         if (var2 == var3.getTableFilter()) {
            if (this.right instanceof Parameter) {
               var2.addIndexCondition(IndexCondition.getInList(var3, new ParameterList((Parameter)this.right)));
            } else if (this.right.isConstant()) {
               Value var4 = this.right.getValue((SessionLocal)null);
               if (var4 instanceof ValueArray) {
                  Value[] var5 = ((ValueArray)var4).getList();
                  int var6 = var5.length;
                  if (var6 == 0) {
                     var2.addIndexCondition(IndexCondition.get(9, var3, ValueExpression.FALSE));
                  } else {
                     TypeInfo var7 = var3.getType();
                     TypeInfo var8 = var7;

                     for(int var9 = 0; var9 < var6; ++var9) {
                        var8 = TypeInfo.getHigherType(var8, var5[var9].getType());
                     }

                     if (TypeInfo.haveSameOrdering(var7, var8)) {
                        Expression[] var14 = new Expression[var6];

                        for(int var10 = 0; var10 < var6; ++var10) {
                           var14[var10] = ValueExpression.get(var5[var10]);
                        }

                        var2.addIndexCondition(IndexCondition.getInList(var3, Arrays.asList(var14)));
                     }
                  }
               }
            } else {
               ExpressionVisitor var11 = ExpressionVisitor.getNotFromResolverVisitor(var2);
               if (this.right.isEverything(var11)) {
                  TypeInfo var12 = this.right.getType();
                  if (var12.getValueType() == 40) {
                     TypeInfo var13 = var3.getType();
                     if (TypeInfo.haveSameOrdering(var13, TypeInfo.getHigherType(var13, (TypeInfo)var12.getExtTypeInfo()))) {
                        var2.addIndexCondition(IndexCondition.getInArray(var3, this.right));
                     }
                  }
               }
            }

         }
      }
   }

   public void setEvaluatable(TableFilter var1, boolean var2) {
      this.left.setEvaluatable(var1, var2);
      this.right.setEvaluatable(var1, var2);
   }

   public boolean needParentheses() {
      return true;
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      return this.getWhenSQL(this.left.getSQL(var1, var2, 0), var2);
   }

   public StringBuilder getWhenSQL(StringBuilder var1, int var2) {
      return this.right.getSQL(var1.append(' ').append(Comparison.COMPARE_TYPES[this.compareType]).append(this.all ? " ALL(" : " ANY("), var2).append(')');
   }

   public void updateAggregate(SessionLocal var1, int var2) {
      this.left.updateAggregate(var1, var2);
      this.right.updateAggregate(var1, var2);
   }

   public boolean isEverything(ExpressionVisitor var1) {
      return this.left.isEverything(var1) && this.right.isEverything(var1);
   }

   public int getCost() {
      return this.left.getCost() + this.right.getCost() + 10;
   }

   private static final class ParameterList extends AbstractList<Expression> {
      private final Parameter parameter;

      ParameterList(Parameter var1) {
         this.parameter = var1;
      }

      public Expression get(int var1) {
         Value var2 = this.parameter.getParamValue();
         if (var2 instanceof ValueArray) {
            return ValueExpression.get(((ValueArray)var2).getList()[var1]);
         } else if (var1 != 0) {
            throw new IndexOutOfBoundsException();
         } else {
            return ValueExpression.get(var2);
         }
      }

      public int size() {
         if (!this.parameter.isValueSet()) {
            return 0;
         } else {
            Value var1 = this.parameter.getParamValue();
            return var1 instanceof ValueArray ? ((ValueArray)var1).getList().length : 1;
         }
      }
   }
}
