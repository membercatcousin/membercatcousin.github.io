package org.h2.expression.aggregate;

import java.math.BigInteger;
import org.h2.engine.SessionLocal;
import org.h2.expression.function.GCDFunction;
import org.h2.message.DbException;
import org.h2.value.Value;
import org.h2.value.ValueNull;
import org.h2.value.ValueNumeric;

final class AggregateDataGCD extends AggregateData {
   private final boolean lcm;
   private boolean skipRemaining;
   private boolean overflow;
   private BigInteger bi;

   AggregateDataGCD(boolean var1) {
      this.lcm = var1;
   }

   void add(SessionLocal var1, Value var2) {
      if (var2 != ValueNull.INSTANCE && !this.skipRemaining) {
         BigInteger var3 = var2.getBigInteger();
         if (this.lcm) {
            if (var3.signum() == 0) {
               this.bi = BigInteger.ZERO;
               this.skipRemaining = true;
               this.overflow = false;
            } else if (this.bi == null) {
               this.bi = var3.abs();
            } else if (!this.overflow) {
               this.bi = this.bi.multiply(var3).abs().divide(this.bi.gcd(var3));
               this.overflow = this.bi.bitLength() > GCDFunction.MAX_BIT_LENGTH;
            }
         } else {
            if (this.bi == null) {
               this.bi = var3.abs();
            } else {
               if (var3.signum() == 0) {
                  return;
               }

               this.bi = this.bi.gcd(var3);
            }

            this.skipRemaining = this.bi.equals(BigInteger.ONE);
         }

      }
   }

   Value getValue(SessionLocal var1) {
      if (this.overflow) {
         throw DbException.getValueTooLongException("NUMERIC", "unknown least common multiple", -1L);
      } else {
         return (Value)(this.bi != null ? ValueNumeric.get(this.bi) : ValueNull.INSTANCE);
      }
   }
}
