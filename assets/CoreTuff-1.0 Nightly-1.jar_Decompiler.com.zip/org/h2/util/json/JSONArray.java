package org.h2.util.json;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.function.Function;

public final class JSONArray extends JSONValue {
   private final ArrayList<JSONValue> elements = new ArrayList();

   JSONArray() {
   }

   void addElement(JSONValue var1) {
      this.elements.add(var1);
   }

   public void addTo(JSONTarget<?> var1) {
      var1.startArray();

      for(JSONValue var3 : this.elements) {
         var3.addTo(var1);
      }

      var1.endArray();
   }

   public int length() {
      return this.elements.size();
   }

   public JSONValue[] getArray() {
      return (JSONValue[])this.elements.toArray(new JSONValue[0]);
   }

   public <E> E[] getArray(Class<E> var1, Function<JSONValue, E> var2) {
      int var3 = this.elements.size();
      Object[] var4 = Array.newInstance(var1, var3);

      for(int var5 = 0; var5 < var3; ++var5) {
         var4[var5] = var2.apply((JSONValue)this.elements.get(var5));
      }

      return (E[])var4;
   }

   public JSONValue getElement(int var1) {
      return var1 >= 0 && var1 < this.elements.size() ? (JSONValue)this.elements.get(var1) : null;
   }
}
