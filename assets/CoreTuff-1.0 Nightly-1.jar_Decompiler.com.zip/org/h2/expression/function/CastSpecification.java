package org.h2.expression.function;

import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.TypedValueExpression;
import org.h2.expression.ValueExpression;
import org.h2.message.DbException;
import org.h2.schema.Domain;
import org.h2.table.Column;
import org.h2.util.DateTimeTemplate;
import org.h2.util.HasSQL;
import org.h2.value.DataType;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueNull;
import org.h2.value.ValueVarchar;

public final class CastSpecification extends Function1_2 {
   private Domain domain;

   public CastSpecification(Expression var1, Column var2, Expression var3) {
      super(var1, var3);
      this.type = var2.getType();
      this.domain = var2.getDomain();
   }

   public CastSpecification(Expression var1, Column var2) {
      super(var1, (Expression)null);
      this.type = var2.getType();
      this.domain = var2.getDomain();
   }

   public CastSpecification(Expression var1, TypeInfo var2) {
      super(var1, (Expression)null);
      this.type = var2;
   }

   protected Value getValue(SessionLocal var1, Value var2, Value var3) {
      if (var3 != null) {
         var2 = this.getValueWithTemplate(var2, var3, var1);
      }

      var2 = var2.castTo(this.type, var1);
      if (this.domain != null) {
         this.domain.checkConstraints(var1, var2);
      }

      return var2;
   }

   private Value getValueWithTemplate(Value var1, Value var2, SessionLocal var3) {
      if (var1 == ValueNull.INSTANCE) {
         return ValueNull.INSTANCE;
      } else {
         int var4 = var1.getValueType();
         if (DataType.isDateTimeType(var4)) {
            if (DataType.isCharacterStringType(this.type.getValueType())) {
               return ValueVarchar.get(DateTimeTemplate.of(var2.getString()).format(var1), var3);
            }
         } else if (DataType.isCharacterStringType(var4) && DataType.isDateTimeType(this.type.getValueType())) {
            return DateTimeTemplate.of(var2.getString()).parse(var1.getString(), this.type, var3);
         }

         throw DbException.getUnsupportedException(this.type.getSQL(var1.getType().getSQL(new StringBuilder("CAST with template from "), 3).append(" to "), 0).toString());
      }
   }

   public Expression optimize(SessionLocal var1) {
      this.left = this.left.optimize(var1);
      if (this.right != null) {
         this.right = this.right.optimize(var1);
      }

      if (this.left.isConstant() && (this.right == null || this.right.isConstant())) {
         Value var2 = this.getValue(var1);
         if (var2 == ValueNull.INSTANCE || canOptimizeCast(this.left.getType().getValueType(), this.type.getValueType())) {
            return TypedValueExpression.get(var2, this.type);
         }
      }

      return this;
   }

   public TypeInfo getTypeIfStaticallyKnown(SessionLocal var1) {
      return this.type;
   }

   public boolean isConstant() {
      return this.left instanceof ValueExpression && (this.right == null || this.right.isConstant()) && canOptimizeCast(this.left.getType().getValueType(), this.type.getValueType());
   }

   private static boolean canOptimizeCast(int var0, int var1) {
      switch (var0) {
         case 17:
            if (var1 == 21) {
               return false;
            }
            break;
         case 18:
            switch (var1) {
               case 19:
               case 20:
               case 21:
                  return false;
               default:
                  return true;
            }
         case 19:
            switch (var1) {
               case 18:
               case 20:
               case 21:
                  return false;
               case 19:
               default:
                  return true;
            }
         case 20:
            switch (var1) {
               case 19:
               case 21:
                  return false;
               default:
                  return true;
            }
         case 21:
            switch (var1) {
               case 17:
               case 18:
               case 20:
                  return false;
               case 19:
            }
      }

      return true;
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      var1.append("CAST(");
      this.left.getUnenclosedSQL(var1, this.left instanceof ValueExpression ? var2 | 4 : var2).append(" AS ");
      ((HasSQL)(this.domain != null ? this.domain : this.type)).getSQL(var1, var2);
      if (this.right != null) {
         this.right.getSQL(var1.append(" FORMAT "), var2);
      }

      return var1.append(')');
   }

   public String getName() {
      return "CAST";
   }
}
