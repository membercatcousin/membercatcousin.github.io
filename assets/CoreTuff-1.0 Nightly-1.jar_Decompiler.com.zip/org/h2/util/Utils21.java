package org.h2.util;

public final class Utils21 {
   public static Thread newVirtualThread(Runnable var0) {
      Thread var1 = new Thread(var0);
      var1.setDaemon(true);
      return var1;
   }

   private Utils21() {
   }
}
