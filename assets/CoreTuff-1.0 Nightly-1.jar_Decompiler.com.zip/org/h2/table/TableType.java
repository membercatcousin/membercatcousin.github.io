package org.h2.table;

public enum TableType {
   TABLE_LINK,
   SYSTEM_TABLE,
   TABLE,
   VIEW,
   EXTERNAL_TABLE_ENGINE,
   MATERIALIZED_VIEW;

   public String toString() {
      if (this == EXTERNAL_TABLE_ENGINE) {
         return "EXTERNAL";
      } else if (this == SYSTEM_TABLE) {
         return "SYSTEM TABLE";
      } else if (this == TABLE_LINK) {
         return "TABLE LINK";
      } else {
         return this == MATERIALIZED_VIEW ? "MATERIALIZED VIEW" : super.toString();
      }
   }
}
