package org.h2.index;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import org.h2.command.query.Query;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionColumn;
import org.h2.expression.ExpressionList;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.ValueExpression;
import org.h2.message.DbException;
import org.h2.result.ResultInterface;
import org.h2.result.SortOrder;
import org.h2.table.Column;
import org.h2.table.IndexColumn;
import org.h2.table.TableType;
import org.h2.value.Value;
import org.h2.value.ValueArray;
import org.h2.value.ValueRow;

public class IndexCondition {
   public static final int EQUALITY = 1;
   public static final int START = 2;
   public static final int END = 4;
   public static final int RANGE = 6;
   public static final int ALWAYS_FALSE = 8;
   public static final int SPATIAL_INTERSECTS = 16;
   private final Column column;
   private final Column[] columns;
   private final boolean compoundColumns;
   private final int compareType;
   private final Expression expression;
   private final List<Expression> expressionList;
   private final Query expressionQuery;

   private IndexCondition(int var1, ExpressionColumn var2, Column[] var3, Expression var4, List<Expression> var5, Query var6) {
      this.compareType = var1;
      if (var2 != null) {
         this.column = var2.getColumn();
         this.columns = null;
         this.compoundColumns = false;
      } else if (var3 != null) {
         this.column = null;
         this.columns = var3;
         this.compoundColumns = true;
      } else {
         this.column = null;
         this.columns = null;
         this.compoundColumns = false;
      }

      this.expression = var4;
      this.expressionList = var5;
      this.expressionQuery = var6;
   }

   public static IndexCondition get(int var0, ExpressionColumn var1, Expression var2) {
      return new IndexCondition(var0, var1, (Column[])null, var2, (List)null, (Query)null);
   }

   public static IndexCondition getInList(ExpressionColumn var0, List<Expression> var1) {
      return new IndexCondition(10, var0, (Column[])null, (Expression)null, var1, (Query)null);
   }

   public static IndexCondition getCompoundInList(Column[] var0, List<Expression> var1) {
      return new IndexCondition(10, (ExpressionColumn)null, var0, (Expression)null, var1, (Query)null);
   }

   public static IndexCondition getInArray(ExpressionColumn var0, Expression var1) {
      return new IndexCondition(11, var0, (Column[])null, var1, (List)null, (Query)null);
   }

   public static IndexCondition getInQuery(ExpressionColumn var0, Query var1) {
      assert var1.isInPredicateResult();

      return new IndexCondition(12, var0, (Column[])null, (Expression)null, (List)null, var1);
   }

   public Value getCurrentValue(SessionLocal var1) {
      return this.expression.getValue(var1);
   }

   public Value[] getCurrentValueList(SessionLocal var1, int[] var2) {
      Object var3;
      if (this.compoundColumns) {
         SortOrder var4 = SortOrder.ofSortTypes(var1, var2);
         var3 = (var1x, var2x) -> var4.compare(((ValueRow)var1x).getList(), ((ValueRow)var2x).getList());
      } else {
         var3 = var1;
         if ((var2[0] & 1) != 0) {
            var3 = var1.reversed();
         }
      }

      TreeSet var10 = new TreeSet((Comparator)var3);
      if (this.compareType == 10) {
         if (this.compoundColumns) {
            Column[] var5 = this.getColumns();

            for(Expression var7 : this.expressionList) {
               ValueRow var8 = (ValueRow)var7.getValue(var1);
               var8 = Column.convert(var1, var5, var8);
               var10.add(var8);
            }
         } else {
            Column var11 = this.getColumn();

            for(Expression var15 : this.expressionList) {
               Value var18 = var15.getValue(var1);
               var18 = var11.convert(var1, var18);
               var10.add(var18);
            }
         }
      } else {
         if (this.compareType != 11) {
            throw DbException.getInternalError("compareType = " + this.compareType);
         }

         Value var12 = this.expression.getValue(var1);
         if (var12 instanceof ValueArray) {
            for(Value var9 : ((ValueArray)var12).getList()) {
               var10.add(var9);
            }
         }
      }

      return (Value[])var10.toArray(new Value[var10.size()]);
   }

   public ResultInterface getCurrentResult(SessionLocal var1, int[] var2) {
      this.expressionQuery.setInPredicateResultSortTypes(var2);
      return this.expressionQuery.query(0L);
   }

   public String getSQL(int var1) {
      if (this.compareType == 9) {
         return "FALSE";
      } else {
         StringBuilder var2 = new StringBuilder();
         var2 = this.isCompoundColumns() ? this.buildSql(var1, var2) : this.buildSql(var1, this.getColumn(), var2);
         return var2.toString();
      }
   }

   private StringBuilder buildSql(int var1, StringBuilder var2) {
      if (this.compareType == 10) {
         var2.append(" IN(");
         int var3 = 0;

         for(int var4 = this.expressionList.size(); var3 < var4; ++var3) {
            if (var3 > 0) {
               var2.append(", ");
            }

            var2.append(((Expression)this.expressionList.get(var3)).getSQL(var1));
         }

         return var2.append(')');
      } else {
         throw DbException.getInternalError("Multiple columns can only be used with compound IN lists.");
      }
   }

   private StringBuilder buildSql(int var1, Column var2, StringBuilder var3) {
      var2.getSQL(var3, var1);
      switch (this.compareType) {
         case 0:
            var3.append(" = ");
            break;
         case 1:
         case 7:
         case 9:
         default:
            throw DbException.getInternalError("type=" + this.compareType);
         case 2:
            var3.append(" < ");
            break;
         case 3:
            var3.append(" > ");
            break;
         case 4:
            var3.append(" <= ");
            break;
         case 5:
            var3.append(" >= ");
            break;
         case 6:
            var3.append(!this.expression.isNullConstant() && (var2.getType().getValueType() != 8 || !this.expression.isConstant()) ? " IS NOT DISTINCT FROM " : " IS ");
            break;
         case 8:
            var3.append(" && ");
            break;
         case 10:
            Expression.writeExpressions(var3.append(" IN("), this.expressionList, var1).append(')');
            break;
         case 11:
            return this.expression.getSQL(var3.append(" = ANY("), var1, 0).append(')');
         case 12:
            var3.append(" IN(");
            this.expressionQuery.getPlanSQL(var3, var1);
            var3.append(')');
      }

      if (this.expression != null) {
         this.expression.getSQL(var3, var1, 0);
      }

      return var3;
   }

   public int getMask(ArrayList<IndexCondition> var1) {
      switch (this.compareType) {
         case 0:
         case 6:
            return 1;
         case 1:
         case 7:
         default:
            throw DbException.getInternalError("type=" + this.compareType);
         case 2:
         case 4:
            return 4;
         case 3:
         case 5:
            return 2;
         case 8:
            return 16;
         case 9:
            return 8;
         case 10:
         case 11:
         case 12:
            if (var1.size() > 1) {
               if (this.isCompoundColumns()) {
                  Column[] var2 = this.getColumns();
                  int var3 = var2.length;

                  while(true) {
                     --var3;
                     if (var3 < 0) {
                        break;
                     }

                     if (TableType.TABLE != var2[var3].getTable().getTableType()) {
                        return 0;
                     }
                  }
               } else if (TableType.TABLE != this.getColumn().getTable().getTableType()) {
                  return 0;
               }
            }

            return 1;
      }
   }

   public boolean isAlwaysFalse() {
      return this.compareType == 9;
   }

   public boolean isStart() {
      switch (this.compareType) {
         case 0:
         case 3:
         case 5:
         case 6:
            return true;
         case 1:
         case 2:
         case 4:
         default:
            return false;
      }
   }

   public boolean isEnd() {
      switch (this.compareType) {
         case 0:
         case 2:
         case 4:
         case 6:
            return true;
         case 1:
         case 3:
         case 5:
         default:
            return false;
      }
   }

   public boolean isSpatialIntersects() {
      switch (this.compareType) {
         case 8:
            return true;
         default:
            return false;
      }
   }

   public int getCompareType() {
      return this.compareType;
   }

   public Column getColumn() {
      if (!this.isCompoundColumns()) {
         return this.column;
      } else {
         throw DbException.getInternalError("The getColumn() method cannot be with multiple columns.");
      }
   }

   public Column[] getColumns() {
      if (this.isCompoundColumns()) {
         return this.columns;
      } else {
         throw DbException.getInternalError("The getColumns() method cannot be with a single column.");
      }
   }

   public boolean isCompoundColumns() {
      return this.compoundColumns;
   }

   public Expression getExpression() {
      return this.expression;
   }

   public List<Expression> getExpressionList() {
      return this.expressionList;
   }

   public Query getExpressionQuery() {
      return this.expressionQuery;
   }

   public boolean isEvaluatable() {
      if (this.expression != null) {
         return this.expression.isEverything(ExpressionVisitor.EVALUATABLE_VISITOR);
      } else if (this.expressionList != null) {
         for(Expression var2 : this.expressionList) {
            if (!var2.isEverything(ExpressionVisitor.EVALUATABLE_VISITOR)) {
               return false;
            }
         }

         return true;
      } else {
         return this.expressionQuery.isEverything(ExpressionVisitor.EVALUATABLE_VISITOR);
      }
   }

   public IndexCondition cloneWithIndexColumns(Index var1) {
      if (!this.isCompoundColumns()) {
         throw DbException.getInternalError("The cloneWithColumns() method cannot be with a single column.");
      } else {
         IndexColumn[] var2 = var1.getIndexColumns();
         int var3 = var2.length;
         if (var3 != this.columns.length) {
            return null;
         } else {
            int[] var4 = new int[var3];
            int var5 = 0;

            for(int var6 = 0; var6 < var3; ++var6) {
               if (var2[var6] == null || var2[var6].column == null) {
                  return null;
               }

               for(int var7 = 0; var7 < this.columns.length; ++var7) {
                  if (this.columns[var7] == var2[var6].column) {
                     var4[var7] = var6;
                     ++var5;
                  }
               }
            }

            if (var5 != var3) {
               return null;
            } else {
               Column[] var13 = new Column[var3];

               for(int var14 = 0; var14 < var3; ++var14) {
                  var13[var14] = this.columns[var4[var14]];
               }

               ArrayList var15 = new ArrayList(var3);

               for(Expression var9 : this.expressionList) {
                  if (var9 instanceof ValueExpression) {
                     ValueExpression var10 = (ValueExpression)var9;
                     ValueRow var11 = (ValueRow)var10.getValue((SessionLocal)null);
                     ValueRow var12 = var11.cloneWithOrder(var4);
                     var15.add(ValueExpression.get(var12));
                  } else {
                     if (!(var9 instanceof ExpressionList)) {
                        throw DbException.getInternalError("Unexpected expression type: " + var9.getClass());
                     }

                     ExpressionList var16 = (ExpressionList)var9;
                     ExpressionList var17 = var16.cloneWithOrder(var4);
                     var15.add(var17);
                  }
               }

               return new IndexCondition(10, (ExpressionColumn)null, var13, (Expression)null, var15, (Query)null);
            }
         }
      }
   }

   public String toString() {
      StringBuilder var1 = new StringBuilder();
      if (!this.isCompoundColumns()) {
         var1.append("column=").append(this.column);
      } else {
         var1.append("columns=");
         Column.writeColumns(var1, this.columns, 3);
      }

      var1.append(", compareType=");
      return compareTypeToString(var1, this.compareType).append(", expression=").append(this.expression).append(", expressionList=").append(this.expressionList).append(", expressionQuery=").append(this.expressionQuery).toString();
   }

   private static StringBuilder compareTypeToString(StringBuilder var0, int var1) {
      boolean var2 = false;
      if ((var1 & 1) == 1) {
         var2 = true;
         var0.append("EQUALITY");
      }

      if ((var1 & 2) == 2) {
         if (var2) {
            var0.append(", ");
         }

         var2 = true;
         var0.append("START");
      }

      if ((var1 & 4) == 4) {
         if (var2) {
            var0.append(", ");
         }

         var2 = true;
         var0.append("END");
      }

      if ((var1 & 8) == 8) {
         if (var2) {
            var0.append(", ");
         }

         var2 = true;
         var0.append("ALWAYS_FALSE");
      }

      if ((var1 & 16) == 16) {
         if (var2) {
            var0.append(", ");
         }

         var0.append("SPATIAL_INTERSECTS");
      }

      return var0;
   }
}
