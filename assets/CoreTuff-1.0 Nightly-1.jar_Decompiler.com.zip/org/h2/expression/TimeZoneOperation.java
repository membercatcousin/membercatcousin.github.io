package org.h2.expression;

import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.util.DateTimeUtils;
import org.h2.util.TimeZoneProvider;
import org.h2.value.DataType;
import org.h2.value.ExtTypeInfo;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueInterval;
import org.h2.value.ValueNull;
import org.h2.value.ValueTimeTimeZone;
import org.h2.value.ValueTimestampTimeZone;

public final class TimeZoneOperation extends Operation1_2 {
   public TimeZoneOperation(Expression var1, Expression var2) {
      super(var1, var2);
   }

   public StringBuilder getUnenclosedSQL(StringBuilder var1, int var2) {
      this.left.getSQL(var1, var2, 0).append(" AT ");
      if (this.right != null) {
         this.right.getSQL(var1.append("TIME ZONE "), var2, 0);
      } else {
         var1.append("LOCAL");
      }

      return var1;
   }

   public Value getValue(SessionLocal var1) {
      Value var2 = this.left.getValue(var1);
      Object var3 = var2.convertTo(this.type, var1);
      if (var3 == ValueNull.INSTANCE) {
         return ValueNull.INSTANCE;
      } else {
         Value var4;
         if (this.right == null) {
            int var5 = var2.getValueType();
            if (var5 == 18 || var5 == 20) {
               return (Value)var3;
            }

            var4 = null;
         } else {
            var4 = this.right.getValue(var1);
            if (var4 == ValueNull.INSTANCE) {
               return ValueNull.INSTANCE;
            }
         }

         if (((Value)var3).getValueType() == 21) {
            ValueTimestampTimeZone var12 = (ValueTimestampTimeZone)var3;
            long var6 = var12.getDateValue();
            long var8 = var12.getTimeNanos();
            int var10 = var12.getTimeZoneOffsetSeconds();
            int var11 = var4 != null ? parseTimeZone(var4, var6, var8, var10, true) : var1.currentTimeZone().getTimeZoneOffsetUTC(DateTimeUtils.getEpochSeconds(var6, var8, var10));
            if (var10 != var11) {
               var3 = DateTimeUtils.timestampTimeZoneAtOffset(var6, var8, var10, var11);
            }
         } else {
            ValueTimeTimeZone var13 = (ValueTimeTimeZone)var3;
            long var14 = var13.getNanos();
            int var16 = var13.getTimeZoneOffsetSeconds();
            int var9 = var4 != null ? parseTimeZone(var4, 1008673L, var14, var16, false) : var1.currentTimeZone().getTimeZoneOffsetUTC(DateTimeUtils.getEpochSeconds(var1.currentTimestamp().getDateValue(), var14, var16));
            if (var16 != var9) {
               var14 += (long)(var9 - var16) * 1000000000L;
               var3 = ValueTimeTimeZone.fromNanos(DateTimeUtils.normalizeNanosOfDay(var14), var9);
            }
         }

         return (Value)var3;
      }
   }

   private static int parseTimeZone(Value var0, long var1, long var3, int var5, boolean var6) {
      if (DataType.isCharacterStringType(var0.getValueType())) {
         TimeZoneProvider var7;
         try {
            var7 = TimeZoneProvider.ofId(var0.getString());
         } catch (RuntimeException var9) {
            throw DbException.getInvalidValueException("time zone", var0.getTraceSQL());
         }

         if (!var6 && !var7.hasFixedOffset()) {
            throw DbException.getInvalidValueException("time zone", var0.getTraceSQL());
         } else {
            return var7.getTimeZoneOffsetUTC(DateTimeUtils.getEpochSeconds(var1, var3, var5));
         }
      } else {
         return parseInterval(var0);
      }
   }

   public static int parseInterval(Value var0) {
      ValueInterval var1 = (ValueInterval)var0.convertTo(TypeInfo.TYPE_INTERVAL_HOUR_TO_SECOND);
      long var2 = var1.getLeading();
      long var4 = var1.getRemaining();
      if (var2 <= 18L && (var2 != 18L || var4 == 0L) && var4 % 1000000000L == 0L) {
         int var6 = (int)(var2 * 3600L + var4 / 1000000000L);
         if (var1.isNegative()) {
            var6 = -var6;
         }

         return var6;
      } else {
         throw DbException.getInvalidValueException("time zone", var1.getTraceSQL());
      }
   }

   public Expression optimize(SessionLocal var1) {
      this.left = this.left.optimize(var1);
      if (this.right != null) {
         this.right = this.right.optimize(var1);
      }

      TypeInfo var2 = this.left.getType();
      byte var3 = 21;
      int var4 = 9;
      int var5 = var2.getValueType();
      switch (var5) {
         case 18:
         case 19:
            var3 = 19;
            var4 = var2.getScale();
            break;
         case 20:
         case 21:
            var4 = var2.getScale();
            break;
         default:
            StringBuilder var6 = this.left.getSQL(new StringBuilder(), 3, 0);
            int var7 = var6.length();
            var6.append(" AT ");
            if (this.right != null) {
               this.right.getSQL(var6.append("TIME ZONE "), 3, 0);
            } else {
               var6.append("LOCAL");
            }

            throw DbException.getSyntaxError(var6.toString(), var7, "time, timestamp");
      }

      this.type = TypeInfo.getTypeInfo(var3, -1L, var4, (ExtTypeInfo)null);
      return (Expression)(this.left.isConstant() && (var5 == 19 || var5 == 21) && this.right != null && this.right.isConstant() ? ValueExpression.get(this.getValue(var1)) : this);
   }

   public boolean isEverything(ExpressionVisitor var1) {
      if (var1.getType() == 2) {
         if (this.right == null) {
            return false;
         }

         int var2 = this.left.getType().getValueType();
         if (var2 == 18 || var2 == 20) {
            return false;
         }
      }

      return this.left.isEverything(var1) && (this.right == null || this.right.isEverything(var1));
   }
}
