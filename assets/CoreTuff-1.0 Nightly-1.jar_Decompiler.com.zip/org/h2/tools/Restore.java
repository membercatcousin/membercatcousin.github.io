package org.h2.tools;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.h2.message.DbException;
import org.h2.store.fs.FileUtils;
import org.h2.util.IOUtils;
import org.h2.util.Tool;

public class Restore extends Tool {
   public static void main(String... var0) throws SQLException {
      (new Restore()).runTool(var0);
   }

   public void runTool(String... var1) throws SQLException {
      String var2 = "backup.zip";
      String var3 = ".";
      String var4 = null;

      for(int var5 = 0; var1 != null && var5 < var1.length; ++var5) {
         String var6 = var1[var5];
         if (var6.equals("-dir")) {
            ++var5;
            var3 = var1[var5];
         } else if (var6.equals("-file")) {
            ++var5;
            var2 = var1[var5];
         } else if (var6.equals("-db")) {
            ++var5;
            var4 = var1[var5];
         } else if (!var6.equals("-quiet")) {
            if (var6.equals("-help") || var6.equals("-?")) {
               this.showUsage();
               return;
            }

            this.showUsageAndThrowUnsupportedOption(var6);
         }
      }

      execute(var2, var3, var4);
   }

   private static String getOriginalDbName(String var0, String var1) throws IOException {
      InputStream var2 = FileUtils.newInputStream(var0);

      String var11;
      try {
         ZipInputStream var3 = new ZipInputStream(var2);
         String var4 = null;
         boolean var5 = false;

         while(true) {
            ZipEntry var6 = var3.getNextEntry();
            if (var6 == null) {
               break;
            }

            String var7 = var6.getName();
            var3.closeEntry();
            String var8 = getDatabaseNameFromFileName(var7);
            if (var8 != null) {
               if (var1.equals(var8)) {
                  var4 = var8;
                  break;
               }

               if (var4 == null) {
                  var4 = var8;
               } else {
                  var5 = true;
               }
            }
         }

         var3.close();
         if (var5 && !var1.equals(var4)) {
            throw new IOException("Multiple databases found, but not " + var1);
         }

         var11 = var4;
      } catch (Throwable var10) {
         if (var2 != null) {
            try {
               var2.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }
         }

         throw var10;
      }

      if (var2 != null) {
         var2.close();
      }

      return var11;
   }

   private static String getDatabaseNameFromFileName(String var0) {
      return var0.endsWith(".mv.db") ? var0.substring(0, var0.length() - ".mv.db".length()) : null;
   }

   public static void execute(String var0, String var1, String var2) {
      InputStream var3 = null;

      try {
         if (!FileUtils.exists(var0)) {
            throw new IOException("File not found: " + var0);
         }

         String var4 = null;
         int var5 = 0;
         if (var2 != null) {
            var4 = getOriginalDbName(var0, var2);
            if (var4 == null) {
               throw new IOException("No database named " + var2 + " found");
            }

            if (var4.startsWith(File.separator)) {
               var4 = var4.substring(1);
            }

            var5 = var4.length();
         }

         var3 = FileUtils.newInputStream(var0);
         ZipInputStream var6 = new ZipInputStream(var3);

         try {
            while(true) {
               ZipEntry var7 = var6.getNextEntry();
               if (var7 == null) {
                  var6.closeEntry();
                  break;
               }

               String var8 = var7.getName();
               var8 = IOUtils.nameSeparatorsToNative(var8);
               if (var8.startsWith(File.separator)) {
                  var8 = var8.substring(1);
               }

               boolean var9 = false;
               if (var2 == null) {
                  var9 = true;
               } else if (var8.startsWith(var4 + ".")) {
                  var8 = var2 + var8.substring(var5);
                  var9 = true;
               }

               if (var9) {
                  OutputStream var10 = null;

                  try {
                     var10 = FileUtils.newOutputStream(var1 + File.separatorChar + var8, false);
                     IOUtils.copy((InputStream)var6, var10);
                     var10.close();
                  } finally {
                     IOUtils.closeSilently(var10);
                  }
               }

               var6.closeEntry();
            }
         } catch (Throwable var25) {
            try {
               var6.close();
            } catch (Throwable var23) {
               var25.addSuppressed(var23);
            }

            throw var25;
         }

         var6.close();
      } catch (IOException var26) {
         throw DbException.convertIOException(var26, var0);
      } finally {
         IOUtils.closeSilently(var3);
      }

   }
}
