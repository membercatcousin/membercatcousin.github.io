package org.h2.expression.function;

import java.math.BigInteger;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.TypedValueExpression;
import org.h2.message.DbException;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueNull;
import org.h2.value.ValueNumeric;

public class GCDFunction extends FunctionN {
   public static final int GCD = 0;
   public static final int LCM = 1;
   private static final String[] NAMES = new String[]{"GCD", "LCM"};
   public static final int MAX_BIT_LENGTH = (int)Math.ceil((double)100000.0F / Math.log10((double)2.0F));
   private final int function;

   public GCDFunction(int var1) {
      super(new Expression[2]);
      this.function = var1;
      this.type = TypeInfo.TYPE_NUMERIC_SCALE_0;
   }

   public Value getValue(SessionLocal var1) {
      Value var2 = this.args[0].getValue(var1);
      if (var2 == ValueNull.INSTANCE) {
         return ValueNull.INSTANCE;
      } else {
         Value var3 = this.args[1].getValue(var1);
         if (var3 == ValueNull.INSTANCE) {
            return ValueNull.INSTANCE;
         } else {
            BigInteger var4 = var2.getBigInteger();
            BigInteger var5 = var3.getBigInteger();
            switch (this.function) {
               case 0:
                  return this.gcd(var1, var4, var5);
               case 1:
                  return this.lcm(var1, var4, var5);
               default:
                  throw DbException.getInternalError("function=" + this.function);
            }
         }
      }
   }

   private Value gcd(SessionLocal var1, BigInteger var2, BigInteger var3) {
      var2 = var2.gcd(var3);
      int var4 = this.args.length;
      if (var4 > 2) {
         boolean var5 = var2.equals(BigInteger.ONE);

         for(int var6 = 2; var6 < var4; ++var6) {
            Value var7 = this.args[var6].getValue(var1);
            if (var7 == ValueNull.INSTANCE) {
               return ValueNull.INSTANCE;
            }

            if (!var5) {
               var3 = var7.getBigInteger();
               if (var3.signum() != 0) {
                  var2 = var2.gcd(var3);
                  var5 = var2.equals(BigInteger.ONE);
               }
            }
         }
      }

      return ValueNumeric.get(var2);
   }

   private Value lcm(SessionLocal var1, BigInteger var2, BigInteger var3) {
      boolean var4 = var2.signum() == 0 || var3.signum() == 0;
      var2 = var4 ? BigInteger.ZERO : var2.multiply(var3).abs().divide(var2.gcd(var3));
      int var5 = this.args.length;
      if (var5 > 2) {
         boolean var6 = !var4 && var2.bitLength() > MAX_BIT_LENGTH;

         for(int var7 = 2; var7 < var5; ++var7) {
            Value var8 = this.args[var7].getValue(var1);
            if (var8 == ValueNull.INSTANCE) {
               return ValueNull.INSTANCE;
            }

            if (!var4) {
               var3 = var8.getBigInteger();
               if (var3.signum() == 0) {
                  var2 = BigInteger.ZERO;
                  var4 = true;
                  var6 = false;
               } else if (!var6) {
                  var2 = var2.multiply(var3).abs().divide(var2.gcd(var3));
                  var6 = var2.bitLength() > MAX_BIT_LENGTH;
               }
            }
         }

         if (var6) {
            throw DbException.getValueTooLongException("NUMERIC", "unknown least common multiple", -1L);
         }
      }

      return ValueNumeric.get(var2);
   }

   public Expression optimize(SessionLocal var1) {
      boolean var2 = true;
      boolean var3 = false;
      int var4 = 0;

      for(int var5 = this.args.length; var4 < var5; ++var4) {
         Expression var6 = this.args[var4].optimize(var1);
         var3 |= checkType(var6, this.getName());
         this.args[var4] = var6;
         if (var2 && !var6.isConstant()) {
            var2 = false;
         }
      }

      if (var2) {
         return TypedValueExpression.getTypedIfNull(this.getValue(var1), TypeInfo.TYPE_NUMERIC_SCALE_0);
      } else if (var3) {
         return TypedValueExpression.get(ValueNull.INSTANCE, TypeInfo.TYPE_NUMERIC_SCALE_0);
      } else {
         this.inlineSubexpressions((var1x) -> var1x instanceof GCDFunction && ((GCDFunction)var1x).function == this.function);
         return this;
      }
   }

   public static boolean checkType(Expression var0, String var1) {
      TypeInfo var2 = var0.getType();
      switch (var2.getValueType()) {
         case 0:
            return true;
         case 1:
         case 2:
         case 3:
         case 4:
         case 5:
         case 6:
         case 7:
         case 8:
         default:
            break;
         case 13:
            if (var2.getScale() != 0) {
               break;
            }
         case 9:
         case 10:
         case 11:
         case 12:
            return false;
      }

      throw DbException.getInvalidValueException(var1 + " argument", var0.getTraceSQL());
   }

   public String getName() {
      return NAMES[this.function];
   }
}
