package org.h2.compress;

import java.nio.ByteBuffer;

public final class CompressLZF implements Compressor {
   private static final int HASH_SIZE = 16384;
   private static final int MAX_LITERAL = 32;
   private static final int MAX_OFF = 8192;
   private static final int MAX_REF = 264;
   private int[] cachedHashTable;

   public void setOptions(String var1) {
   }

   private static int first(byte[] var0, int var1) {
      return var0[var1] << 8 | var0[var1 + 1] & 255;
   }

   private static int first(ByteBuffer var0, int var1) {
      return var0.get(var1) << 8 | var0.get(var1 + 1) & 255;
   }

   private static int next(int var0, byte[] var1, int var2) {
      return var0 << 8 | var1[var2 + 2] & 255;
   }

   private static int next(int var0, ByteBuffer var1, int var2) {
      return var0 << 8 | var1.get(var2 + 2) & 255;
   }

   private static int hash(int var0) {
      return var0 * 2777 >> 9 & 16383;
   }

   public int compress(byte[] param1, int param2, int param3, byte[] param4, int param5) {
      // $FF: Couldn't be decompiled
   }

   public int compress(ByteBuffer param1, int param2, byte[] param3, int param4) {
      // $FF: Couldn't be decompiled
   }

   public void expand(byte[] var1, int var2, int var3, byte[] var4, int var5, int var6) {
      if (var2 >= 0 && var5 >= 0 && var6 >= 0) {
         do {
            int var7 = var1[var2++] & 255;
            if (var7 < 32) {
               ++var7;
               System.arraycopy(var1, var2, var4, var5, var7);
               var5 += var7;
               var2 += var7;
            } else {
               int var8 = var7 >> 5;
               if (var8 == 7) {
                  var8 += var1[var2++] & 255;
               }

               var8 += 2;
               var7 = -((var7 & 31) << 8) - 1;
               var7 -= var1[var2++] & 255;
               var7 += var5;
               if (var5 + var8 >= var4.length) {
                  throw new ArrayIndexOutOfBoundsException();
               }

               for(int var9 = 0; var9 < var8; ++var9) {
                  var4[var5++] = var4[var7++];
               }
            }
         } while(var5 < var6);

      } else {
         throw new IllegalArgumentException();
      }
   }

   public static void expand(ByteBuffer var0, ByteBuffer var1) {
      do {
         int var2 = var0.get() & 255;
         if (var2 < 32) {
            ++var2;

            for(int var3 = 0; var3 < var2; ++var3) {
               var1.put(var0.get());
            }
         } else {
            int var9 = var2 >> 5;
            if (var9 == 7) {
               var9 += var0.get() & 255;
            }

            var9 += 2;
            var2 = -((var2 & 31) << 8) - 1;
            var2 -= var0.get() & 255;
            var2 += var1.position();

            for(int var4 = 0; var4 < var9; ++var4) {
               var1.put(var1.get(var2++));
            }
         }
      } while(var1.position() < var1.capacity());

   }

   public int getAlgorithm() {
      return 1;
   }
}
