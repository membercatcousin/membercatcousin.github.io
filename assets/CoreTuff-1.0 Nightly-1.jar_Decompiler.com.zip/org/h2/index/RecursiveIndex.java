package org.h2.index;

import java.util.ArrayList;
import org.h2.command.Parser;
import org.h2.command.query.AllColumnsForPlan;
import org.h2.command.query.Query;
import org.h2.command.query.SelectUnion;
import org.h2.engine.SessionLocal;
import org.h2.expression.Parameter;
import org.h2.message.DbException;
import org.h2.result.LocalResult;
import org.h2.result.ResultInterface;
import org.h2.result.SearchRow;
import org.h2.result.SortOrder;
import org.h2.table.CTE;
import org.h2.table.QueryExpressionTable;
import org.h2.table.TableFilter;
import org.h2.value.Value;

public final class RecursiveIndex extends QueryExpressionIndex {
   private final SessionLocal createSession;

   public RecursiveIndex(QueryExpressionTable var1, String var2, ArrayList<Parameter> var3, SessionLocal var4) {
      super(var1, var2, var3);
      this.createSession = var4;
   }

   public boolean isExpired() {
      return false;
   }

   public double getCost(SessionLocal var1, int[] var2, TableFilter[] var3, int var4, SortOrder var5, AllColumnsForPlan var6, boolean var7) {
      return (double)1000.0F;
   }

   public Cursor find(SessionLocal var1, SearchRow var2, SearchRow var3, boolean var4) {
      assert !var4;

      CTE var5 = (CTE)this.table;
      ResultInterface var6 = var5.getRecursiveResult();
      if (var6 != null) {
         var6.reset();
         return new QueryExpressionCursor(this, var6, var2, var3);
      } else {
         if (this.query == null) {
            Parser var7 = new Parser(this.createSession);
            var7.setRightsChecked(true);
            var7.setSuppliedParameters(this.originalParameters);
            var7.setQueryScope(this.table.getQueryScope());
            this.query = (Query)var7.prepare(this.querySQL);
            this.query.setNeverLazy(true);
         }

         if (!this.query.isUnion()) {
            throw DbException.get(42001, (String)"recursive queries without UNION");
         } else {
            SelectUnion var13 = (SelectUnion)this.query;
            Query var8 = var13.getLeft();
            var8.setNeverLazy(true);
            var8.disableCache();
            ResultInterface var9 = var8.query(0L);
            LocalResult var10 = var13.getEmptyResult();
            var10.setMaxMemoryRows(Integer.MAX_VALUE);

            while(var9.next()) {
               Value[] var11 = var9.currentRow();
               var10.addRow(var11);
            }

            Query var15 = var13.getRight();
            var15.setNeverLazy(true);
            var9.reset();
            var5.setRecursiveResult(var9);
            var15.disableCache();

            while(true) {
               var9 = var15.query(0L);
               if (!var9.hasNext()) {
                  var5.setRecursiveResult((ResultInterface)null);
                  var10.done();
                  return new QueryExpressionCursor(this, var10, var2, var3);
               }

               while(var9.next()) {
                  Value[] var12 = var9.currentRow();
                  var10.addRow(var12);
               }

               var9.reset();
               var5.setRecursiveResult(var9);
            }
         }
      }
   }
}
