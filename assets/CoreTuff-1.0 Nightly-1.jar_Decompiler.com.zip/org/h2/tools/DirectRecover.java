package org.h2.tools;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.h2.message.DbException;
import org.h2.mvstore.MVStore;
import org.h2.mvstore.MVStoreTool;
import org.h2.mvstore.db.ValueDataType;
import org.h2.mvstore.tx.TransactionMap;
import org.h2.mvstore.tx.TransactionStore;
import org.h2.result.Row;
import org.h2.store.FileLister;
import org.h2.store.fs.FileUtils;
import org.h2.value.Value;
import org.h2.value.ValueCollectionBase;

public class DirectRecover extends Recover {
   private ExecutorService kanziExecutor = null;
   private CompressionType compressionType;
   private boolean debugMode;
   private boolean showProgress;

   public DirectRecover() {
      this.compressionType = CompressionType.NONE;
      this.debugMode = false;
      this.showProgress = true;
   }

   public static void main(String... var0) throws SQLException {
      (new DirectRecover()).runTool(var0);
   }

   public void runTool(String... var1) throws SQLException {
      String var2 = ".";
      String var3 = null;
      boolean var4 = false;

      for(int var5 = 0; var1 != null && var5 < var1.length; ++var5) {
         String var6 = var1[var5];
         if ("-dir".equals(var6)) {
            ++var5;
            var2 = var1[var5];
         } else if ("-db".equals(var6)) {
            ++var5;
            var3 = var1[var5];
         } else if ("-trace".equals(var6)) {
            var4 = true;
            this.debugMode = true;
            this.showProgress = false;
         } else if ("-compress".equals(var6)) {
            ++var5;
            String var7 = var1[var5].toUpperCase();

            try {
               this.compressionType = CompressionType.valueOf(var7);
            } catch (IllegalArgumentException var9) {
               throw new SQLException("Invalid compression type: " + var7 + ". Valid options: none, gzip, zip, bzip2, kanzi");
            }
         } else {
            if (var6.equals("-help") || var6.equals("-?")) {
               this.showUsage();
               return;
            }

            this.showUsageAndThrowUnsupportedOption(var6);
         }
      }

      super.trace = var4;
      if (this.compressionType != CompressionType.NONE && !this.isCompressionAvailable(this.compressionType)) {
         System.err.println("WARNING: " + this.compressionType + " compression library not found in classpath.");
         System.err.println("Falling back to uncompressed output (.sql files).");
         if (this.compressionType == CompressionType.BZIP2) {
            System.err.println("To enable BZIP2: Add commons-compress.jar to classpath");
            System.err.println("Download from: https://commons.apache.org/proper/commons-compress/");
         } else if (this.compressionType == CompressionType.KANZI) {
            System.err.println("To enable KANZI: Add kanzi.jar to classpath");
            System.err.println("Download from: https://github.com/flanglet/kanzi-java");
         }

         System.err.println();
      }

      this.debug("Starting DirectRecover with compression: " + this.compressionType);
      this.processWithPipe(var2, var3);
      this.debug("DirectRecover completed successfully");
   }

   private void debug(String var1) {
      if (this.debugMode) {
         System.out.println("[DEBUG] " + var1 + " [Thread: " + Thread.currentThread().getName() + "]");
         System.out.flush();
      }

   }

   private void processWithPipe(String var1, String var2) {
      ArrayList var3 = FileLister.getDatabaseFiles(var1, var2, true);
      if (var3.isEmpty()) {
         this.printNoDatabaseFilesFound(var1, var2);
      } else {
         this.debug("Found " + var3.size() + " database files to process");
         ExecutorService var4 = Executors.newFixedThreadPool(2);

         try {
            for(String var6 : var3) {
               if (var6.endsWith(".mv.db")) {
                  this.debug("Processing file: " + var6);
                  String var7 = var6.substring(0, var6.length() - ".mv.db".length());
                  ProgressBar var8 = null;
                  if (this.showProgress) {
                     String var9 = (new File(var6)).getName();
                     var8 = new ProgressBar("Processing " + var9, 50);
                  }

                  PipedWriter var51 = null;
                  PipedReader var10 = null;

                  try {
                     this.debug("Creating pipes for: " + var6);
                     var51 = new PipedWriter();
                     var10 = new PipedReader(var51, 262144);
                     this.debug("Starting dump task for: " + var6);
                     CompletableFuture var14 = CompletableFuture.runAsync(() -> {
                        this.debug("DUMP TASK: Starting dump for " + var6);

                        try {
                           PrintWriter var3 = new PrintWriter(var51);

                           try {
                              this.debug("DUMP TASK: Created writer, starting MVStoreTool.dump");
                              MVStoreTool.dump(var6, var3, true);
                              this.debug("DUMP TASK: MVStoreTool.dump completed, starting info");
                              MVStoreTool.info(var6, var3);
                              this.debug("DUMP TASK: MVStoreTool.info completed, flushing");
                              var3.flush();
                              this.debug("DUMP TASK: Flush completed, dump task finishing");
                           } catch (Throwable var7) {
                              try {
                                 var3.close();
                              } catch (Throwable var6x) {
                                 var7.addSuppressed(var6x);
                              }

                              throw var7;
                           }

                           var3.close();
                        } catch (Exception var8) {
                           this.debug("DUMP TASK: Error - " + var8.getMessage());
                           this.trace("Error in dump task: " + var8.getMessage());
                        }

                        this.debug("DUMP TASK: Dump task completed for " + var6);
                     }, var4);
                     this.debug("Starting SQL task for: " + var6);
                     CompletableFuture var15 = CompletableFuture.runAsync(() -> {
                        this.debug("SQL TASK: Starting SQL conversion for " + var6);

                        try {
                           PrintWriter var5 = this.getCompressedWriter(var7 + ".h2.db");

                           try {
                              this.debug("SQL TASK: Created compressed writer, starting processPipedDumpToSQL");
                              this.processPipedDumpToSQL(var10, var5, var6, var8);
                              this.debug("SQL TASK: processPipedDumpToSQL completed, flushing");
                              var5.flush();
                              this.debug("SQL TASK: Flush completed, SQL task finishing");
                           } catch (Throwable var9) {
                              if (var5 != null) {
                                 try {
                                    var5.close();
                                 } catch (Throwable var8x) {
                                    var9.addSuppressed(var8x);
                                 }
                              }

                              throw var9;
                           }

                           if (var5 != null) {
                              var5.close();
                           }
                        } catch (Exception var10x) {
                           this.debug("SQL TASK: Error - " + var10x.getMessage());
                           this.trace("Error in SQL conversion task: " + var10x.getMessage());
                        }

                        this.debug("SQL TASK: SQL task completed for " + var6);
                     }, var4);
                     this.debug("Waiting for both tasks to complete for: " + var6);

                     try {
                        CompletableFuture.allOf(var14, var15).get(1L, TimeUnit.DAYS);
                        this.debug("Both tasks completed successfully for: " + var6);
                        if (var8 != null) {
                           var8.finish();
                        }
                     } catch (TimeoutException var47) {
                        this.debug("TIMEOUT: Processing timed out 1 day for: " + var6);
                        this.trace("Processing timed out after 1 day");
                        var14.cancel(true);
                        var15.cancel(true);
                        if (var8 != null) {
                           var8.finish();
                        }
                     }
                  } catch (Exception var48) {
                     this.debug("ERROR: Exception processing " + var6 + ": " + var48.getMessage());
                     this.traceError("Error processing " + var6, var48);
                  } finally {
                     this.debug("Cleaning up pipes for: " + var6);
                     if (var51 != null) {
                        try {
                           var51.close();
                           this.debug("PipeWriter closed for: " + var6);
                        } catch (Exception var46) {
                           this.debug("Error closing PipeWriter: " + var46.getMessage());
                        }
                     }

                     if (var10 != null) {
                        try {
                           var10.close();
                           this.debug("PipeReader closed for: " + var6);
                        } catch (Exception var45) {
                           this.debug("Error closing PipeReader: " + var45.getMessage());
                        }
                     }

                     this.debug("Pipe cleanup completed for: " + var6);
                  }
               }
            }
         } finally {
            this.debug("Shutting down executor");
            var4.shutdown();

            try {
               this.debug("Waiting for executor termination (30 seconds)");
               if (!var4.awaitTermination(30L, TimeUnit.SECONDS)) {
                  this.debug("Executor did not terminate gracefully, forcing shutdown");
                  this.trace("Executor did not terminate gracefully, forcing shutdown");
                  var4.shutdownNow();
                  if (!var4.awaitTermination(10L, TimeUnit.SECONDS)) {
                     this.debug("Executor did not terminate after force shutdown");
                     System.err.println("Executor did not terminate");
                  } else {
                     this.debug("Executor terminated after force shutdown");
                  }
               } else {
                  this.debug("Executor terminated gracefully");
               }
            } catch (InterruptedException var44) {
               this.debug("Interrupted while waiting for executor termination");
               var4.shutdownNow();
               Thread.currentThread().interrupt();
            }

            this.debug("Executor shutdown completed");
         }

      }
   }

   private PrintWriter getCompressedWriter(String var1) {
      var1 = var1.substring(0, var1.length() - 3);
      switch (this.compressionType) {
         case GZIP:
            String var17 = var1 + ".sql.gz";
            this.debug("Creating GZIP compressed writer for: " + var17);

            try {
               OutputStream var21 = FileUtils.newOutputStream(var17, false);
               GZIPOutputStream var26 = new GZIPOutputStream(var21);
               this.debug("GZIP writer created successfully: " + var17);
               this.trace("Created compressed file: " + var17);
               return new PrintWriter(new OutputStreamWriter(var26, StandardCharsets.UTF_8));
            } catch (IOException var11) {
               throw DbException.convertIOException(var11, (String)null);
            }
         case ZIP:
            String var16 = var1 + ".sql.zip";
            this.debug("Creating ZIP compressed writer for: " + var16);

            try {
               OutputStream var20 = FileUtils.newOutputStream(var16, false);
               final ZipOutputStream var25 = new ZipOutputStream(var20);
               String var5 = (new File(var1 + ".sql")).getName();
               var25.putNextEntry(new ZipEntry(var5));
               this.debug("ZIP writer created successfully: " + var16);
               this.trace("Created compressed file: " + var16);
               return new PrintWriter(new OutputStreamWriter(var25, StandardCharsets.UTF_8)) {
                  public void close() {
                     try {
                        super.close();
                        var25.closeEntry();
                        var25.close();
                        DirectRecover.this.debug("ZIP writer closed successfully.");
                     } catch (IOException var2) {
                        DirectRecover.this.debug("Error closing ZIP stream: " + var2.getMessage());
                        System.err.println("Error closing ZIP stream: " + var2.getMessage());
                     }

                  }
               };
            } catch (IOException var10) {
               throw DbException.convertIOException(var10, (String)null);
            }
         case BZIP2:
            String var14 = var1 + ".sql.bz2";
            this.debug("Creating BZIP2 compressed writer for: " + var14);

            try {
               OutputStream var19 = FileUtils.newOutputStream(var14, false);
               OutputStream var24 = this.createCompressedStream(CompressionType.BZIP2, var19);
               this.debug("BZIP2 writer created successfully: " + var14);
               this.trace("Created compressed file: " + var14);
               return new PrintWriter(new OutputStreamWriter(var24, StandardCharsets.UTF_8));
            } catch (Exception var9) {
               this.debug("BZIP2 compression not available, falling back: " + var9.getMessage());
               this.trace("BZip2 compression not available: " + var9.getMessage());
               this.trace("Falling back to uncompressed output");
               var14 = var1 + ".sql";
               this.debug("Creating fallback uncompressed writer for: " + var14);
               this.trace("Created fallback file: " + var14);

               try {
                  OutputStream var23 = FileUtils.newOutputStream(var14, false);
                  return new PrintWriter(new OutputStreamWriter(var23, StandardCharsets.UTF_8));
               } catch (IOException var7) {
                  throw DbException.convertIOException(var7, (String)null);
               }
            }
         case KANZI:
            String var2 = var1 + ".sql.knz";
            this.debug("Creating KANZI compressed writer for: " + var2);

            try {
               this.debug("KANZI: Opening output stream for: " + var2);
               OutputStream var3 = FileUtils.newOutputStream(var2, false);
               this.debug("KANZI: Base output stream created successfully");
               this.debug("KANZI: Creating compressed stream...");
               final OutputStream var22 = this.createCompressedStream(CompressionType.KANZI, var3);
               this.debug("KANZI: Compressed stream created successfully");
               this.debug("KANZI writer created successfully: " + var2);
               this.trace("Created compressed file: " + var2);
               return new PrintWriter(new OutputStreamWriter(var22, StandardCharsets.UTF_8)) {
                  public void close() {
                     try {
                        DirectRecover.this.debug("KANZI: Closing PrintWriter");
                        super.close();
                        DirectRecover.this.debug("KANZI: Closing compressed stream");
                        if (DirectRecover.this.kanziExecutor != null) {
                           DirectRecover.this.kanziExecutor.shutdown();
                           DirectRecover.this.kanziExecutor.awaitTermination(1L, TimeUnit.DAYS);
                        }

                        var22.close();
                        DirectRecover.this.debug("KANZI writer closed successfully.");
                     } catch (InterruptedException | IOException var2) {
                        DirectRecover.this.debug("Error closing KANZI stream: " + ((Exception)var2).getMessage());
                        System.err.println("Error closing Kanzi stream: " + ((Exception)var2).getMessage());
                        ((Exception)var2).printStackTrace();
                     }

                  }
               };
            } catch (Exception var8) {
               this.debug("KANZI compression FAILED, falling back: " + var8.getMessage());
               System.err.println("KANZI compression failed: " + var8.getMessage());
               var8.printStackTrace();
               this.trace("Kanzi compression not available: " + var8.getMessage());
               this.trace("Falling back to uncompressed output");
               var2 = var1 + ".sql";
               this.debug("Creating fallback uncompressed writer for: " + var2);
               this.trace("Created fallback file: " + var2);

               try {
                  OutputStream var4 = FileUtils.newOutputStream(var2, false);
                  return new PrintWriter(new OutputStreamWriter(var4, StandardCharsets.UTF_8));
               } catch (IOException var6) {
                  throw DbException.convertIOException(var6, (String)null);
               }
            }
         case NONE:
         default:
            String var18 = var1 + ".sql";
            this.debug("Creating uncompressed writer for: " + var18);
            this.trace("Created file: " + var18);
            return this.getWriter(var1, ".sql");
      }
   }

   private OutputStream createCompressedStream(CompressionType var1, OutputStream var2) throws Exception {
      switch (var1) {
         case BZIP2:
            return CompressTool.createBZip2OutputStream(var2);
         case KANZI:
            int var3 = Runtime.getRuntime().availableProcessors();
            this.kanziExecutor = Executors.newFixedThreadPool(var3);
            return CompressTool.createKanziOutputStream(var2, this.kanziExecutor);
         default:
            return var2;
      }
   }

   private void processPipedDumpToSQL(PipedReader var1, PrintWriter var2, String var3, ProgressBar var4) {
      BufferedReader var5 = null;

      try {
         this.debug("PROCESS: Starting processPipedDumpToSQL for " + var3);
         var5 = new BufferedReader(var1);
         this.debug("PROCESS: Writing SQL header");
         var2.println("-- MVStore");
         String var6 = Recover.class.getName();
         var2.println("CREATE ALIAS IF NOT EXISTS READ_BLOB_MAP FOR '" + var6 + ".readBlobMap';");
         var2.println("CREATE ALIAS IF NOT EXISTS READ_CLOB_MAP FOR '" + var6 + ".readClobMap';");
         this.debug("PROCESS: Resetting schema");
         this.resetSchema();
         this.setDatabaseName(var3.substring(0, var3.length() - ".mv.db".length()));
         this.debug("PROCESS: Starting background SQL generation");
         ExecutorService var7 = Executors.newSingleThreadExecutor();
         CompletableFuture var8 = CompletableFuture.runAsync(() -> {
            this.debug("SQL_GEN: Starting background generateSQLFromMVStore");
            this.generateSQLFromMVStore(var2, var3);
            this.debug("SQL_GEN: Background generateSQLFromMVStore completed");
         }, var7);
         this.debug("PROCESS: Starting parallel dump consumption");
         int var9 = 0;
         long var10 = 1000000L;

         while(var5.readLine() != null) {
            ++var9;
            if (this.debugMode && var9 % 10000 == 0) {
               this.debug("PROCESS: Consumed " + var9 + " dump lines");
            }

            if (var4 != null && var9 % 1000 == 0) {
               long var12 = Math.min((long)var9, var10);
               var4.update(var12, var10);
            }

            if (var9 % 1000 == 0) {
               Thread.yield();
            }
         }

         this.debug("PROCESS: Consumed and discarded total of " + var9 + " dump lines");
         this.debug("PROCESS: Waiting for SQL generation to complete");
         var8.get(1L, TimeUnit.DAYS);
         this.debug("PROCESS: SQL generation completed");
         if (var4 != null) {
            var4.update(var10, var10);
         }

         var7.shutdown();
      } catch (Exception var22) {
         this.debug("PROCESS: Error in processPipedDumpToSQL: " + var22.getMessage());
         this.writeError(var2, var22);
      } finally {
         this.debug("PROCESS: Cleaning up BufferedReader");
         if (var5 != null) {
            try {
               var5.close();
               this.debug("PROCESS: BufferedReader closed");
            } catch (Exception var21) {
               this.debug("PROCESS: Error closing BufferedReader: " + var21.getMessage());
            }
         }

         this.debug("PROCESS: processPipedDumpToSQL completed for " + var3);
      }

   }

   private void generateSQLFromMVStore(PrintWriter var1, String var2) {
      this.debug("GENERATE: Starting generateSQLFromMVStore for " + var2);

      try (MVStore var3 = (new MVStore.Builder()).fileName(var2).recoveryMode().readOnly().open()) {
         this.debug("GENERATE: MVStore opened, dumping LOB maps");
         this.dumpLobMaps(var1, var3);
         var1.println("-- Layout");
         this.debug("GENERATE: Dumping layout");
         dumpLayout(var1, var3);
         var1.println("-- Meta");
         this.debug("GENERATE: Dumping meta");
         dumpMeta(var1, var3);
         var1.println("-- Types");
         this.debug("GENERATE: Dumping types");
         dumpTypes(var1, var3);
         var1.println("-- Tables");
         this.debug("GENERATE: Creating transaction store");
         TransactionStore var4 = new TransactionStore(var3, new ValueDataType());

         try {
            var4.init();
            this.debug("GENERATE: Transaction store initialized");
         } catch (Throwable var19) {
            this.debug("GENERATE: Error initializing transaction store: " + var19.getMessage());
            this.writeError(var1, var19);
         }

         this.debug("GENERATE: Extracting metadata");

         for(String var6 : var3.getMapNames()) {
            if (var6.startsWith("table.")) {
               String var7 = var6.substring("table.".length());
               if (Integer.parseInt(var7) == 0) {
                  TransactionMap var8 = var4.begin().openMap(var6);
                  Iterator var9 = var8.keyIterator((Object)null);

                  while(var9.hasNext()) {
                     Long var10 = (Long)var9.next();
                     Row var11 = (Row)var8.get(var10);

                     try {
                        this.writeMetaRow(var11);
                     } catch (Throwable var18) {
                        this.writeError(var1, var18);
                     }
                  }
               }
            }
         }

         this.debug("GENERATE: Writing schema SET");
         this.writeSchemaSET(var1);
         var1.println("---- Table Data ----");
         this.debug("GENERATE: Processing table data");

         for(String var23 : var3.getMapNames()) {
            if (var23.startsWith("table.")) {
               String var24 = var23.substring("table.".length());
               if (Integer.parseInt(var24) != 0) {
                  TransactionMap var25 = var4.begin().openMap(var23);
                  Iterator var26 = var25.keyIterator((Object)null);
                  boolean var27 = false;

                  while(var26.hasNext()) {
                     Object var28 = var26.next();
                     Object var12 = var25.get(var28);
                     Value[] var13;
                     if (var12 instanceof Row) {
                        var13 = ((Row)var12).getValueList();
                        super.recordLength = var13.length;
                     } else {
                        var13 = ((ValueCollectionBase)var12).getList();
                        super.recordLength = var13.length - 1;
                     }

                     if (!var27) {
                        this.setStorage(Integer.parseInt(var24));
                        StringBuilder var14 = new StringBuilder();

                        for(int var15 = 0; var15 < super.recordLength; ++var15) {
                           String var16 = super.storageName + "." + var15;
                           var14.setLength(0);
                           this.getSQL(var14, var16, var13[var15]);
                        }

                        this.createTemporaryTable(var1);
                        var27 = true;
                     }

                     StringBuilder var29 = new StringBuilder();
                     var29.append("INSERT INTO O_").append(var24).append(" VALUES(");

                     for(int var30 = 0; var30 < super.recordLength; ++var30) {
                        if (var30 > 0) {
                           var29.append(", ");
                        }

                        String var31 = super.storageName + "." + var30;
                        this.getSQL(var29, var31, var13[var30]);
                     }

                     var29.append(");");
                     var1.println(var29);
                  }
               }
            }
         }

         this.debug("GENERATE: Writing schema");
         this.writeSchema(var1);
         var1.println("DROP ALIAS READ_BLOB_MAP;");
         var1.println("DROP ALIAS READ_CLOB_MAP;");
         var1.println("DROP TABLE IF EXISTS INFORMATION_SCHEMA.LOB_BLOCKS;");
         this.debug("GENERATE: generateSQLFromMVStore completed successfully");
      } catch (Throwable var21) {
         this.debug("GENERATE: Error in generateSQLFromMVStore: " + var21.getMessage());
         this.writeError(var1, var21);
      }

   }

   public boolean isCompressionAvailable(CompressionType var1) {
      switch (var1) {
         case GZIP:
         case ZIP:
         case NONE:
            return true;
         case BZIP2:
            try {
               Class.forName("org.apache.commons.compress.compressors.bzip2.BZip2CompressorOutputStream");
               return true;
            } catch (ClassNotFoundException var4) {
               return false;
            }
         case KANZI:
            try {
               Class.forName("io.github.flanglet.kanzi.io.CompressedOutputStream");
               return true;
            } catch (ClassNotFoundException var3) {
               return false;
            }
         default:
            return false;
      }
   }

   public CompressionType[] getAvailableCompressionTypes() {
      ArrayList var1 = new ArrayList();

      for(CompressionType var5 : CompressionType.values()) {
         if (this.isCompressionAvailable(var5)) {
            var1.add(var5);
         }
      }

      return (CompressionType[])var1.toArray(new CompressionType[0]);
   }

   public void setCompressionType(CompressionType var1) {
      this.compressionType = var1;
   }

   public CompressionType getCompressionType() {
      return this.compressionType;
   }

   public static void execute(String var0, String var1, PrintWriter var2) throws SQLException {
      try {
         DirectRecover var3 = new DirectRecover();
         var3.processWithPipe(var0, var1);
      } catch (DbException var4) {
         throw DbException.toSQLException(var4);
      }
   }

   private static class ProgressBar {
      private final int width;
      private final String prefix;
      private long lastUpdate = 0L;
      private int lastProgress = -1;

      public ProgressBar(String var1, int var2) {
         this.prefix = var1;
         this.width = var2;
      }

      public void update(long var1, long var3) {
         long var5 = System.currentTimeMillis();
         if (var5 - this.lastUpdate >= 100L) {
            this.lastUpdate = var5;
            int var7 = var3 > 0L ? (int)(var1 * 100L / var3) : 0;
            if (var7 != this.lastProgress) {
               this.lastProgress = var7;
               int var8 = var7 * this.width / 100;
               StringBuilder var9 = new StringBuilder();
               var9.append('\r').append(this.prefix).append(" [");

               for(int var10 = 0; var10 < this.width; ++var10) {
                  if (var10 < var8) {
                     var9.append('█');
                  } else if (var10 == var8 && var7 < 100) {
                     var9.append('▓');
                  } else {
                     var9.append('░');
                  }
               }

               var9.append(String.format("] %3d%% ", var7));
               System.out.print(var9);
               System.out.flush();
               if (var7 >= 100) {
                  System.out.println();
               }

            }
         }
      }

      public void finish() {
         if (this.lastProgress < 100) {
            System.out.println();
         }

      }
   }
}
