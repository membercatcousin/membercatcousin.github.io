package org.h2.expression.condition;

import java.util.ArrayList;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionColumn;
import org.h2.expression.ExpressionList;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.Parameter;
import org.h2.expression.TypedValueExpression;
import org.h2.expression.ValueExpression;
import org.h2.index.IndexCondition;
import org.h2.table.ColumnResolver;
import org.h2.table.TableFilter;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueBoolean;
import org.h2.value.ValueNull;
import org.h2.value.ValueRow;

public final class ConditionInList extends ConditionIn {
   public ConditionInList(Expression var1, boolean var2, boolean var3, ArrayList<Expression> var4) {
      super(var1, var2, var3, var4);
   }

   Value getValue(SessionLocal var1, Value var2) {
      if (var2.containsNull()) {
         return ValueNull.INSTANCE;
      } else {
         boolean var3 = false;

         for(Expression var5 : this.valueList) {
            Value var6 = var5.getValue(var1);
            Value var7 = Comparison.compare(var1, var2, var6, 0);
            if (var7 == ValueNull.INSTANCE) {
               var3 = true;
            } else if (var7 == ValueBoolean.TRUE) {
               return ValueBoolean.get(!this.not);
            }
         }

         if (var3) {
            return ValueNull.INSTANCE;
         } else {
            return ValueBoolean.get(this.not);
         }
      }
   }

   public void mapColumns(ColumnResolver var1, int var2, int var3) {
      this.left.mapColumns(var1, var2, var3);

      for(Expression var5 : this.valueList) {
         var5.mapColumns(var1, var2, var3);
      }

   }

   public Expression optimize(SessionLocal var1) {
      this.left = this.left.optimize(var1);
      boolean var2 = !this.whenOperand && this.left.isConstant();
      if (var2 && this.left.isNullConstant()) {
         return TypedValueExpression.UNKNOWN;
      } else {
         boolean var3 = true;
         boolean var4 = true;
         TypeInfo var5 = this.left.getType();
         int var6 = 0;

         for(int var7 = this.valueList.size(); var6 < var7; ++var6) {
            Expression var8 = (Expression)this.valueList.get(var6);
            var8 = var8.optimize(var1);
            TypeInfo.checkComparable(var5, var8.getType());
            if (var8.isConstant() && !var8.getValue(var1).containsNull()) {
               var4 = false;
            }

            if (var3 && !var8.isConstant()) {
               var3 = false;
            }

            if (this.left instanceof ExpressionColumn && var8 instanceof Parameter) {
               ((Parameter)var8).setColumn(((ExpressionColumn)this.left).getColumn());
            }

            this.valueList.set(var6, var8);
         }

         return this.optimize2(var1, var2, var3, var4, this.valueList);
      }
   }

   private Expression optimize2(SessionLocal var1, boolean var2, boolean var3, boolean var4, ArrayList<Expression> var5) {
      if (var2 && var3) {
         return ValueExpression.getBoolean(this.getValue(var1));
      } else if (var5.size() == 1) {
         return (new Comparison(this.not ? 1 : 0, this.left, (Expression)var5.get(0), this.whenOperand)).optimize(var1);
      } else if (var3 && !var4) {
         int var6 = this.left.getType().getValueType();
         if (var6 == -1) {
            return this;
         } else {
            return (Expression)(var6 == 36 && !(this.left instanceof ExpressionColumn) ? this : (new ConditionInConstantSet(var1, this.left, this.not, this.whenOperand, var5)).optimize(var1));
         }
      } else {
         return this;
      }
   }

   public Expression getNotIfPossible(SessionLocal var1) {
      return this.whenOperand ? null : new ConditionInList(this.left, !this.not, false, this.valueList);
   }

   void createUniqueIndexConditions(TableFilter var1, ExpressionList var2) {
      int var3 = var2.getSubexpressionCount();

      for(int var4 = 0; var4 < var3; ++var4) {
         Expression var5 = var2.getSubexpression(var4);
         if (var5 instanceof ExpressionColumn) {
            ExpressionColumn var6 = (ExpressionColumn)var5;
            if (var1 == var6.getTableFilter()) {
               ArrayList var7 = new ArrayList(this.valueList.size());

               for(Expression var9 : this.valueList) {
                  if (var9 instanceof ExpressionList) {
                     ExpressionList var10 = (ExpressionList)var9;
                     if (var10.isArray() || var10.getSubexpressionCount() != var3) {
                        return;
                     }

                     var7.add(var10.getSubexpression(var4));
                  } else {
                     if (!(var9 instanceof ValueExpression)) {
                        return;
                     }

                     Value var12 = var9.getValue((SessionLocal)null);
                     if (var12.getValueType() != 41) {
                        return;
                     }

                     Value[] var11 = ((ValueRow)var12).getList();
                     if (var3 != var11.length) {
                        return;
                     }

                     var7.add(ValueExpression.get(var11[var4]));
                  }
               }

               this.createIndexConditions(var1, var6, var7);
            }
         }
      }

   }

   void createIndexConditions(TableFilter var1, ExpressionColumn var2, ArrayList<Expression> var3) {
      ExpressionVisitor var4 = ExpressionVisitor.getNotFromResolverVisitor(var1);
      TypeInfo var5 = var2.getType();

      for(Expression var7 : var3) {
         if (!var7.isEverything(var4) || !TypeInfo.haveSameOrdering(var5, TypeInfo.getHigherType(var5, var7.getType()))) {
            return;
         }
      }

      var1.addIndexCondition(IndexCondition.getInList(var2, var3));
   }

   public void setEvaluatable(TableFilter var1, boolean var2) {
      this.left.setEvaluatable(var1, var2);

      for(Expression var4 : this.valueList) {
         var4.setEvaluatable(var1, var2);
      }

   }

   public void updateAggregate(SessionLocal var1, int var2) {
      this.left.updateAggregate(var1, var2);

      for(Expression var4 : this.valueList) {
         var4.updateAggregate(var1, var2);
      }

   }

   public boolean isEverything(ExpressionVisitor var1) {
      return !this.left.isEverything(var1) ? false : this.areAllValues(var1);
   }

   private boolean areAllValues(ExpressionVisitor var1) {
      for(Expression var3 : this.valueList) {
         if (!var3.isEverything(var1)) {
            return false;
         }
      }

      return true;
   }

   public int getCost() {
      int var1 = this.left.getCost();

      for(Expression var3 : this.valueList) {
         var1 += var3.getCost();
      }

      return var1;
   }

   Expression getAdditional(Comparison var1) {
      if (!this.not && !this.whenOperand && this.left.isEverything(ExpressionVisitor.DETERMINISTIC_VISITOR)) {
         Expression var2 = var1.getIfEquals(this.left);
         if (var2 != null) {
            ArrayList var3 = new ArrayList(this.valueList.size() + 1);
            var3.addAll(this.valueList);
            var3.add(var2);
            return new ConditionInList(this.left, false, false, var3);
         }
      }

      return null;
   }
}
