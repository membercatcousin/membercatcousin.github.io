package org.h2.util.json;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Map;

public final class JSONObject extends JSONValue {
   private final ArrayList<AbstractMap.SimpleImmutableEntry<String, JSONValue>> members = new ArrayList();

   JSONObject() {
   }

   void addMember(String var1, JSONValue var2) {
      this.members.add(new AbstractMap.SimpleImmutableEntry(var1, var2));
   }

   public void addTo(JSONTarget<?> var1) {
      var1.startObject();

      for(AbstractMap.SimpleImmutableEntry var3 : this.members) {
         var1.member((String)var3.getKey());
         ((JSONValue)var3.getValue()).addTo(var1);
      }

      var1.endObject();
   }

   public Map.Entry<String, JSONValue>[] getMembers() {
      return (Map.Entry[])this.members.toArray(new Map.Entry[0]);
   }

   public JSONValue getFirst(String var1) {
      for(AbstractMap.SimpleImmutableEntry var3 : this.members) {
         if (var1.equals(var3.getKey())) {
            return (JSONValue)var3.getValue();
         }
      }

      return null;
   }
}
