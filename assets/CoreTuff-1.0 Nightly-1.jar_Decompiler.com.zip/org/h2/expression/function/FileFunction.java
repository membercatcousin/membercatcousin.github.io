package org.h2.expression.function;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.h2.engine.Database;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionVisitor;
import org.h2.message.DbException;
import org.h2.store.fs.FileUtils;
import org.h2.util.IOUtils;
import org.h2.value.ExtTypeInfo;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueBigint;
import org.h2.value.ValueLob;
import org.h2.value.ValueNull;

public final class FileFunction extends Function1_2 {
   public static final int FILE_READ = 0;
   public static final int FILE_WRITE = 1;
   private static final String[] NAMES = new String[]{"FILE_READ", "FILE_WRITE"};
   private final int function;

   public FileFunction(Expression var1, Expression var2, int var3) {
      super(var1, var2);
      this.function = var3;
   }

   public Value getValue(SessionLocal var1) {
      var1.getUser().checkAdmin();
      Value var2 = this.left.getValue(var1);
      if (var2 == ValueNull.INSTANCE) {
         return ValueNull.INSTANCE;
      } else {
         switch (this.function) {
            case 0:
               String var20 = var2.getString();
               Database var21 = var1.getDatabase();

               try {
                  long var22 = FileUtils.size(var20);
                  InputStream var8 = FileUtils.newInputStream(var20);

                  Object var7;
                  try {
                     if (this.right == null) {
                        var7 = var21.getLobStorage().createBlob(var8, var22);
                     } else {
                        Value var9 = this.right.getValue(var1);
                        InputStreamReader var10 = var9 == ValueNull.INSTANCE ? new InputStreamReader(var8) : new InputStreamReader(var8, var9.getString());
                        var7 = var21.getLobStorage().createClob(var10, var22);
                     }
                  } catch (Throwable var15) {
                     if (var8 != null) {
                        try {
                           var8.close();
                        } catch (Throwable var13) {
                           var15.addSuppressed(var13);
                        }
                     }

                     throw var15;
                  }

                  if (var8 != null) {
                     var8.close();
                  }

                  var2 = var1.addTemporaryLob((ValueLob)var7);
                  break;
               } catch (IOException var16) {
                  throw DbException.convertIOException(var16, var20);
               }
            case 1:
               Value var3 = this.right.getValue(var1);
               if (var3 == ValueNull.INSTANCE) {
                  var2 = ValueNull.INSTANCE;
               } else {
                  String var4 = var3.getString();

                  try {
                     OutputStream var5 = Files.newOutputStream(Paths.get(var4));

                     try {
                        InputStream var6 = var2.getInputStream();

                        try {
                           var2 = ValueBigint.get(IOUtils.copy(var6, var5));
                        } catch (Throwable var14) {
                           if (var6 != null) {
                              try {
                                 var6.close();
                              } catch (Throwable var12) {
                                 var14.addSuppressed(var12);
                              }
                           }

                           throw var14;
                        }

                        if (var6 != null) {
                           var6.close();
                        }
                     } catch (Throwable var17) {
                        if (var5 != null) {
                           try {
                              var5.close();
                           } catch (Throwable var11) {
                              var17.addSuppressed(var11);
                           }
                        }

                        throw var17;
                     }

                     if (var5 != null) {
                        var5.close();
                     }
                  } catch (IOException var18) {
                     throw DbException.convertIOException(var18, var4);
                  }
               }
               break;
            default:
               throw DbException.getInternalError("function=" + this.function);
         }

         return var2;
      }
   }

   public Expression optimize(SessionLocal var1) {
      this.left = this.left.optimize(var1);
      if (this.right != null) {
         this.right = this.right.optimize(var1);
      }

      switch (this.function) {
         case 0:
            this.type = this.right == null ? TypeInfo.getTypeInfo(7, 2147483647L, 0, (ExtTypeInfo)null) : TypeInfo.getTypeInfo(3, 2147483647L, 0, (ExtTypeInfo)null);
            break;
         case 1:
            this.type = TypeInfo.TYPE_BIGINT;
            break;
         default:
            throw DbException.getInternalError("function=" + this.function);
      }

      return this;
   }

   public boolean isEverything(ExpressionVisitor var1) {
      switch (var1.getType()) {
         case 2:
         case 8:
            return false;
         case 5:
            if (this.function == 1) {
               return false;
            }
         default:
            return super.isEverything(var1);
      }
   }

   public String getName() {
      return NAMES[this.function];
   }
}
