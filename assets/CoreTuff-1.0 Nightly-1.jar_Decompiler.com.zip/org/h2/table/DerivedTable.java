package org.h2.table;

import java.util.ArrayList;
import org.h2.command.QueryScope;
import org.h2.command.query.Query;
import org.h2.engine.SessionLocal;
import org.h2.expression.ExpressionVisitor;
import org.h2.expression.Parameter;
import org.h2.index.QueryExpressionIndex;
import org.h2.index.RegularQueryExpressionIndex;
import org.h2.message.DbException;
import org.h2.util.StringUtils;

public final class DerivedTable extends QueryExpressionTable {
   private final String querySQL;
   private final Query topQuery;
   private final ArrayList<Parameter> originalParameters;

   public DerivedTable(SessionLocal var1, String var2, Column[] var3, Query var4, Query var5) {
      super(var1.getDatabase().getMainSchema(), 0, var2);
      this.setTemporary(true);
      this.topQuery = var5;
      var4.prepareExpressions();

      try {
         this.querySQL = var4.getPlanSQL(0);
         this.originalParameters = var4.getParameters();
         this.tables = new ArrayList(var4.getTables());
         this.setColumns(this.initColumns(var1, var3, var4, true, false));
         this.viewQuery = var4;
      } catch (DbException var7) {
         if (var7.getErrorCode() == 90156) {
            throw var7;
         } else {
            var7.addSQL(this.getCreateSQL());
            throw var7;
         }
      }
   }

   protected QueryExpressionIndex createIndex(SessionLocal var1, int[] var2) {
      return new RegularQueryExpressionIndex(this, this.querySQL, this.originalParameters, var1, var2);
   }

   public boolean isQueryComparable() {
      return super.isQueryComparable() && (this.topQuery == null || this.topQuery.isEverything(ExpressionVisitor.QUERY_COMPARABLE_VISITOR));
   }

   public boolean canDrop() {
      return false;
   }

   public TableType getTableType() {
      return null;
   }

   public Query getTopQuery() {
      return this.topQuery;
   }

   public String getCreateSQL() {
      return null;
   }

   public StringBuilder getSQL(StringBuilder var1, int var2) {
      return StringUtils.indent(var1.append("(\n"), this.querySQL, 4, true).append(')');
   }

   public QueryScope getQueryScope() {
      return this.viewQuery.getOuterQueryScope();
   }
}
