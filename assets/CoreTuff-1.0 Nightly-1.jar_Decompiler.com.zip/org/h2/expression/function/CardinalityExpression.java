package org.h2.expression.function;

import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.TypedValueExpression;
import org.h2.message.DbException;
import org.h2.util.MathUtils;
import org.h2.util.json.JSONArray;
import org.h2.util.json.JSONValue;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueArray;
import org.h2.value.ValueInteger;
import org.h2.value.ValueNull;

public final class CardinalityExpression extends Function1 {
   private final boolean max;

   public CardinalityExpression(Expression var1, boolean var2) {
      super(var1);
      this.max = var2;
   }

   public Value getValue(SessionLocal var1) {
      int var2;
      if (this.max) {
         TypeInfo var3 = this.arg.getType();
         if (var3.getValueType() != 40) {
            throw DbException.getInvalidValueException("array", this.arg.getValue(var1).getTraceSQL());
         }

         var2 = MathUtils.convertLongToInt(var3.getPrecision());
      } else {
         Value var5 = this.arg.getValue(var1);
         if (var5 == ValueNull.INSTANCE) {
            return ValueNull.INSTANCE;
         }

         switch (var5.getValueType()) {
            case 38:
               JSONValue var4 = var5.convertToAnyJson().getDecomposition();
               if (!(var4 instanceof JSONArray)) {
                  return ValueNull.INSTANCE;
               }

               var2 = ((JSONArray)var4).length();
               break;
            case 40:
               var2 = ((ValueArray)var5).getList().length;
               break;
            default:
               throw DbException.getInvalidValueException("array", var5.getTraceSQL());
         }
      }

      return ValueInteger.get(var2);
   }

   public Expression optimize(SessionLocal var1) {
      this.arg = this.arg.optimize(var1);
      this.type = TypeInfo.TYPE_INTEGER;
      return (Expression)(this.arg.isConstant() ? TypedValueExpression.getTypedIfNull(this.getValue(var1), this.type) : this);
   }

   public String getName() {
      return this.max ? "ARRAY_MAX_CARDINALITY" : "CARDINALITY";
   }
}
