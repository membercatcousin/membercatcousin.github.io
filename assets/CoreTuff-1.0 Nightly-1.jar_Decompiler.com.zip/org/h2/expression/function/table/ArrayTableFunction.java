package org.h2.expression.function.table;

import java.util.ArrayList;
import org.h2.engine.Database;
import org.h2.engine.SessionLocal;
import org.h2.expression.Expression;
import org.h2.expression.ExpressionColumn;
import org.h2.message.DbException;
import org.h2.result.LocalResult;
import org.h2.result.ResultInterface;
import org.h2.table.Column;
import org.h2.util.json.JSONArray;
import org.h2.util.json.JSONValue;
import org.h2.value.Value;
import org.h2.value.ValueCollectionBase;
import org.h2.value.ValueInteger;
import org.h2.value.ValueJson;
import org.h2.value.ValueNull;

public final class ArrayTableFunction extends TableFunction {
   public static final int UNNEST = 0;
   public static final int TABLE = 1;
   public static final int TABLE_DISTINCT = 2;
   private Column[] columns;
   private static final String[] NAMES = new String[]{"UNNEST", "TABLE", "TABLE_DISTINCT"};
   private final int function;

   public ArrayTableFunction(int var1) {
      super(new Expression[1]);
      this.function = var1;
   }

   public ResultInterface getValue(SessionLocal var1) {
      return this.getTable(var1, false);
   }

   public void optimize(SessionLocal var1) {
      super.optimize(var1);
      if (this.args.length < 1) {
         throw DbException.get(7001, (String[])(this.getName(), ">0"));
      }
   }

   public StringBuilder getSQL(StringBuilder var1, int var2) {
      if (this.function == 0) {
         super.getSQL(var1, var2);
         if (this.args.length < this.columns.length) {
            var1.append(" WITH ORDINALITY");
         }
      } else {
         var1.append(this.getName()).append('(');

         for(int var3 = 0; var3 < this.args.length; ++var3) {
            if (var3 > 0) {
               var1.append(", ");
            }

            var1.append(this.columns[var3].getCreateSQL()).append('=');
            this.args[var3].getUnenclosedSQL(var1, var2);
         }

         var1.append(')');
      }

      return var1;
   }

   public ResultInterface getValueTemplate(SessionLocal var1) {
      return this.getTable(var1, true);
   }

   public void setColumns(ArrayList<Column> var1) {
      this.columns = (Column[])var1.toArray(new Column[0]);
   }

   private ResultInterface getTable(SessionLocal var1, boolean var2) {
      int var3 = this.columns.length;
      Expression[] var4 = new Expression[var3];
      Database var5 = var1.getDatabase();

      for(int var6 = 0; var6 < var3; ++var6) {
         Column var7 = this.columns[var6];
         ExpressionColumn var8 = new ExpressionColumn(var5, var7);
         var4[var6] = var8;
      }

      LocalResult var18 = new LocalResult(var1, var4, var3, var3);
      if (!var2 && this.function == 2) {
         var18.setDistinct();
      }

      if (!var2) {
         int var19 = var3;
         boolean var20 = this.function == 0;
         boolean var9 = false;
         if (var20) {
            var19 = this.args.length;
            if (var19 < var3) {
               var9 = true;
            }
         }

         Value[][] var10 = new Value[var19][];
         int var11 = 0;

         for(int var12 = 0; var12 < var19; ++var12) {
            Value var13 = this.args[var12].getValue(var1);
            if (var13 == ValueNull.INSTANCE) {
               var10[var12] = Value.EMPTY_VALUES;
            } else {
               Value[] var14;
               switch (var13.getValueType()) {
                  case 38:
                     JSONValue var15 = var13.convertToAnyJson().getDecomposition();
                     if (var15 instanceof JSONArray) {
                        var14 = (Value[])((JSONArray)var15).getArray(Value.class, ValueJson::fromJson);
                     } else {
                        var14 = Value.EMPTY_VALUES;
                     }
                     break;
                  case 39:
                  default:
                     var14 = new Value[]{var13};
                     break;
                  case 40:
                  case 41:
                     var14 = ((ValueCollectionBase)var13).getList();
               }

               var10[var12] = var14;
               var11 = Math.max(var11, var14.length);
            }
         }

         for(int var21 = 0; var21 < var11; ++var21) {
            Value[] var22 = new Value[var3];

            for(int var23 = 0; var23 < var19; ++var23) {
               Value[] var24 = var10[var23];
               Object var16;
               if (var24.length <= var21) {
                  var16 = ValueNull.INSTANCE;
               } else {
                  Column var17 = this.columns[var23];
                  var16 = var24[var21];
                  if (!var20) {
                     var16 = ((Value)var16).convertForAssignTo(var17.getType(), var1, var17);
                  }
               }

               var22[var23] = (Value)var16;
            }

            if (var9) {
               var22[var19] = ValueInteger.get(var21 + 1);
            }

            var18.addRow(var22);
         }
      }

      var18.done();
      return var18;
   }

   public String getName() {
      return NAMES[this.function];
   }

   public boolean isDeterministic() {
      return true;
   }

   public int getFunctionType() {
      return this.function;
   }
}
