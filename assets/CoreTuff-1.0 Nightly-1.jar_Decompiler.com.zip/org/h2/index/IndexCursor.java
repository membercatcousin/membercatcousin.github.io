package org.h2.index;

import java.util.ArrayList;
import org.h2.engine.SessionLocal;
import org.h2.message.DbException;
import org.h2.result.ResultInterface;
import org.h2.result.Row;
import org.h2.result.SearchRow;
import org.h2.table.Column;
import org.h2.table.IndexColumn;
import org.h2.table.Table;
import org.h2.value.ExtTypeInfoGeometry;
import org.h2.value.Value;
import org.h2.value.ValueGeometry;
import org.h2.value.ValueNull;
import org.h2.value.ValueRow;

public class IndexCursor implements Cursor {
   private SessionLocal session;
   private Index index;
   private boolean reverse;
   private Table table;
   private IndexColumn[] indexColumns;
   private boolean alwaysFalse;
   private SearchRow start;
   private SearchRow end;
   private SearchRow intersects;
   private Cursor cursor;
   private Object inColumn;
   private int inListIndex;
   private Value[] inList;
   private ResultInterface inResult;

   public void setIndex(Index var1, boolean var2) {
      this.index = var1;
      this.reverse = var2;
      this.table = var1.getTable();
      Column[] var3 = this.table.getColumns();
      this.indexColumns = new IndexColumn[var3.length];
      IndexColumn[] var4 = var1.getIndexColumns();
      if (var4 != null) {
         int var5 = 0;

         for(int var6 = var3.length; var5 < var6; ++var5) {
            int var7 = var1.getColumnIndex(var3[var5]);
            if (var7 >= 0) {
               this.indexColumns[var5] = var4[var7];
            }
         }
      }

   }

   public void prepare(SessionLocal var1, ArrayList<IndexCondition> var2) {
      this.session = var1;
      this.alwaysFalse = false;
      this.start = this.end = null;
      this.inList = null;
      this.inColumn = null;
      this.inResult = null;
      this.intersects = null;

      for(IndexCondition var4 : var2) {
         if (var4.isAlwaysFalse()) {
            this.alwaysFalse = true;
            break;
         }

         if (!this.index.isFindUsingFullTableScan()) {
            if (var4.isCompoundColumns()) {
               Column[] var13 = var4.getColumns();
               if (var4.getCompareType() != 10) {
                  throw DbException.getInternalError("Multiple columns can only be used with compound IN lists.");
               }

               if (this.start == null && this.end == null && this.canUseIndexForIn(var13)) {
                  this.inColumn = var13;
                  this.inList = var4.getCurrentValueList(var1, this.buildSortTypes(var13));
                  this.inListIndex = 0;
               }
            } else {
               Column var5 = var4.getColumn();
               switch (var4.getCompareType()) {
                  case 10:
                  case 11:
                     if (this.start == null && this.end == null && this.canUseIndexForIn(var5)) {
                        this.inColumn = var5;
                        this.inList = var4.getCurrentValueList(var1, this.buildSortTypes(new Column[]{var5}));
                        this.inListIndex = 0;
                     }
                     break;
                  case 12:
                     if (this.start == null && this.end == null && this.canUseIndexForIn(var5)) {
                        this.inColumn = var5;
                        this.inResult = var4.getCurrentResult(this.session, this.buildSortTypes(new Column[]{var5}));
                     }
                     break;
                  default:
                     Value var6 = var4.getCurrentValue(var1);
                     boolean var7 = var4.isStart();
                     boolean var8 = var4.isEnd();
                     boolean var9 = var4.isSpatialIntersects();
                     int var10 = var5.getColumnId();
                     if (var10 != -1) {
                        IndexColumn var11 = this.indexColumns[var10];
                        if (var11 != null && (var11.sortType & 1) != 0) {
                           boolean var12 = var7;
                           var7 = var8;
                           var8 = var12;
                        }
                     }

                     if (var7) {
                        this.start = this.getSearchRow(this.start, var10, var6, true);
                     }

                     if (var8) {
                        this.end = this.getSearchRow(this.end, var10, var6, false);
                     }

                     if (var9) {
                        this.intersects = this.getSpatialSearchRow(this.intersects, var10, var6);
                     }

                     if ((var7 || var8) && !this.canUseIndexFor((Column)this.inColumn)) {
                        this.inColumn = null;
                        this.inList = null;
                        this.inResult = null;
                     }
               }
            }
         }
      }

      if (this.inColumn != null) {
         this.start = this.table.getTemplateRow();
      }

   }

   private int[] buildSortTypes(Column[] var1) {
      IndexColumn[] var2 = this.index.getIndexColumns();
      int var3 = Math.max(var2.length, var1.length);
      int[] var4 = new int[var3];

      for(int var5 = 0; var5 < var3; ++var5) {
         var4[var5] = (var2[var5].sortType & 1) != 0 ^ this.reverse ? 1 : 0;
      }

      return var4;
   }

   public void find(SessionLocal var1, ArrayList<IndexCondition> var2) {
      this.prepare(var1, var2);
      if (this.inColumn == null) {
         if (!this.alwaysFalse) {
            SearchRow var3;
            SearchRow var4;
            if (this.reverse) {
               var3 = this.end;
               var4 = this.start;
            } else {
               var3 = this.start;
               var4 = this.end;
            }

            if (this.intersects != null && this.index instanceof SpatialIndex) {
               this.cursor = ((SpatialIndex)this.index).findByGeometry(this.session, var3, var4, this.reverse, this.intersects);
            } else if (this.index != null) {
               this.cursor = this.index.find(this.session, var3, var4, this.reverse);
            }
         }

      }
   }

   private boolean canUseIndexForIn(Column var1) {
      return this.inColumn != null ? false : this.canUseIndexFor(var1);
   }

   private boolean canUseIndexFor(Column var1) {
      IndexColumn[] var2 = this.index.getIndexColumns();
      if (var2 == null) {
         return true;
      } else {
         IndexColumn var3 = var2[0];
         return var3 == null || var3.column == var1;
      }
   }

   private boolean canUseIndexForIn(Column[] var1) {
      return this.inColumn != null ? false : canUseIndexForIn(this.index, var1);
   }

   public static boolean canUseIndexForIn(Index var0, Column[] var1) {
      IndexColumn[] var2 = var0.getIndexColumns();
      if (var2 != null && var2.length == var1.length) {
         for(int var3 = 0; var3 < var2.length; ++var3) {
            IndexColumn var4 = var2[var3];
            if (var4 != null && var4.column != var1[var3]) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private SearchRow getSpatialSearchRow(SearchRow var1, int var2, Value var3) {
      if (var1 == null) {
         var1 = this.table.getTemplateRow();
      } else if (((SearchRow)var1).getValue(var2) != null) {
         ValueGeometry var4 = ((SearchRow)var1).getValue(var2).convertToGeometry((ExtTypeInfoGeometry)null);
         var3 = var3.convertToGeometry((ExtTypeInfoGeometry)null).getEnvelopeUnion(var4);
      }

      if (var2 == -1) {
         ((SearchRow)var1).setKey(var3 == ValueNull.INSTANCE ? Long.MIN_VALUE : var3.getLong());
      } else {
         ((SearchRow)var1).setValue(var2, var3);
      }

      return (SearchRow)var1;
   }

   private SearchRow getSearchRow(SearchRow var1, int var2, Value var3, boolean var4) {
      if (var1 == null) {
         var1 = this.table.getTemplateRow();
      } else {
         var3 = this.getMax(((SearchRow)var1).getValue(var2), var3, var4);
      }

      if (var2 == -1) {
         ((SearchRow)var1).setKey(var3 == ValueNull.INSTANCE ? Long.MIN_VALUE : var3.getLong());
      } else {
         ((SearchRow)var1).setValue(var2, var3);
      }

      return (SearchRow)var1;
   }

   private Value getMax(Value var1, Value var2, boolean var3) {
      if (var1 == null) {
         return var2;
      } else if (var2 == null) {
         return var1;
      } else if (var1 == ValueNull.INSTANCE) {
         return var2;
      } else if (var2 == ValueNull.INSTANCE) {
         return var1;
      } else {
         int var4 = this.session.compare(var1, var2);
         if (var4 == 0) {
            return var1;
         } else {
            return var4 > 0 == var3 ? var1 : var2;
         }
      }
   }

   public boolean isAlwaysFalse() {
      return this.alwaysFalse;
   }

   public SearchRow getStart() {
      return this.start;
   }

   public SearchRow getEnd() {
      return this.end;
   }

   public Row get() {
      return this.cursor == null ? null : this.cursor.get();
   }

   public SearchRow getSearchRow() {
      return this.cursor.getSearchRow();
   }

   public boolean next() {
      while(true) {
         if (this.cursor == null) {
            this.nextCursor();
            if (this.cursor == null) {
               return false;
            }
         }

         if (this.cursor.next()) {
            return true;
         }

         this.cursor = null;
      }
   }

   private void nextCursor() {
      if (this.inList != null) {
         while(this.inListIndex < this.inList.length) {
            Value var3 = this.inList[this.inListIndex++];
            if (var3 != ValueNull.INSTANCE) {
               this.find(var3);
               break;
            }
         }
      } else if (this.inResult != null) {
         while(this.inResult.next()) {
            Value var1 = this.inResult.currentRow()[0];
            if (var1 != ValueNull.INSTANCE) {
               Object var2;
               if (this.inColumn instanceof Column[]) {
                  var2 = Column.convert(this.session, (Column[])this.inColumn, (ValueRow)var1);
               } else {
                  var2 = ((Column)this.inColumn).convert(this.session, var1);
               }

               this.find((Value)var2);
               break;
            }
         }
      }

   }

   private void find(Value var1) {
      if (this.inColumn instanceof Column[]) {
         Column[] var2 = (Column[])this.inColumn;
         ValueRow var3 = Column.convert(this.session, var2, (ValueRow)var1);
         Value[] var4 = var3.getList();
         int var5 = var2.length;

         while(true) {
            --var5;
            if (var5 < 0) {
               break;
            }

            this.start.setValue(var2[var5].getColumnId(), var4[var5]);
         }
      } else {
         Column var7 = (Column)this.inColumn;
         var1 = var7.convert(this.session, var1);
         int var8 = var7.getColumnId();
         this.start.setValue(var8, var1);
      }

      this.cursor = this.index.find(this.session, this.start, this.start, this.reverse);
   }

   public boolean previous() {
      throw DbException.getInternalError(this.toString());
   }
}
