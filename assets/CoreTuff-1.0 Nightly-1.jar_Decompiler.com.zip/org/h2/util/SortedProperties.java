package org.h2.util;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import org.h2.store.fs.FileUtils;

public class SortedProperties extends Properties {
   private static final long serialVersionUID = 1L;

   public synchronized Enumeration<Object> keys() {
      ArrayList var1 = new ArrayList();

      for(Object var3 : this.keySet()) {
         var1.add(var3.toString());
      }

      var1.sort((Comparator)null);
      return Collections.enumeration(var1);
   }

   public static boolean getBooleanProperty(Properties var0, String var1, boolean var2) {
      try {
         return Utils.parseBoolean(var0.getProperty(var1, (String)null), var2, true);
      } catch (IllegalArgumentException var4) {
         var4.printStackTrace();
         return var2;
      }
   }

   public static int getIntProperty(Properties var0, String var1, int var2) {
      String var3 = var0.getProperty(var1, Integer.toString(var2));

      try {
         return Integer.decode(var3);
      } catch (Exception var5) {
         var5.printStackTrace();
         return var2;
      }
   }

   public static String getStringProperty(Properties var0, String var1, String var2) {
      return var0.getProperty(var1, var2);
   }

   public static synchronized SortedProperties loadProperties(String var0) throws IOException {
      SortedProperties var1 = new SortedProperties();
      if (FileUtils.exists(var0)) {
         InputStream var2 = FileUtils.newInputStream(var0);

         try {
            var1.load(new InputStreamReader(var2, StandardCharsets.ISO_8859_1));
         } catch (Throwable var6) {
            if (var2 != null) {
               try {
                  var2.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (var2 != null) {
            var2.close();
         }
      }

      return var1;
   }

   public synchronized void store(String var1) throws IOException {
      ByteArrayOutputStream var2 = new ByteArrayOutputStream();
      this.store(var2, (String)null);
      ByteArrayInputStream var3 = new ByteArrayInputStream(var2.toByteArray());
      InputStreamReader var4 = new InputStreamReader(var3, StandardCharsets.ISO_8859_1);
      LineNumberReader var5 = new LineNumberReader(var4);

      OutputStreamWriter var6;
      try {
         var6 = new OutputStreamWriter(FileUtils.newOutputStream(var1, false), StandardCharsets.ISO_8859_1);
      } catch (Exception var11) {
         throw new IOException(var11.toString(), var11);
      }

      PrintWriter var7 = new PrintWriter(new BufferedWriter(var6));

      try {
         while(true) {
            String var8 = var5.readLine();
            if (var8 == null) {
               break;
            }

            if (!var8.startsWith("#")) {
               var7.print(var8 + "\n");
            }
         }
      } catch (Throwable var12) {
         try {
            var7.close();
         } catch (Throwable var10) {
            var12.addSuppressed(var10);
         }

         throw var12;
      }

      var7.close();
   }

   public synchronized String toLines() {
      StringBuilder var1 = new StringBuilder();

      for(Map.Entry var3 : (new TreeMap(this)).entrySet()) {
         var1.append(var3.getKey()).append('=').append(var3.getValue()).append('\n');
      }

      return var1.toString();
   }

   public static SortedProperties fromLines(String var0) {
      SortedProperties var1 = new SortedProperties();

      for(String var5 : StringUtils.arraySplit(var0, '\n', true)) {
         int var6 = var5.indexOf(61);
         if (var6 > 0) {
            var1.put(var5.substring(0, var6), var5.substring(var6 + 1));
         }
      }

      return var1;
   }
}
