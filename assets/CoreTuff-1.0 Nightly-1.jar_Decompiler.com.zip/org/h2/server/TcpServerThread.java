package org.h2.server;

import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.h2.command.Command;
import org.h2.engine.ConnectionInfo;
import org.h2.engine.Engine;
import org.h2.engine.Session;
import org.h2.engine.SessionLocal;
import org.h2.engine.SysProperties;
import org.h2.expression.Parameter;
import org.h2.expression.ParameterInterface;
import org.h2.expression.ParameterRemote;
import org.h2.jdbc.JdbcException;
import org.h2.jdbc.meta.DatabaseMetaServer;
import org.h2.message.DbException;
import org.h2.result.BatchResult;
import org.h2.result.ResultColumn;
import org.h2.result.ResultInterface;
import org.h2.result.ResultWithGeneratedKeys;
import org.h2.store.LobStorageInterface;
import org.h2.util.IOUtils;
import org.h2.util.NetUtils;
import org.h2.util.NetworkConnectionInfo;
import org.h2.util.SmallLRUCache;
import org.h2.util.SmallMap;
import org.h2.util.TimeZoneProvider;
import org.h2.value.Transfer;
import org.h2.value.TypeInfo;
import org.h2.value.Value;
import org.h2.value.ValueLob;

public class TcpServerThread implements Runnable {
   protected final Transfer transfer;
   private final TcpServer server;
   private SessionLocal session;
   private boolean stop;
   private Thread thread;
   private Command commit;
   private final SmallMap cache;
   private final SmallLRUCache<Long, CachedInputStream> lobs;
   private final int threadId;
   private int clientVersion;
   private String sessionId;
   private long lastRemoteSettingsId;

   TcpServerThread(Socket var1, TcpServer var2, int var3) {
      this.cache = new SmallMap(SysProperties.SERVER_CACHED_OBJECTS);
      this.lobs = SmallLRUCache.<Long, CachedInputStream>newInstance(Math.max(SysProperties.SERVER_CACHED_OBJECTS, SysProperties.SERVER_RESULT_SET_FETCH_SIZE * 5));
      this.server = var2;
      this.threadId = var3;
      this.transfer = new Transfer((Session)null, var1);
   }

   private void trace(String var1) {
      this.server.trace(this + " " + var1);
   }

   public void run() {
      try {
         try {
            this.transfer.init();
            this.trace("Connect");

            try {
               Socket var1 = this.transfer.getSocket();
               if (var1 == null) {
                  return;
               }

               if (!this.server.allow(this.transfer.getSocket())) {
                  throw DbException.get(90117);
               }

               int var2 = this.transfer.readInt();
               if (var2 < 6) {
                  throw DbException.get(90047, Integer.toString(var2), "17");
               }

               int var3 = this.transfer.readInt();
               if (var3 < 17) {
                  throw DbException.get(90047, Integer.toString(var3), "17");
               }

               if (var2 > 21) {
                  throw DbException.get(90047, Integer.toString(var2), "21");
               }

               if (var3 >= 21) {
                  this.clientVersion = 21;
               } else {
                  this.clientVersion = var3;
               }

               this.transfer.setVersion(this.clientVersion);
               String var4 = this.transfer.readString();
               String var5 = this.transfer.readString();
               if (var4 == null && var5 == null) {
                  String var6 = this.transfer.readString();
                  int var7 = this.transfer.readInt();
                  this.stop = true;
                  if (var7 == 13) {
                     int var8 = this.transfer.readInt();
                     this.server.cancelStatement(var6, var8);
                  } else if (var7 == 14) {
                     var4 = this.server.checkKeyAndGetDatabaseName(var6);
                     if (!var6.equals(var4)) {
                        this.transfer.writeInt(1);
                     } else {
                        this.transfer.writeInt(0);
                     }
                  }
               }

               String var22 = this.server.getBaseDir();
               if (var22 == null) {
                  var22 = SysProperties.getBaseDir();
               }

               var4 = this.server.checkKeyAndGetDatabaseName(var4);
               ConnectionInfo var23 = new ConnectionInfo(var4);
               var23.setOriginalURL(var5);
               var23.setUserName(this.transfer.readString());
               var23.setUserPasswordHash(this.transfer.readBytes());
               var23.setFilePasswordHash(this.transfer.readBytes());
               int var24 = this.transfer.readInt();

               for(int var9 = 0; var9 < var24; ++var9) {
                  var23.setProperty(this.transfer.readString(), this.transfer.readString());
               }

               if (var22 != null) {
                  var23.setBaseDir(var22);
               }

               if (this.server.getIfExists()) {
                  var23.setProperty("FORBID_CREATION", "TRUE");
               }

               this.transfer.writeInt(1);
               this.transfer.writeInt(this.clientVersion);
               this.transfer.flush();
               if (var23.getFilePasswordHash() != null) {
                  var23.setFileEncryptionKey(this.transfer.readBytes());
               }

               var23.setNetworkConnectionInfo(new NetworkConnectionInfo(NetUtils.ipToShortForm(new StringBuilder(this.server.getSSL() ? "ssl://" : "tcp://"), var1.getLocalAddress().getAddress(), true).append(':').append(var1.getLocalPort()).toString(), var1.getInetAddress().getAddress(), var1.getPort(), "" + 'P' + this.clientVersion));
               if (this.clientVersion < 20) {
                  var23.setProperty("OLD_INFORMATION_SCHEMA", "TRUE");
                  var23.setProperty("NON_KEYWORDS", "VALUE");
               }

               this.session = Engine.createSession(var23);
               this.transfer.setSession(this.session);
               this.server.addConnection(this.threadId, var5, var23.getUserName());
               this.trace("Connected");
               this.lastRemoteSettingsId = this.session.getDatabase().getRemoteSettingsId();
            } catch (OutOfMemoryError var17) {
               this.server.traceError(var17);
               this.sendError(var17, true);
               this.stop = true;
            } catch (Throwable var18) {
               this.sendError(var18, true);
               this.stop = true;
            }

            while(!this.stop) {
               try {
                  this.process();
               } catch (Throwable var16) {
                  this.sendError(var16, true);
               }
            }

            this.trace("Disconnect");
         } catch (Throwable var19) {
            this.server.traceError(var19);
         }

      } finally {
         this.close();
      }
   }

   private void closeSession() {
      if (this.session != null) {
         RuntimeException var1 = null;

         try {
            this.session.close();
            this.server.removeConnection(this.threadId);
         } catch (RuntimeException var7) {
            var1 = var7;
            this.server.traceError(var7);
         } catch (Exception var8) {
            this.server.traceError(var8);
         } finally {
            this.session = null;
         }

         if (var1 != null) {
            throw var1;
         }
      }

   }

   void close() {
      try {
         this.stop = true;
         this.closeSession();
      } catch (Exception var5) {
         this.server.traceError(var5);
      } finally {
         this.transfer.close();
         this.trace("Close");
         this.server.remove(this);
      }

   }

   private void sendError(Throwable var1, boolean var2) {
      try {
         if (var2) {
            this.transfer.writeInt(0);
         }

         this.sendSQLException(DbException.convert(var1).getSQLException());
         this.transfer.flush();
      } catch (Exception var4) {
         if (!this.transfer.isClosed()) {
            this.server.traceError(var4);
         }

         this.stop = true;
      }

   }

   private void sendSQLException(SQLException var1) throws IOException {
      StringWriter var2 = new StringWriter();
      var1.printStackTrace(new PrintWriter(var2));
      String var3 = var2.toString();
      String var4;
      String var5;
      if (var1 instanceof JdbcException) {
         JdbcException var6 = (JdbcException)var1;
         var4 = var6.getOriginalMessage();
         var5 = var6.getSQL();
      } else {
         var4 = var1.getMessage();
         var5 = null;
      }

      this.transfer.writeString(var1.getSQLState()).writeString(var4).writeString(var5).writeInt(var1.getErrorCode()).writeString(var3);
   }

   private void setParameters(Command var1) throws IOException {
      int var2 = this.transfer.readInt();
      ArrayList var3 = var1.getParameters();

      for(int var4 = 0; var4 < var2; ++var4) {
         Parameter var5 = (Parameter)var3.get(var4);
         var5.setValue(this.transfer.readValue((TypeInfo)null));
      }

   }

   private void process() throws IOException {
      SessionLocal var1 = this.session;
      int var2 = this.transfer.readInt();
      switch (var2) {
         case 0:
         case 18:
            int var51 = this.transfer.readInt();
            String var61 = this.transfer.readString();
            int var69 = var1.getModificationId();
            Command var75 = var1.prepareLocal(var61);
            boolean var81 = var75.isReadOnly();
            this.cache.addObject(var51, var75);
            boolean var90 = var75.isQuery();
            this.transfer.writeInt(this.getState(var69)).writeBoolean(var90).writeBoolean(var81);
            if (var2 != 0) {
               this.transfer.writeInt(var75.getCommandType());
            }

            ArrayList var95 = var75.getParameters();
            this.transfer.writeInt(var95.size());
            if (var2 != 0) {
               for(ParameterInterface var105 : var95) {
                  ParameterRemote.writeMetaData(this.transfer, var105);
               }
            }

            this.transfer.flush();
            break;
         case 1:
            this.stop = true;
            this.closeSession();
            this.transfer.writeInt(1).flush();
            this.close();
            break;
         case 2:
            int var50 = this.transfer.readInt();
            int var60 = this.transfer.readInt();
            long var68 = this.transfer.readRowCount();
            int var80 = this.transfer.readInt();
            Command var89 = (Command)this.cache.getObject(var50, false);
            this.setParameters(var89);
            int var94 = var1.getModificationId();
            var1.lock();

            ResultInterface var100;
            try {
               var100 = var89.executeQuery(var68, -1, false);
            } finally {
               var1.unlock();
            }

            this.cache.addObject(var60, var100);
            int var104 = var100.getVisibleColumnCount();
            int var108 = this.getState(var94);
            this.transfer.writeInt(var108).writeInt(var104);
            long var110 = var100.isLazy() ? -1L : var100.getRowCount();
            this.transfer.writeRowCount(var110);

            for(int var15 = 0; var15 < var104; ++var15) {
               ResultColumn.writeColumn(this.transfer, var100, var15);
            }

            this.sendRows(var100, var110 >= 0L ? Math.min(var110, (long)var80) : (long)var80);
            this.transfer.flush();
            break;
         case 3:
            int var49 = this.transfer.readInt();
            Command var59 = (Command)this.cache.getObject(var49, false);
            this.setParameters(var59);
            Object var67 = this.readGeneratedKeysRequest();
            int var74 = var1.getModificationId();
            var1.lock();

            ResultWithGeneratedKeys var79;
            try {
               var79 = var59.executeUpdate(var67);
            } finally {
               var1.unlock();
            }

            int var88;
            if (var1.isClosed()) {
               var88 = 2;
               this.stop = true;
            } else {
               var88 = this.getState(var74);
            }

            this.transfer.writeInt(var88);
            this.transfer.writeRowCount(var79.getUpdateCount());
            this.transfer.writeBoolean(var1.getAutoCommit());
            if (var67 != Boolean.FALSE) {
               this.sendGeneratedKeys(var79.getGeneratedKeys());
            }

            this.transfer.flush();
            break;
         case 4:
            int var48 = this.transfer.readInt();
            Command var58 = (Command)this.cache.getObject(var48, true);
            if (var58 != null) {
               var58.close();
               this.cache.freeObject(var48);
            }
            break;
         case 5:
            int var47 = this.transfer.readInt();
            int var57 = this.transfer.readInt();
            ResultInterface var66 = (ResultInterface)this.cache.getObject(var47, false);
            this.transfer.writeInt(1);
            this.sendRows(var66, (long)var57);
            this.transfer.flush();
            break;
         case 6:
            int var46 = this.transfer.readInt();
            ResultInterface var56 = (ResultInterface)this.cache.getObject(var46, false);
            var56.reset();
            break;
         case 7:
            int var45 = this.transfer.readInt();
            ResultInterface var55 = (ResultInterface)this.cache.getObject(var45, true);
            if (var55 != null) {
               var55.close();
               this.cache.freeObject(var45);
            }
            break;
         case 8:
            if (this.commit == null) {
               this.commit = var1.prepareLocal("COMMIT");
            }

            int var44 = var1.getModificationId();
            this.commit.executeUpdate((Object)null);
            this.transfer.writeInt(this.getState(var44)).flush();
            break;
         case 9:
            int var43 = this.transfer.readInt();
            int var54 = this.transfer.readInt();
            Object var65 = this.cache.getObject(var43, false);
            this.cache.freeObject(var43);
            this.cache.addObject(var54, var65);
            break;
         case 10:
            int var42 = this.transfer.readInt();
            int var53 = this.transfer.readInt();
            Command var64 = (Command)this.cache.getObject(var42, false);
            ResultInterface var73 = var64.getMetaData();
            this.cache.addObject(var53, var73);
            int var78 = var73.getVisibleColumnCount();
            this.transfer.writeInt(1).writeInt(var78).writeRowCount(0L);

            for(int var87 = 0; var87 < var78; ++var87) {
               ResultColumn.writeColumn(this.transfer, var73, var87);
            }

            this.transfer.flush();
            break;
         case 11:
         case 13:
         case 14:
         default:
            this.trace("Unknown operation: " + var2);
            this.close();
            break;
         case 12:
            this.sessionId = this.transfer.readString();
            if (this.clientVersion >= 20) {
               var1.setTimeZone(TimeZoneProvider.ofId(this.transfer.readString()));
            }

            this.transfer.writeInt(1).writeBoolean(var1.getAutoCommit()).flush();
            break;
         case 15:
            boolean var41 = this.transfer.readBoolean();
            var1.setAutoCommit(var41);
            this.transfer.writeInt(1).flush();
            break;
         case 16:
            this.transfer.writeInt(1).writeInt(var1.hasPendingTransaction() ? 1 : 0).flush();
            break;
         case 17:
            long var40 = this.transfer.readLong();
            byte[] var63 = this.transfer.readBytes();
            long var72 = this.transfer.readLong();
            int var84 = this.transfer.readInt();
            this.transfer.verifyLobMac(var63, var40);
            CachedInputStream var93 = (CachedInputStream)this.lobs.get(var40);
            if (var93 == null || var93.getPos() != var72) {
               LobStorageInterface var98 = var1.getDataHandler().getLobStorage();
               InputStream var103 = var98.getInputStream(var40, -1L);
               var93 = new CachedInputStream(var103);
               this.lobs.put(var40, var93);
               var103.skip(var72);
            }

            var84 = Math.min(65536, var84);
            byte[] var99 = new byte[var84];
            var84 = IOUtils.readFully((InputStream)var93, (byte[])var99, var84);
            this.transfer.writeInt(1);
            this.transfer.writeInt(var84);
            this.transfer.writeBytes(var99, 0, var84);
            this.transfer.flush();
            break;
         case 19:
            int var39 = this.transfer.readInt();
            int var52 = this.transfer.readInt();
            Value[] var62 = new Value[var52];

            for(int var70 = 0; var70 < var52; ++var70) {
               var62[var70] = this.transfer.readValue((TypeInfo)null);
            }

            int var71 = var1.getModificationId();
            var1.lock();

            ResultInterface var77;
            try {
               var77 = DatabaseMetaServer.process(var1, var39, var62);
            } finally {
               var1.unlock();
            }

            int var83 = var77.getVisibleColumnCount();
            int var92 = this.getState(var71);
            this.transfer.writeInt(var92).writeInt(var83);
            long var97 = var77.getRowCount();
            this.transfer.writeRowCount(var97);

            for(int var107 = 0; var107 < var83; ++var107) {
               ResultColumn.writeColumn(this.transfer, var77, var107);
            }

            this.sendRows(var77, var97);
            this.transfer.flush();
            break;
         case 20:
            int var3 = this.transfer.readInt();
            Command var4 = (Command)this.cache.getObject(var3, false);
            int var5 = this.transfer.readInt();
            ArrayList var6 = new ArrayList(var5);

            for(int var7 = 0; var7 < var5; ++var7) {
               int var8 = this.transfer.readInt();
               Value[] var9 = new Value[var8];

               for(int var10 = 0; var10 < var8; ++var10) {
                  var9[var10] = this.transfer.readValue((TypeInfo)null);
               }

               var6.add(var9);
            }

            Object var76 = this.readGeneratedKeysRequest();
            int var82 = var1.getModificationId();
            var1.lock();

            BatchResult var91;
            try {
               var91 = var4.executeBatchUpdate(var6, var76);
            } finally {
               var1.unlock();
            }

            int var96;
            if (var1.isClosed()) {
               var96 = 2;
               this.stop = true;
            } else {
               var96 = this.getState(var82);
            }

            this.transfer.writeInt(var96);

            for(long var14 : var91.getUpdateCounts()) {
               this.transfer.writeLong(var14);
            }

            if (var76 != Boolean.FALSE) {
               this.sendGeneratedKeys(var91.getGeneratedKeys());
            }

            List var102 = var91.getExceptions();
            this.transfer.writeInt(var102.size());

            for(SQLException var109 : var102) {
               this.sendSQLException(var109);
            }

            this.transfer.writeBoolean(var1.getAutoCommit());
            this.transfer.flush();
      }

   }

   private Object readGeneratedKeysRequest() throws IOException {
      int var1 = this.transfer.readInt();
      switch (var1) {
         case 0:
            return Boolean.FALSE;
         case 1:
            return Boolean.TRUE;
         case 2:
            int var5 = this.transfer.readInt();
            int[] var6 = new int[var5];

            for(int var7 = 0; var7 < var5; ++var7) {
               var6[var7] = this.transfer.readInt();
            }

            return var6;
         case 3:
            int var2 = this.transfer.readInt();
            String[] var3 = new String[var2];

            for(int var4 = 0; var4 < var2; ++var4) {
               var3[var4] = this.transfer.readString();
            }

            return var3;
         default:
            throw DbException.get(90067, "Unsupported generated keys' mode " + var1);
      }
   }

   private void sendGeneratedKeys(ResultInterface var1) throws IOException {
      int var2 = var1.getVisibleColumnCount();
      this.transfer.writeInt(var2);
      long var3 = var1.getRowCount();
      this.transfer.writeRowCount(var3);

      for(int var5 = 0; var5 < var2; ++var5) {
         ResultColumn.writeColumn(this.transfer, var1, var5);
      }

      this.sendRows(var1, var3);
      var1.close();
   }

   private int getState(int var1) {
      if (this.session == null) {
         return 2;
      } else {
         if (this.session.getModificationId() == var1) {
            long var2 = this.session.getDatabase().getRemoteSettingsId();
            if (this.lastRemoteSettingsId == var2) {
               return 1;
            }

            this.lastRemoteSettingsId = var2;
         }

         return 3;
      }
   }

   private void sendRows(ResultInterface var1, long var2) throws IOException {
      int var4 = var1.getVisibleColumnCount();
      boolean var5 = var1.isLazy();
      Session var6 = var5 ? this.session.setThreadLocalSession() : null;

      try {
         while(var2-- > 0L) {
            boolean var7;
            try {
               var7 = var1.next();
            } catch (Exception var15) {
               this.transfer.writeByte((byte)-1);
               this.sendError(var15, false);
               break;
            }

            if (!var7) {
               this.transfer.writeByte((byte)0);
               break;
            }

            this.transfer.writeByte((byte)1);
            Value[] var8 = var1.currentRow();

            for(int var9 = 0; var9 < var4; ++var9) {
               Object var10 = var8[var9];
               if (var5 && var10 instanceof ValueLob) {
                  ValueLob var11 = ((ValueLob)var10).copyToResult();
                  if (var11 != var10) {
                     var10 = this.session.addTemporaryLob(var11);
                  }
               }

               this.transfer.writeValue((Value)var10);
            }
         }
      } finally {
         if (var5) {
            this.session.resetThreadLocalSession(var6);
         }

      }

   }

   void setThread(Thread var1) {
      this.thread = var1;
   }

   Thread getThread() {
      return this.thread;
   }

   void cancelStatement(String var1, int var2) {
      if (Objects.equals(var1, this.sessionId)) {
         Command var3 = (Command)this.cache.getObject(var2, false);
         var3.cancel();
      }

   }

   static class CachedInputStream extends FilterInputStream {
      private static final ByteArrayInputStream DUMMY = new ByteArrayInputStream(new byte[0]);
      private long pos;

      CachedInputStream(InputStream var1) {
         super((InputStream)(var1 == null ? DUMMY : var1));
         if (var1 == null) {
            this.pos = -1L;
         }

      }

      public int read(byte[] var1, int var2, int var3) throws IOException {
         var3 = super.read(var1, var2, var3);
         if (var3 > 0) {
            this.pos += (long)var3;
         }

         return var3;
      }

      public int read() throws IOException {
         int var1 = this.in.read();
         if (var1 >= 0) {
            ++this.pos;
         }

         return var1;
      }

      public long skip(long var1) throws IOException {
         var1 = super.skip(var1);
         if (var1 > 0L) {
            this.pos += var1;
         }

         return var1;
      }

      public long getPos() {
         return this.pos;
      }
   }
}
