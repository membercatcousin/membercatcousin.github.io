package org.h2.tools;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.SequenceInputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import org.h2.engine.MetaRecord;
import org.h2.message.DbException;
import org.h2.mvstore.MVMap;
import org.h2.mvstore.MVStore;
import org.h2.mvstore.MVStoreTool;
import org.h2.mvstore.StreamStore;
import org.h2.mvstore.db.LobStorageMap;
import org.h2.mvstore.db.ValueDataType;
import org.h2.mvstore.tx.TransactionMap;
import org.h2.mvstore.tx.TransactionStore;
import org.h2.mvstore.type.MetaType;
import org.h2.mvstore.type.StringDataType;
import org.h2.result.Row;
import org.h2.store.DataHandler;
import org.h2.store.FileLister;
import org.h2.store.FileStore;
import org.h2.store.LobStorageInterface;
import org.h2.store.fs.FileUtils;
import org.h2.util.IOUtils;
import org.h2.util.SmallLRUCache;
import org.h2.util.StringUtils;
import org.h2.util.TempFileDeleter;
import org.h2.util.Tool;
import org.h2.value.CompareMode;
import org.h2.value.Value;
import org.h2.value.ValueCollectionBase;
import org.h2.value.ValueJson;
import org.h2.value.ValueLob;
import org.h2.value.lob.LobData;
import org.h2.value.lob.LobDataDatabase;

public class Recover extends Tool implements DataHandler {
   private String databaseName;
   private int storageId;
   String storageName;
   int recordLength;
   private int valueId;
   boolean trace;
   private ArrayList<MetaRecord> schema;
   private HashSet<Integer> objectIdSet;
   private HashMap<Integer, String> tableMap;
   private HashMap<String, String> columnTypeMap;
   private boolean lobMaps;

   public static void main(String... var0) throws SQLException {
      (new Recover()).runTool(var0);
   }

   public void runTool(String... var1) throws SQLException {
      String var2 = ".";
      String var3 = null;

      for(int var4 = 0; var1 != null && var4 < var1.length; ++var4) {
         String var5 = var1[var4];
         if ("-dir".equals(var5)) {
            ++var4;
            var2 = var1[var4];
         } else if ("-db".equals(var5)) {
            ++var4;
            var3 = var1[var4];
         } else if ("-trace".equals(var5)) {
            this.trace = true;
         } else {
            if (var5.equals("-help") || var5.equals("-?")) {
               this.showUsage();
               return;
            }

            this.showUsageAndThrowUnsupportedOption(var5);
         }
      }

      this.process(var2, var3);
   }

   public static InputStream readBlobMap(Connection var0, long var1, long var3) throws SQLException {
      final PreparedStatement var5 = var0.prepareStatement("SELECT DATA FROM INFORMATION_SCHEMA.LOB_BLOCKS WHERE LOB_ID = ? AND SEQ = ? AND ? > 0");
      var5.setLong(1, var1);
      var5.setLong(3, var3);
      return new SequenceInputStream(new Enumeration<InputStream>() {
         private int seq;
         private byte[] data = this.fetch();

         private byte[] fetch() {
            try {
               var5.setInt(2, this.seq++);
               ResultSet var1 = var5.executeQuery();
               return var1.next() ? var1.getBytes(1) : null;
            } catch (SQLException var2) {
               throw DbException.convert(var2);
            }
         }

         public boolean hasMoreElements() {
            return this.data != null;
         }

         public InputStream nextElement() {
            ByteArrayInputStream var1 = new ByteArrayInputStream(this.data);
            this.data = this.fetch();
            return var1;
         }
      });
   }

   public static Reader readClobMap(Connection var0, long var1, long var3) throws Exception {
      InputStream var5 = readBlobMap(var0, var1, var3);
      return new BufferedReader(new InputStreamReader(var5, StandardCharsets.UTF_8));
   }

   void trace(String var1) {
      if (this.trace) {
         this.out.println(var1);
      }

   }

   void traceError(String var1, Throwable var2) {
      this.out.println(var1 + ": " + var2.toString());
      if (this.trace) {
         var2.printStackTrace(this.out);
      }

   }

   public static void execute(String var0, String var1) throws SQLException {
      try {
         (new Recover()).process(var0, var1);
      } catch (DbException var3) {
         throw DbException.toSQLException(var3);
      }
   }

   private void process(String var1, String var2) {
      ArrayList var3 = FileLister.getDatabaseFiles(var1, var2, true);
      if (var3.isEmpty()) {
         this.printNoDatabaseFilesFound(var1, var2);
      }

      for(String var5 : var3) {
         if (var5.endsWith(".mv.db")) {
            String var6 = var5.substring(0, var5.length() - ".mv.db".length());
            PrintWriter var7 = this.getWriter(var5, ".txt");

            try {
               MVStoreTool.dump(var5, var7, true);
               MVStoreTool.info(var5, var7);
            } catch (Throwable var13) {
               if (var7 != null) {
                  try {
                     var7.close();
                  } catch (Throwable var11) {
                     var13.addSuppressed(var11);
                  }
               }

               throw var13;
            }

            if (var7 != null) {
               var7.close();
            }

            var7 = this.getWriter(var6 + ".h2.db", ".sql");

            try {
               this.dumpMVStoreFile(var7, var5);
            } catch (Throwable var12) {
               if (var7 != null) {
                  try {
                     var7.close();
                  } catch (Throwable var10) {
                     var12.addSuppressed(var10);
                  }
               }

               throw var12;
            }

            if (var7 != null) {
               var7.close();
            }
         }
      }

   }

   PrintWriter getWriter(String var1, String var2) {
      var1 = var1.substring(0, var1.length() - 3);
      String var3 = var1 + var2;
      this.trace("Created file: " + var3);

      try {
         return new PrintWriter(IOUtils.getBufferedWriter(FileUtils.newOutputStream(var3, false)));
      } catch (IOException var5) {
         throw DbException.convertIOException(var5, (String)null);
      }
   }

   void getSQL(StringBuilder var1, String var2, Value var3) {
      if (var3 instanceof ValueLob) {
         ValueLob var4 = (ValueLob)var3;
         LobData var5 = var4.getLobData();
         if (var5 instanceof LobDataDatabase) {
            LobDataDatabase var6 = (LobDataDatabase)var5;
            int var7 = var3.getValueType();
            long var8 = var6.getLobId();
            long var10;
            String var12;
            if (var7 == 7) {
               var10 = var4.octetLength();
               var12 = "BLOB";
               var1.append("READ_BLOB");
            } else {
               var10 = var4.charLength();
               var12 = "CLOB";
               var1.append("READ_CLOB");
            }

            if (this.lobMaps) {
               var1.append("_MAP");
            } else {
               var1.append("_DB");
            }

            this.columnTypeMap.put(var2, var12);
            var1.append('(').append(var8).append(", ").append(var10).append(')');
            return;
         }
      } else if (var3 instanceof ValueJson) {
         this.columnTypeMap.put(var2, "JSON");
      }

      var3.getSQL(var1, 4);
   }

   void setDatabaseName(String var1) {
      this.databaseName = var1;
   }

   private void dumpMVStoreFile(PrintWriter var1, String var2) {
      var1.println("-- MVStore");
      String var3 = this.getClass().getName();
      var1.println("CREATE ALIAS IF NOT EXISTS READ_BLOB_MAP FOR '" + var3 + ".readBlobMap';");
      var1.println("CREATE ALIAS IF NOT EXISTS READ_CLOB_MAP FOR '" + var3 + ".readClobMap';");
      this.resetSchema();
      this.setDatabaseName(var2.substring(0, var2.length() - ".mv.db".length()));

      try (MVStore var4 = (new MVStore.Builder()).fileName(var2).recoveryMode().readOnly().open()) {
         this.dumpLobMaps(var1, var4);
         var1.println("-- Layout");
         dumpLayout(var1, var4);
         var1.println("-- Meta");
         dumpMeta(var1, var4);
         var1.println("-- Types");
         dumpTypes(var1, var4);
         var1.println("-- Tables");
         TransactionStore var5 = new TransactionStore(var4, new ValueDataType());

         try {
            var5.init();
         } catch (Throwable var19) {
            this.writeError(var1, var19);
         }

         for(String var7 : var4.getMapNames()) {
            if (var7.startsWith("table.")) {
               String var8 = var7.substring("table.".length());
               if (Integer.parseInt(var8) == 0) {
                  TransactionMap var9 = var5.begin().openMap(var7);
                  Iterator var10 = var9.keyIterator((Object)null);

                  while(var10.hasNext()) {
                     Long var11 = (Long)var10.next();
                     Row var12 = (Row)var9.get(var11);

                     try {
                        this.writeMetaRow(var12);
                     } catch (Throwable var18) {
                        this.writeError(var1, var18);
                     }
                  }
               }
            }
         }

         this.writeSchemaSET(var1);
         var1.println("---- Table Data ----");

         for(String var23 : var4.getMapNames()) {
            if (var23.startsWith("table.")) {
               String var24 = var23.substring("table.".length());
               if (Integer.parseInt(var24) != 0) {
                  TransactionMap var25 = var5.begin().openMap(var23);
                  Iterator var26 = var25.keyIterator((Object)null);
                  boolean var27 = false;

                  while(var26.hasNext()) {
                     Object var28 = var26.next();
                     Object var13 = var25.get(var28);
                     Value[] var14;
                     if (var13 instanceof Row) {
                        var14 = ((Row)var13).getValueList();
                        this.recordLength = var14.length;
                     } else {
                        var14 = ((ValueCollectionBase)var13).getList();
                        this.recordLength = var14.length - 1;
                     }

                     if (!var27) {
                        this.setStorage(Integer.parseInt(var24));
                        StringBuilder var15 = new StringBuilder();

                        for(this.valueId = 0; this.valueId < this.recordLength; ++this.valueId) {
                           String var16 = this.storageName + "." + this.valueId;
                           var15.setLength(0);
                           this.getSQL(var15, var16, var14[this.valueId]);
                        }

                        this.createTemporaryTable(var1);
                        var27 = true;
                     }

                     StringBuilder var29 = new StringBuilder();
                     var29.append("INSERT INTO O_").append(var24).append(" VALUES(");

                     for(this.valueId = 0; this.valueId < this.recordLength; ++this.valueId) {
                        if (this.valueId > 0) {
                           var29.append(", ");
                        }

                        String var30 = this.storageName + "." + this.valueId;
                        this.getSQL(var29, var30, var14[this.valueId]);
                     }

                     var29.append(");");
                     var1.println(var29.toString());
                  }
               }
            }
         }

         this.writeSchema(var1);
         var1.println("DROP ALIAS READ_BLOB_MAP;");
         var1.println("DROP ALIAS READ_CLOB_MAP;");
         var1.println("DROP TABLE IF EXISTS INFORMATION_SCHEMA.LOB_BLOCKS;");
      } catch (Throwable var21) {
         this.writeError(var1, var21);
      }

   }

   static void dumpLayout(PrintWriter var0, MVStore var1) {
      Map var2 = var1.getLayoutMap();

      for(Map.Entry var4 : var2.entrySet()) {
         String var10001 = (String)var4.getKey();
         var0.println("-- " + var10001 + " = " + (String)var4.getValue());
      }

   }

   static void dumpMeta(PrintWriter var0, MVStore var1) {
      MVMap var2 = var1.getMetaMap();

      for(Map.Entry var4 : var2.entrySet()) {
         String var10001 = (String)var4.getKey();
         var0.println("-- " + var10001 + " = " + (String)var4.getValue());
      }

   }

   static void dumpTypes(PrintWriter var0, MVStore var1) {
      MVMap.Builder var2 = (new MVMap.Builder()).keyType(StringDataType.INSTANCE).valueType(new MetaType((Object)null, (Thread.UncaughtExceptionHandler)null));
      MVMap var3 = var1.openMap("_", var2);

      for(Map.Entry var5 : var3.entrySet()) {
         String var10001 = (String)var5.getKey();
         var0.println("-- " + var10001 + " = " + var5.getValue());
      }

   }

   void dumpLobMaps(PrintWriter var1, MVStore var2) {
      this.lobMaps = var2.hasMap("lobData");
      if (this.lobMaps) {
         TransactionStore var3 = new TransactionStore(var2);
         MVMap var4 = LobStorageMap.openLobDataMap(var3);
         StreamStore var5 = new StreamStore(var4);
         MVMap var6 = LobStorageMap.openLobMap(var3);
         var1.println("-- LOB");
         var1.println("CREATE TABLE IF NOT EXISTS INFORMATION_SCHEMA.LOB_BLOCKS(LOB_ID BIGINT, SEQ INT, DATA VARBINARY, PRIMARY KEY(LOB_ID, SEQ));");
         boolean var7 = false;

         for(Map.Entry var9 : var6.entrySet()) {
            long var10 = (Long)var9.getKey();
            LobStorageMap.BlobMeta var12 = (LobStorageMap.BlobMeta)var9.getValue();
            byte[] var13 = var12.streamStoreId;
            InputStream var14 = var5.get(var13);
            short var15 = 8192;
            byte[] var16 = new byte[var15];

            try {
               int var17 = 0;

               while(true) {
                  int var18 = IOUtils.readFully(var14, var16, var16.length);
                  if (var18 > 0) {
                     var1.print("INSERT INTO INFORMATION_SCHEMA.LOB_BLOCKS VALUES(" + var10 + ", " + var17 + ", X'");
                     var1.print(StringUtils.convertBytesToHex(var16, var18));
                     var1.println("');");
                  }

                  if (var18 != var15) {
                     break;
                  }

                  ++var17;
               }
            } catch (IOException var19) {
               this.writeError(var1, var19);
               var7 = true;
            }
         }

         var1.println("-- lobMap.size: " + var6.sizeAsLong());
         var1.println("-- lobData.size: " + var4.sizeAsLong());
         if (var7) {
            var1.println("-- lobMap");

            for(Long var22 : var6.keyList()) {
               LobStorageMap.BlobMeta var24 = (LobStorageMap.BlobMeta)var6.get(var22);
               byte[] var11 = var24.streamStoreId;
               var1.println("--     " + var22 + " " + StreamStore.toString(var11));
            }

            var1.println("-- lobData");

            for(Long var23 : var4.keyList()) {
               var1.println("--     " + var23 + " len " + ((byte[])var4.get(var23)).length);
            }
         }

      }
   }

   String setStorage(int var1) {
      this.storageId = var1;
      String var10001 = Integer.toString(var1);
      this.storageName = "O_" + var10001.replace('-', 'M');
      return this.storageName;
   }

   void writeMetaRow(Row var1) {
      MetaRecord var2 = new MetaRecord(var1);
      int var3 = var2.getObjectType();
      if (var3 != 1 || !var2.getSQL().startsWith("CREATE PRIMARY KEY ")) {
         this.schema.add(var2);
         if (var3 == 0) {
            this.tableMap.put(var2.getId(), extractTableOrViewName(var2.getSQL()));
         }

      }
   }

   void resetSchema() {
      this.schema = new ArrayList();
      this.objectIdSet = new HashSet();
      this.tableMap = new HashMap();
      this.columnTypeMap = new HashMap();
   }

   void writeSchemaSET(PrintWriter var1) {
      var1.println("---- Schema SET ----");

      for(MetaRecord var3 : this.schema) {
         if (var3.getObjectType() == 6) {
            String var4 = var3.getSQL();
            var1.println(var4 + ";");
         }
      }

   }

   void writeSchema(PrintWriter var1) {
      var1.println("---- Schema ----");
      Collections.sort(this.schema);

      for(MetaRecord var3 : this.schema) {
         if (var3.getObjectType() != 6 && !isSchemaObjectTypeDelayed(var3)) {
            String var4 = var3.getSQL();
            var1.println(var4 + ";");
         }
      }

      boolean var7 = false;

      for(Map.Entry var12 : this.tableMap.entrySet()) {
         Integer var5 = (Integer)var12.getKey();
         String var6 = (String)var12.getValue();
         if (this.objectIdSet.contains(var5) && isLobTable(var6)) {
            this.setStorage(var5);
            var1.println("DELETE FROM " + var6 + ";");
            var1.println("INSERT INTO " + var6 + " SELECT * FROM " + this.storageName + ";");
            if (var6.equals("INFORMATION_SCHEMA.LOBS") || var6.equalsIgnoreCase("\"INFORMATION_SCHEMA\".\"LOBS\"")) {
               var1.println("UPDATE " + var6 + " SET `TABLE` = -2;");
               var7 = true;
            }
         }
      }

      for(Map.Entry var13 : this.tableMap.entrySet()) {
         Integer var17 = (Integer)var13.getKey();
         String var20 = (String)var13.getValue();
         if (this.objectIdSet.contains(var17)) {
            this.setStorage(var17);
            if (!isLobTable(var20)) {
               var1.println("INSERT INTO " + var20 + " SELECT * FROM " + this.storageName + ";");
            }
         }
      }

      for(Integer var14 : this.objectIdSet) {
         this.setStorage(var14);
         var1.println("DROP TABLE " + this.storageName + ";");
      }

      if (var7) {
         var1.println("DELETE FROM INFORMATION_SCHEMA.LOBS WHERE `TABLE` = -2;");
      }

      ArrayList var11 = new ArrayList();

      for(MetaRecord var18 : this.schema) {
         if (isSchemaObjectTypeDelayed(var18)) {
            String var21 = var18.getSQL();
            if (var18.getObjectType() == 5 && var21.endsWith("NOCHECK") && var21.contains(" FOREIGN KEY") && var21.contains("REFERENCES ")) {
               var11.add(var21);
            } else {
               var1.println(var21 + ";");
            }
         }
      }

      for(String var19 : var11) {
         var1.println(var19 + ";");
      }

   }

   private static boolean isLobTable(String var0) {
      return var0.startsWith("INFORMATION_SCHEMA.LOB") || var0.startsWith("\"INFORMATION_SCHEMA\".\"LOB") || var0.startsWith("\"information_schema\".\"lob");
   }

   private static boolean isSchemaObjectTypeDelayed(MetaRecord var0) {
      switch (var0.getObjectType()) {
         case 1:
         case 4:
         case 5:
            return true;
         case 2:
         case 3:
         default:
            return false;
      }
   }

   void createTemporaryTable(PrintWriter var1) {
      if (!this.objectIdSet.contains(this.storageId)) {
         this.objectIdSet.add(this.storageId);
         var1.write("CREATE TABLE ");
         var1.write(this.storageName);
         var1.write(40);

         for(int var2 = 0; var2 < this.recordLength; ++var2) {
            if (var2 > 0) {
               var1.print(", ");
            }

            var1.write(67);
            var1.print(var2);
            var1.write(32);
            String var10001 = this.storageName;
            String var3 = (String)this.columnTypeMap.get(var10001 + "." + var2);
            var1.write(var3 == null ? "VARCHAR" : var3);
         }

         var1.println(");");
         var1.flush();
      }

   }

   private static String extractTableOrViewName(String var0) {
      int var1 = var0.indexOf(" TABLE ");
      int var2 = var0.indexOf(" VIEW ");
      if (var1 > 0 && var2 > 0) {
         if (var1 < var2) {
            var2 = -1;
         } else {
            var1 = -1;
         }
      }

      if (var2 > 0) {
         var0 = var0.substring(var2 + " VIEW ".length());
      } else {
         if (var1 <= 0) {
            return "UNKNOWN";
         }

         var0 = var0.substring(var1 + " TABLE ".length());
      }

      if (var0.startsWith("IF NOT EXISTS ")) {
         var0 = var0.substring("IF NOT EXISTS ".length());
      }

      boolean var3 = false;

      for(int var4 = 0; var4 < var0.length(); ++var4) {
         char var5 = var0.charAt(var4);
         if (var5 == '"') {
            var3 = !var3;
         } else if (!var3 && (var5 <= ' ' || var5 == '(')) {
            var0 = var0.substring(0, var4);
            return var0;
         }
      }

      return "UNKNOWN";
   }

   void writeError(PrintWriter var1, Throwable var2) {
      if (var1 != null) {
         var1.println("// error: " + var2);
      }

      this.traceError("Error", var2);
   }

   public String getDatabasePath() {
      return this.databaseName;
   }

   public FileStore openFile(String var1, String var2, boolean var3) {
      return FileStore.open(this, var1, "rw");
   }

   public void checkPowerOff() {
   }

   public void checkWritingAllowed() {
   }

   public int getMaxLengthInplaceLob() {
      throw DbException.getInternalError();
   }

   public Object getLobSyncObject() {
      return this;
   }

   public SmallLRUCache<String, String[]> getLobFileListCache() {
      return null;
   }

   public TempFileDeleter getTempFileDeleter() {
      return TempFileDeleter.getInstance();
   }

   public LobStorageInterface getLobStorage() {
      return null;
   }

   public int readLob(long var1, byte[] var3, long var4, byte[] var6, int var7, int var8) {
      throw DbException.getInternalError();
   }

   public CompareMode getCompareMode() {
      return CompareMode.getInstance((String)null, 0);
   }
}
